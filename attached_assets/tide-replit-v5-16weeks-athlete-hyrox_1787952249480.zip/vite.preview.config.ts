import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Build de un solo archivo, formato IIFE (script clásico) para máxima compatibilidad
export default defineConfig({
  plugins: [react()],
  define: { 'process.env.NODE_ENV': '"production"' },
  build: {
    outDir: 'dist-preview',
    target: 'es2017',
    cssCodeSplit: false,
    modulePreload: false,
    rollupOptions: {
      input: 'src/main.tsx',
      output: {
        format: 'iife',
        entryFileNames: 'app.js',
        assetFileNames: 'app.[ext]',
        inlineDynamicImports: true,
      },
    },
  },
});
