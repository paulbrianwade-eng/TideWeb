import { EXERCISES } from '../src/data/exercises';
const caps = new Set(EXERCISES.flatMap(e => e.capacities));
console.log('ejercicios:', EXERCISES.length);
console.log('capacidades cubiertas:', caps.size);
const need = ['Antirrotación','Rotación','Unilateral','Unipodal','Plano frontal','Plano transversal','Tendón','Pie y tobillo','Equilibrio','Desaceleración','Cambio de dirección','Absorción de impacto','Isometría','Excéntrico'];
console.log('faltantes:', need.filter(c => !caps.has(c as any)).join(', ') || 'ninguna');
console.log('sin objetivo:', EXERCISES.filter(e => !e.objective).length);
console.log('sin video:', EXERCISES.filter(e => !e.video).length);
