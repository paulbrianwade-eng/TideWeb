import type { Workout } from '../types';

type Pattern='push'|'pull'|'squat'|'hinge'|'rotation'|'unilateral'|'jump'|'locomotion'|'core';
const MAP:Record<string,Pattern[]>={
  'bench-press':['push'],'push-press':['push'],'kb-clean-push-press':['push','hinge'],'scapular-push-up':['push'],
  'pull-up':['pull'],'trx-row':['pull'],'face-pull':['pull'],
  'back-squat':['squat'],'front-squat':['squat'],'bulgarian-split-squat':['squat','unilateral'],'reverse-lunge':['squat','unilateral'],
  'romanian-deadlift':['hinge'],'single-leg-rdl':['hinge','unilateral'],'kb-swing':['hinge'], 'hang-clean':['hinge'],
  'rotational-mb-throw':['rotation'],'side-plank-rotation':['rotation','core'],'pallof-press':['core'],'dead-bug':['core'],'ab-wheel':['core'],'copenhagen-plank':['core'],
  'box-jump':['jump'],'broad-jump':['jump'],'lateral-bound':['jump','unilateral'],'pogo-jump':['jump'],
  'threshold-run':['locomotion'],'block-run':['locomotion'],'shuttle-run':['locomotion'],'jump-rope':['locomotion'],'spinning-bike':['locomotion'],
};

export const auditWorkout=(w:Workout)=>{
  const counts:Record<Pattern,number>={push:0,pull:0,squat:0,hinge:0,rotation:0,unilateral:0,jump:0,locomotion:0,core:0};
  for(const b of w.blocks){
    if(b.kind==='finisher') continue; // fatiga metabólica no cuenta igual que trabajo principal
    for(const item of b.items) for(const pat of MAP[item.exerciseId]??[]) counts[pat]++;
  }
  const warnings:string[]=[];
  if(counts.push>2) warnings.push('Mucho empuje antes del finisher');
  if(counts.pull>2) warnings.push('Mucho tirón antes del finisher');
  if(counts.squat>2) warnings.push('Patrón de sentadilla repetido');
  if(counts.hinge>2) warnings.push('Bisagra repetida');
  return {counts,warnings};
};
