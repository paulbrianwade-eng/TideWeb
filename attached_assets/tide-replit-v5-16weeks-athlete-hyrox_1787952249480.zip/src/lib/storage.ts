import type { AppState } from '../types';
import { DEFAULT_PROFILE } from '../data/defaults';

export const STORAGE_KEY = 'tide.state.v1';
export const STATE_VERSION = 1;

export const emptyState = (): AppState => ({
  version: STATE_VERSION,
  profile: { ...DEFAULT_PROFILE },
  readiness: {},
  adjustments: {},
  sessions: {},
  history: [],
  calendarOverrides: {},
  metrics: {},
  nutrition: {},
  extras: {},
  lastScreen: 'today',
});

export const loadState = (): AppState => {
  if (typeof window === 'undefined') return emptyState();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyState();
    const parsed = JSON.parse(raw) as Partial<AppState>;
    if (parsed.version !== STATE_VERSION) return emptyState();
    return { ...emptyState(), ...parsed, profile: { ...DEFAULT_PROFILE, ...parsed.profile } };
  } catch {
    return emptyState();
  }
};

export const saveState = (state: AppState): void => {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* almacenamiento no disponible: la app sigue funcionando en memoria */
  }
};

export const clearState = (): void => {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* noop */
  }
};
