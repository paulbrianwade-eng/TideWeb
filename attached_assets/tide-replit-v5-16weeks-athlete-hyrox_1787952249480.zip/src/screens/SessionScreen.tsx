import { useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight, Flag } from 'lucide-react';
import { useApp } from '../state/AppContext';
import type { CompletedSet, SessionSummary, Workout, WorkoutSession } from '../types';
import { BLOCK_META } from '../components/blockMeta';
import { getExercise } from '../data/exercises';
import {
  blocksCompleted,
  completedSetCount,
  prescriptionKey,
  sessionProgress,
  sessionVolume,
  setsForItem,
} from '../lib/prescription';
import { detectRecord, highlightExercise } from '../lib/records';
import { formatClock } from '../lib/date';
import { ExerciseSetTracker } from '../components/ExerciseSetTracker';
import { RestTimer, parseRestSeconds } from '../components/RestTimer';
import { WorkoutSummaryModal } from '../components/WorkoutSummaryModal';
import { CoachNote } from '../components/workout-parts';
import { BlockTimer } from '../components/BlockTimer';

const newSession = (workout: Workout): WorkoutSession => ({
  workoutId: workout.id,
  date: workout.date,
  startedAt: Date.now(),
  elapsedMs: 0,
  blockIndex: 0,
  activeKey: prescriptionKey(workout.blocks[0].id, 0),
  sets: {},
  skipped: [],
  substitutions: {},
});

export const SessionScreen = ({
  workout,
  onExit,
  initialBlockIndex,
}: {
  workout: Workout;
  onExit: () => void;
  initialBlockIndex?: number;
}) => {
  const app = useApp();
  const stored = app.sessionFor(workout.id);
  const [session, setSession] = useState<WorkoutSession>(() => stored ?? newSession(workout));
  const [restSeconds, setRestSeconds] = useState<number | null>(null);
  const [showSummary, setShowSummary] = useState(false);
  const elapsedRef = useRef(session.elapsedMs);
  const [elapsed, setElapsed] = useState(session.elapsedMs);

  useEffect(() => {
    if (initialBlockIndex === undefined) return;
    const target = Math.max(0, Math.min(initialBlockIndex, workout.blocks.length - 1));
    setSession((prev) =>
      prev.blockIndex === target
        ? prev
        : { ...prev, blockIndex: target, activeKey: prescriptionKey(workout.blocks[target].id, 0) },
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialBlockIndex]);

  useEffect(() => {
    const id = window.setInterval(() => {
      elapsedRef.current += 1000;
      setElapsed(elapsedRef.current);
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  const update = (patch: Partial<WorkoutSession>) => {
    setSession((prev) => {
      const next = { ...prev, ...patch, elapsedMs: elapsedRef.current };
      app.saveSession(next);
      return next;
    });
  };

  const block = workout.blocks[Math.min(session.blockIndex, workout.blocks.length - 1)];
  const meta = BLOCK_META[block.kind];
  const BlockIcon = meta.icon;
  const progress = sessionProgress(workout, session);

  const flatItems = useMemo(
    () =>
      workout.blocks.flatMap((b) =>
        b.items.map((item, i) => ({ blockId: b.id, key: prescriptionKey(b.id, i), item })),
      ),
    [workout],
  );

  const activeIndex = flatItems.findIndex((f) => f.key === session.activeKey);
  const nextItem = activeIndex >= 0 ? flatItems[activeIndex + 1] : undefined;

  /** Siguiente ejercicio del bloque, o null si era el último. */
  const nextKeyInBlock = (itemIndex: number): string | null =>
    itemIndex + 1 < block.items.length ? prescriptionKey(block.id, itemIndex + 1) : null;

  const setRow = (key: string, itemIndex: number, index: number, value: CompletedSet, count: number) => {
    const rows = [...(session.sets[key] ?? Array.from({ length: count }, () => ({ done: false })))];
    while (rows.length < count) rows.push({ done: false });
    rows[index] = value;
    const finished = rows.length >= count && rows.slice(0, count).every((r) => r.done);
    const nextKey = finished ? nextKeyInBlock(itemIndex) : null;
    update({
      sets: { ...session.sets, [key]: rows },
      ...(nextKey ? { activeKey: nextKey } : {}),
    });
  };

  const completeAll = (key: string, itemIndex: number, count: number, rest?: string) => {
    const rows = Array.from({ length: count }, (_, i) => ({
      ...(session.sets[key]?.[i] ?? {}),
      done: true,
    }));
    const nextKey = nextKeyInBlock(itemIndex);
    update({
      sets: { ...session.sets, [key]: rows },
      ...(nextKey ? { activeKey: nextKey } : {}),
    });
    setRestSeconds(parseRestSeconds(rest));
  };

  const toggleSkip = (key: string) =>
    update({
      skipped: session.skipped.includes(key)
        ? session.skipped.filter((k) => k !== key)
        : [...session.skipped, key],
    });

  const substitute = (key: string, name: string) => {
    const subs = { ...session.substitutions };
    if (name) subs[key] = name;
    else delete subs[key];
    update({ substitutions: subs });
  };

  const finish = () => {
    update({ completedAt: Date.now() });
    setShowSummary(true);
  };

  const saveSummary = (summary: SessionSummary) => {
    app.saveSummary(summary);
    app.setReadiness(workout.date, { energy: summary.energy, pain: summary.pain });
    setShowSummary(false);
    onExit();
  };

  const draft = {
    workoutId: workout.id,
    workoutName: workout.name,
    date: workout.date,
    durationMin: Math.max(1, Math.round(elapsed / 60000)),
    blocksCompleted: blocksCompleted(workout, session),
    blocksTotal: workout.blocks.length,
    volumeKg: sessionVolume(workout, session),
    setsCompleted: completedSetCount(workout, session),
    highlight: highlightExercise(workout, session),
    personalRecord: detectRecord(workout, session, app.state.sessions, app.program),
  };

  return (
    <div className="min-h-screen bg-base pb-40">
      <header className="sticky top-0 z-20 border-b border-line bg-base/95 pt-[env(safe-area-inset-top)] backdrop-blur">
        <div className="mx-auto max-w-3xl px-4 py-2.5 sm:py-3">
          <div className="flex items-center justify-between gap-3">
            <button type="button" onClick={onExit} className="btn-quiet px-1">
              <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Guardar y salir
            </button>
            <p className="font-mono text-sm">{formatClock(elapsed)}</p>
          </div>
          <div className="mt-2">
            <div className="flex items-baseline justify-between">
              <p className="truncate font-display text-base font-semibold leading-none sm:text-lg">{workout.name}</p>
              <p className="font-mono text-[11px] text-muted">{Math.round(progress * 100)} %</p>
            </div>
            <div
              role="progressbar"
              aria-valuenow={Math.round(progress * 100)}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label="Progreso de la sesión"
              className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-surface2"
            >
              <div className="h-full rounded-full bg-accent transition-all" style={{ width: `${progress * 100}%` }} />
            </div>
          </div>
          <div className="-mx-4 mt-2.5 flex gap-1.5 overflow-x-auto px-4 pb-1">
            {workout.blocks.map((b, i) => {
              const bm = BLOCK_META[b.kind];
              const active = i === session.blockIndex;
              return (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => update({ blockIndex: i, activeKey: prescriptionKey(b.id, 0) })}
                  aria-current={active ? 'step' : undefined}
                  className={`shrink-0 rounded-full border px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.1em] ${
                    active ? 'text-night' : 'border-line bg-surface2 text-muted'
                  }`}
                  style={active ? { backgroundColor: bm.color, borderColor: bm.color } : undefined}
                >
                  {b.title}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-3xl space-y-4 px-4 py-4">
        <div className="card p-4">
          <div className="flex items-center gap-3">
            <span
              aria-hidden="true"
              className={`grid h-10 w-10 place-items-center rounded-xl border ${meta.ring}`}
              style={{ backgroundColor: `${meta.color}14` }}
            >
              <BlockIcon className="h-5 w-5" style={{ color: meta.color }} />
            </span>
            <div>
              <p className="font-display text-lg leading-none">{block.title}</p>
              <p className="text-xs text-muted">
                {block.duration}
                {block.rounds ? ` · ${block.rounds}` : ''}
                {block.rest ? ` · descanso ${block.rest}` : ''}
              </p>
            </div>
          </div>
        </div>

        {(block.kind === 'transition' || block.kind === 'finisher') && (
          <BlockTimer kind={block.kind} duration={block.duration} />
        )}

        <ul className="space-y-2">
          {block.items.map((item, i) => {
            const key = prescriptionKey(block.id, i);
            const count = setsForItem(block.rounds, item);
            const rows = session.sets[key] ?? [];
            const done = rows.filter((r) => r.done).length;
            const isActive = session.activeKey === key;
            const skipped = session.skipped.includes(key);
            const ex = getExercise(item.exerciseId);

            return (
              <li key={key} className={`card p-4 ${isActive ? 'border-accent/40' : ''}`}>
                {isActive ? (
                  <ExerciseSetTracker
                    prescription={item}
                    setCount={count}
                    rows={rows}
                    skipped={skipped}
                    substitution={session.substitutions[key]}
                    onSetChange={(idx, value) => setRow(key, i, idx, value, count)}
                    onCompleteAll={() => completeAll(key, i, count, item.rest)}
                    onSkip={() => toggleSkip(key)}
                    onSubstitute={(name) => substitute(key, name)}
                    onRest={() => setRestSeconds(parseRestSeconds(item.rest ?? block.rest))}
                  />
                ) : (
                  <button
                    type="button"
                    onClick={() => update({ activeKey: key })}
                    className="flex w-full items-center justify-between gap-3 text-left"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium">
                        {item.order ? <span className="mr-2 font-mono text-[11px] text-accent">{item.order}</span> : null}
                        {session.substitutions[key] ?? ex.name}
                      </span>
                      <span className="block font-mono text-[11px] text-muted">
                        {skipped ? 'Salteado' : `${done}/${count} series`}
                      </span>
                    </span>
                    <ChevronRight className="h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
                  </button>
                )}
              </li>
            );
          })}
        </ul>

        {nextItem && (
          <p className="text-sm text-muted">
            <span className="eyebrow mr-2">Sigue</span>
            {session.substitutions[nextItem.key] ?? getExercise(nextItem.item.exerciseId).name}
          </p>
        )}

        <CoachNote text={workout.coachNote} compact />

        <div className="flex gap-2">
          <button
            type="button"
            disabled={session.blockIndex === 0}
            onClick={() =>
              update({
                blockIndex: session.blockIndex - 1,
                activeKey: prescriptionKey(workout.blocks[session.blockIndex - 1].id, 0),
              })
            }
            className="btn-ghost flex-1"
          >
            <ChevronLeft className="h-4 w-4" aria-hidden="true" /> Bloque anterior
          </button>
          {session.blockIndex < workout.blocks.length - 1 ? (
            <button
              type="button"
              onClick={() =>
                update({
                  blockIndex: session.blockIndex + 1,
                  activeKey: prescriptionKey(workout.blocks[session.blockIndex + 1].id, 0),
                })
              }
              className="btn-ghost flex-1"
            >
              Bloque siguiente <ChevronRight className="h-4 w-4" aria-hidden="true" />
            </button>
          ) : (
            <button type="button" onClick={finish} className="btn-primary flex-1 py-3 text-sm">
              <Flag className="h-4 w-4" aria-hidden="true" /> Finalizar
            </button>
          )}
        </div>

        {session.blockIndex < workout.blocks.length - 1 && (
          <button type="button" onClick={finish} className="btn-quiet w-full">
            Finalizar entrenamiento ahora
          </button>
        )}
      </div>

      {restSeconds !== null && (
        <RestTimer seconds={restSeconds} onClose={() => setRestSeconds(null)} />
      )}

      {showSummary && (
        <WorkoutSummaryModal draft={draft} onSave={saveSummary} onClose={() => setShowSummary(false)} />
      )}
    </div>
  );
};
