import { Droplets, Info, Pill } from 'lucide-react';
import { useApp } from '../state/AppContext';
import { MATE_NOTE, MEAL_PLAN, NUTRITION_DAYS, NUTRITION_TARGETS } from '../data/defaults';
import { longDate } from '../lib/date';
import { Card, SectionTitle, StatusBadge, Toggle } from '../components/ui';

const CARB_TONE = { Alto: 'success', Moderado: 'accent', Bajo: 'warn' } as const;
const WATER_GOAL = 10; // vasos de 250 ml ≈ 2,5 L

export const NutritionScreen = () => {
  const app = useApp();
  const day = app.nutritionFor(app.today);
  const config = NUTRITION_DAYS.find((d) => d.id === day.dayType) ?? NUTRITION_DAYS[0];

  const toggleMeal = (id: string) =>
    app.setNutrition(app.today, {
      mealsDone: day.mealsDone.includes(id)
        ? day.mealsDone.filter((m) => m !== id)
        : [...day.mealsDone, id],
    });

  return (
    <div className="space-y-4">
      <header>
        <p className="eyebrow">{longDate(app.today)}</p>
        <h1 className="font-display text-3xl leading-none">Nutrición</h1>
      </header>

      <Card className="space-y-3">
        <SectionTitle eyebrow="Objetivo diario" title="Base del día" />
        <dl className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <dt className="eyebrow">Proteína</dt>
            <dd className="font-display text-lg">{NUTRITION_TARGETS.protein}</dd>
          </div>
          <div>
            <dt className="eyebrow">Calorías</dt>
            <dd className="font-display text-lg">{NUTRITION_TARGETS.calories}</dd>
          </div>
          <div>
            <dt className="eyebrow">Hidratación</dt>
            <dd className="text-sm">{NUTRITION_TARGETS.water}</dd>
          </div>
          <div>
            <dt className="eyebrow">Creatina</dt>
            <dd className="text-sm">{NUTRITION_TARGETS.creatine}</dd>
          </div>
        </dl>
        <p className="flex gap-2 rounded-xl border border-line bg-surface2 p-3 text-xs text-muted">
          <Info className="h-4 w-4 shrink-0" aria-hidden="true" />
          Guía general de entrenamiento, no es una indicación médica ni un plan nutricional personalizado. Consultá
          con un profesional para ajustarlo a tu caso.
        </p>
      </Card>

      <Card className="space-y-3">
        <SectionTitle
          eyebrow="Tipo de día"
          title="Carbohidratos"
          right={<StatusBadge tone={CARB_TONE[config.carbs]}>{config.carbs}</StatusBadge>}
        />
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {NUTRITION_DAYS.map((d) => (
            <button
              key={d.id}
              type="button"
              aria-pressed={day.dayType === d.id}
              onClick={() => app.setDayType(app.today, d.id)}
              className={`rounded-xl border px-3 py-2.5 text-sm ${
                day.dayType === d.id ? 'border-accent bg-accent/15' : 'border-line bg-surface2 text-muted'
              }`}
            >
              {d.label}
            </button>
          ))}
        </div>
        <p className="text-sm text-muted">{config.note}</p>
      </Card>

      <Card className="space-y-3">
        <SectionTitle eyebrow="Hidratación" title="Agua del día" />
        <div className="flex items-center gap-3">
          <Droplets className="h-5 w-5 text-accent" aria-hidden="true" />
          <p className="font-display text-2xl">
            {day.water}
            <span className="text-muted">/{WATER_GOAL}</span>
          </p>
          <p className="text-sm text-muted">vasos de 250 ml</p>
        </div>
        <div className="grid grid-cols-5 gap-1.5 sm:grid-cols-10 sm:gap-1">
          {Array.from({ length: WATER_GOAL }, (_, i) => (
            <button
              key={i}
              type="button"
              aria-label={`Marcar ${i + 1} vasos de agua`}
              aria-pressed={i < day.water}
              onClick={() => app.setNutrition(app.today, { water: i + 1 === day.water ? i : i + 1 })}
              className={`h-11 rounded-lg border sm:h-9 ${
                i < day.water ? 'border-accent bg-accent/25' : 'border-line bg-surface2'
              }`}
            />
          ))}
        </div>
        <Toggle active={day.creatine} onClick={() => app.setNutrition(app.today, { creatine: !day.creatine })}>
          <span className="flex items-center gap-2">
            <Pill className="h-4 w-4" aria-hidden="true" /> Creatina 5 g
          </span>
        </Toggle>
      </Card>

      <section>
        <SectionTitle
          eyebrow={`${day.mealsDone.length}/${MEAL_PLAN.length} comidas`}
          title="Día con entrenamiento temprano"
        />
        <ul className="space-y-2">
          {MEAL_PLAN.map((meal) => {
            const done = day.mealsDone.includes(meal.id);
            return (
              <li key={meal.id}>
                <button
                  type="button"
                  aria-pressed={done}
                  onClick={() => toggleMeal(meal.id)}
                  className={`card flex w-full gap-3 p-4 text-left transition-colors ${
                    done ? 'border-accent/40' : ''
                  }`}
                >
                  <span
                    aria-hidden="true"
                    className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded border text-[11px] ${
                      done ? 'border-accent bg-accent text-night' : 'border-line'
                    }`}
                  >
                    {done ? '✓' : ''}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-baseline justify-between gap-2">
                      <span className="font-display text-base">{meal.title}</span>
                      <span className="font-mono text-[11px] text-muted">{meal.time}</span>
                    </span>
                    <span className="mt-1 block text-sm text-muted">
                      {meal.items.join(' · ')}
                      {meal.optional ? ' (opcional)' : ''}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </section>

      <Card>
        <p className="eyebrow">Sobre el mate</p>
        <p className="mt-1 text-sm text-muted">{MATE_NOTE}</p>
      </Card>
    </div>
  );
};
