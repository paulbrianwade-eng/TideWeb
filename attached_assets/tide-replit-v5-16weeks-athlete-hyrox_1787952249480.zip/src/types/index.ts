export type BlockKind =
  | 'core'
  | 'strength'
  | 'transition'
  | 'athletic'
  | 'finisher'
  | 'movement'
  | 'recovery'
  | 'reset'
  | 'power'
  | 'engine';

/** Módulos deportivos que reemplazan trabajo accesorio dentro de los bloques. */
export type SportModule = 'ski' | 'surf' | 'golf' | 'running';

/** Cualidades que entrena un ejercicio. Es el eje del programa, no el músculo. */
export type Capacity =
  | 'Fuerza máxima'
  | 'Potencia'
  | 'Velocidad'
  | 'Resistencia local'
  | 'Isometría'
  | 'Excéntrico'
  | 'Antirrotación'
  | 'Rotación'
  | 'Unilateral'
  | 'Unipodal'
  | 'Plano frontal'
  | 'Plano transversal'
  | 'Tendón'
  | 'Pie y tobillo'
  | 'Equilibrio'
  | 'Desaceleración'
  | 'Cambio de dirección'
  | 'Absorción de impacto'
  | 'Movilidad'
  | 'Estabilidad escapular'
  | 'Capacidad aeróbica'
  | 'Umbral'
  | 'Down regulation';

/** Fase del macrociclo de 16 semanas. */
export interface Phase {
  id: number;
  name: string;
  weeks: [number, number];
  focus: string;
  /** Cómo se prescribe la fuerza principal en esta fase. */
  strength: { sets: number; reps: string; rpe: string; rest: string };
  /** Cómo se prescribe la potencia. */
  power: { sets: number; reps: string; rest: string; intent: string };
  /** Multiplicador de volumen accesorio. */
  accessoryReps: string;
  coachNote: string;
}

export type SportActivity =
  | 'surf'
  | 'golf'
  | 'ski'
  | 'running'
  | 'rest'
  | 'gym'
  | 'home';

export type WorkoutStatus =
  | 'pending'
  | 'completed'
  | 'modified'
  | 'external'
  | 'rest';

export type MetricStatus = 'nodata' | 'improving' | 'stable' | 'attention';

export type ExerciseCategory =
  | 'Fuerza'
  | 'Potencia'
  | 'Antirrotación'
  | 'Rotación'
  | 'Unilateral'
  | 'Unipodal'
  | 'Plano frontal'
  | 'Core'
  | 'Tendones'
  | 'Movilidad'
  | 'Running'
  | 'Surf'
  | 'Golf'
  | 'Esquí'
  | 'Recovery'
  | 'Cardio';

export interface Exercise {
  id: string;
  name: string;
  categories: ExerciseCategory[];
  /** Para qué está en el programa: la intención, en una línea. */
  objective: string;
  /** Cualidades que desarrolla. */
  capacities: Capacity[];
  /** Músculos y estructuras principales. */
  targets: string[];
  /** Módulos deportivos a los que aporta directamente. */
  modules?: SportModule[];
  typical: string;
  cues: string[];
  mistakes: string[];
  regression: string;
  progression: string;
  equipment: string[];
  /** Término de búsqueda para el video de técnica (se abre en YouTube). */
  video?: string;
}

export interface ExercisePrescription {
  exerciseId: string;
  /** Etiqueta de orden dentro del bloque: A1, B, E3… (corta, 1-3 caracteres) */
  order?: string;
  /** Subgrupo dentro del bloque: "Circuito", "Finisher"… se muestra como encabezado. */
  group?: string;
  sets?: number;
  reps?: string;
  duration?: string;
  distance?: string;
  rest?: string;
  rpe?: string;
  load?: string;
  unilateral?: boolean;
  isometric?: boolean;
  carry?: boolean;
  instructions?: string;
  alternatives?: string[];
}

export interface WorkoutBlock {
  id: string;
  kind: BlockKind;
  title: string;
  duration: string;
  focus?: string;
  rounds?: string;
  rest?: string;
  /** Módulo deportivo que ocupa este bloque, si aplica. */
  module?: SportModule;
  items: ExercisePrescription[];
}

export interface Workout {
  id: string;
  week: number;
  day: number;
  date: string; // YYYY-MM-DD
  name: string;
  subtitle: string;
  objective: string;
  duration: string;
  plannedRpe: string;
  coachNote: string;
  nextDayActivity: SportActivity | null;
  blocks: WorkoutBlock[];
  adaptations: string[];
  status: WorkoutStatus;
  /** Fase del macrociclo (1-4). */
  phase: number;
  /** Módulos deportivos presentes en la sesión. */
  modules: SportModule[];
  /** Día sin entrenamiento programado (deporte externo o descanso). */
  externalActivity?: SportActivity;
}

export interface UserProfile {
  name: string;
  age: number;
  weight: number;
  height: number;
  targetWeight: number;
  daysAvailable: number;
  preferredDuration: string;
  equipment: string[];
  sports: string[];
  complaints: string[];
  trainingTime: string;
}

export interface CompletedSet {
  done: boolean;
  load?: string;
  reps?: string;
}

export interface WorkoutSession {
  workoutId: string;
  date: string;
  startedAt: number;
  completedAt?: number;
  elapsedMs: number;
  blockIndex: number;
  activeKey: string | null;
  sets: Record<string, CompletedSet[]>;
  skipped: string[];
  substitutions: Record<string, string>;
}

export interface SessionSummary {
  workoutId: string;
  workoutName: string;
  date: string;
  durationMin: number;
  blocksCompleted: number;
  blocksTotal: number;
  volumeKg: number;
  setsCompleted: number;
  rpe: number;
  energy: number;
  pain: number;
  feeling: 'fresco' | 'justo' | 'destruido' | null;
  comment: string;
  highlight: string | null;
  personalRecord: string | null;
  coachNote: string;
}

export interface DailyReadiness {
  energy: number | null;
  sleep: number | null;
  pain: number | null;
  motivation: number | null;
}

export interface CoachAdjustment {
  id: string;
  label: string;
  group: 'estado' | 'mañana' | 'contexto';
  recommendation: string;
  effect: string;
}

export type NutritionDayType =
  | 'fuerza'
  | 'hibrido'
  | 'zona2'
  | 'descanso'
  | 'ski'
  | 'surf'
  | 'golf';

export interface NutritionDay {
  date: string;
  dayType: NutritionDayType;
  mealsDone: string[];
  water: number;
  creatine: boolean;
}

export interface ProgressMetric {
  id: string;
  group: 'Composición' | 'Fuerza' | 'Atlético' | 'Engine' | 'Recuperación';
  label: string;
  unit: string;
  target?: string;
  hint?: string;
  /** true = valores más bajos son mejores (peso, cintura, 5k, FC reposo, dolor) */
  lowerIsBetter?: boolean;
}

export interface MetricEntry {
  date: string;
  value: number;
}

export interface AppState {
  version: number;
  profile: UserProfile;
  readiness: Record<string, DailyReadiness>;
  adjustments: Record<string, string[]>;
  sessions: Record<string, WorkoutSession>;
  history: SessionSummary[];
  calendarOverrides: Record<string, SportActivity>;
  metrics: Record<string, MetricEntry[]>;
  nutrition: Record<string, NutritionDay>;
  extras: Record<string, string[]>;
  lastScreen: string;
}
