import type { ReactNode } from 'react';
export { Logo, Wordmark, TideMark, TideLevel, Band, tideLoad } from './ui2';

export const Card = ({
  children,
  className = '',
  as: As = 'div',
}: {
  children: ReactNode;
  className?: string;
  as?: 'div' | 'section' | 'li' | 'article';
}) => <As className={`card p-4 ${className}`}>{children}</As>;

export const SectionTitle = ({ eyebrow, title, right }: { eyebrow?: string; title: string; right?: ReactNode }) => (
  <div className="mb-3 flex items-end justify-between gap-3">
    <div>
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <h2 className="font-display text-xl">{title}</h2>
    </div>
    {right}
  </div>
);

type Tone = 'accent' | 'success' | 'warn' | 'danger' | 'muted';

const TONE_CLASS: Record<Tone, string> = {
  accent: 'bg-accent/15 text-accent border-accent/30',
  success: 'bg-success/15 text-success border-success/30',
  warn: 'bg-warn/15 text-warn border-warn/30',
  danger: 'bg-danger/15 text-danger border-danger/30',
  muted: 'bg-surface2 text-muted border-line',
};

export const StatusBadge = ({
  tone = 'muted',
  children,
  icon,
}: {
  tone?: Tone;
  children: ReactNode;
  icon?: ReactNode;
}) => (
  <span
    className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[11px] uppercase tracking-[0.12em] ${TONE_CLASS[tone]}`}
  >
    {icon}
    {children}
  </span>
);

export const EmptyState = ({
  title,
  hint,
  action,
}: {
  title: string;
  hint: string;
  action?: ReactNode;
}) => (
  <div className="rounded-2xl border border-dashed border-line p-6 text-center">
    <p className="font-display text-base">{title}</p>
    <p className="mt-1 text-sm text-muted">{hint}</p>
    {action && <div className="mt-3">{action}</div>}
  </div>
);

export const Stat = ({ label, value, tone = 'ink' }: { label: string; value: string; tone?: 'ink' | 'accent' }) => (
  <div>
    <p className="eyebrow">{label}</p>
    <p className={`font-display text-lg ${tone === 'accent' ? 'text-accent' : ''}`}>{value}</p>
  </div>
);

export const ScaleSelector = ({
  label,
  value,
  onChange,
  max = 10,
  min = 1,
  hint,
}: {
  label: string;
  value: number | null;
  onChange: (v: number) => void;
  max?: number;
  min?: number;
  hint?: string;
}) => {
  const values = Array.from({ length: max - min + 1 }, (_, i) => i + min);
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between">
        <p className="text-sm font-medium">{label}</p>
        <p className="font-mono text-xs text-muted">{value === null ? 'sin dato' : `${value}/${max}`}</p>
      </div>
      <div role="group" aria-label={label} className="grid grid-cols-5 gap-1.5 sm:grid-cols-10 sm:gap-1">
        {values.map((v) => {
          const active = value !== null && v <= value;
          return (
            <button
              key={v}
              type="button"
              aria-label={`${label}: ${v}`}
              aria-pressed={value === v}
              onClick={() => onChange(v)}
              className={`h-11 rounded-lg border text-xs font-semibold transition-colors sm:h-9 sm:text-[11px] ${
                active
                  ? 'border-accent/60 bg-accent/20 text-accent'
                  : 'border-line bg-surface2 text-muted hover:border-white/25'
              } ${value === v ? 'ring-1 ring-accent' : ''}`}
            >
              {v}
            </button>
          );
        })}
      </div>
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  );
};

export const Toggle = ({
  active,
  onClick,
  children,
  ariaLabel,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  ariaLabel?: string;
}) => (
  <button
    type="button"
    aria-pressed={active}
    aria-label={ariaLabel}
    onClick={onClick}
    className={`rounded-xl border px-3 py-2.5 text-left text-sm transition-colors ${
      active
        ? 'border-accent bg-accent/15 text-ink'
        : 'border-line bg-surface2 text-muted hover:border-white/25 hover:text-ink'
    }`}
  >
    <span className="flex items-center gap-2">
      <span
        aria-hidden="true"
        className={`grid h-4 w-4 shrink-0 place-items-center rounded border text-[10px] ${
          active ? 'border-accent bg-accent text-night' : 'border-line'
        }`}
      >
        {active ? '✓' : ''}
      </span>
      {children}
    </span>
  </button>
);

export const Field = ({
  label,
  value,
  onChange,
  type = 'text',
  suffix,
  placeholder,
  inputMode,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  suffix?: string;
  placeholder?: string;
  inputMode?: 'numeric' | 'decimal' | 'text';
}) => {
  const id = `f-${label.replace(/\s+/g, '-').toLowerCase()}`;
  return (
    <label htmlFor={id} className="block">
      <span className="eyebrow">{label}</span>
      <span className="mt-1 flex items-center gap-2">
        <input
          id={id}
          type={type}
          inputMode={inputMode}
          value={value}
          placeholder={placeholder}
          onChange={(ev) => onChange(ev.target.value)}
          className="field"
        />
        {suffix && <span className="font-mono text-xs text-muted">{suffix}</span>}
      </span>
    </label>
  );
};
