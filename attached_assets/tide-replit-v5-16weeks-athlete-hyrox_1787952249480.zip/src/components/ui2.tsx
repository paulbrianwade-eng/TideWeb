import type { ReactNode } from 'react';

/**
 * Marca ATLAS: dos líneas de marea (una alta, una baja) que se cruzan.
 * Es el único elemento decorativo de la app y también funciona como
 * indicador de carga (ver TideLevel).
 */
export const AtlasMark = ({ className = 'h-5 w-9' }: { className?: string }) => (
  <svg viewBox="0 0 36 20" fill="none" className={className} aria-hidden="true">
    <path
      d="M1 13c4.5 0 4.5-6 9-6s4.5 6 9 6 4.5-6 9-6 4.5 6 7 6"
      stroke="#C7F000"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <path
      d="M1 18c4.5 0 4.5-3 9-3s4.5 3 9 3 4.5-3 9-3 4.5 3 7 3"
      stroke="#58E0C8"
      strokeWidth="1.5"
      strokeLinecap="round"
      opacity="0.55"
    />
  </svg>
);

export const Wordmark = ({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) => {
  const cls = size === 'lg' ? 'text-3xl' : size === 'sm' ? 'text-base' : 'text-xl';
  return (
    <span className={`font-display font-bold leading-none tracking-[0.32em] ${cls}`}>ATLAS</span>
  );
};

export const Logo = ({ compact = false }: { compact?: boolean }) => (
  <div className="flex items-center gap-2.5">
    <AtlasMark />
    <Wordmark />
    {!compact && (
      <span className="eyebrow hidden border-l border-line pl-2.5 sm:inline">
        Athletic Performance System
      </span>
    )}
  </div>
);

export type TideLoad = 'alta' | 'media' | 'baja';

/** Deriva la marea del RPE planificado: es carga, no decoración. */
export const tideLoad = (plannedRpe: string): TideLoad => {
  const nums = plannedRpe.match(/\d+/g)?.map(Number) ?? [];
  const top = nums.length ? Math.max(...nums) : 6;
  if (top >= 8) return 'alta';
  if (top >= 6) return 'media';
  return 'baja';
};

const LOAD_META: Record<TideLoad, { label: string; bars: number; color: string }> = {
  alta: { label: 'Carga alta', bars: 3, color: '#C7F000' },
  media: { label: 'Carga media', bars: 2, color: '#58E0C8' },
  baja: { label: 'Carga baja', bars: 1, color: '#A5ADB4' },
};

export const TideLevel = ({ plannedRpe, showLabel = true }: { plannedRpe: string; showLabel?: boolean }) => {
  const load = tideLoad(plannedRpe);
  const meta = LOAD_META[load];
  return (
    <span className="inline-flex items-center gap-2" title={`${meta.label} · RPE ${plannedRpe}`}>
      <span className="flex items-end gap-[3px]" aria-hidden="true">
        {[1, 2, 3].map((i) => (
          <span
            key={i}
            className="w-[3px] rounded-full"
            style={{
              height: `${4 + i * 4}px`,
              backgroundColor: i <= meta.bars ? meta.color : '#2C3238',
            }}
          />
        ))}
      </span>
      {showLabel && (
        <span className="font-mono text-[10px] uppercase tracking-[0.18em]" style={{ color: meta.color }}>
          {meta.label}
        </span>
      )}
    </span>
  );
};

export const Band = ({ label, right }: { label: string; right?: ReactNode }) => (
  <div className="band mb-1.5">
    <span className="band-label">{label}</span>
    <span className="band-rule" />
    {right && <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted">{right}</span>}
  </div>
);
