import type { SportActivity } from '../types';
import { ACTIVITY_LABEL } from '../data/program';

export { ExerciseRow, PrescriptionList, WorkoutBlockCard, BlockSheet, BlockHeader } from './workout-parts2';

/** Nota del coach: regla vertical + texto. Sin caja, para no competir con la tabla. */
export const CoachNote = ({ text, compact = false }: { text: string; compact?: boolean }) => (
  <div className={`border-l-2 border-accent pl-3 ${compact ? 'py-0.5' : 'py-1'}`}>
    <p className="eyebrow text-accent">Coach note</p>
    <p className="mt-1 text-sm leading-relaxed text-ink/90">{text}</p>
  </div>
);

export const ACTIVITIES: SportActivity[] = ['surf', 'golf', 'ski', 'running', 'gym', 'home', 'rest'];

export const ActivitySelector = ({
  value,
  onChange,
  onClear,
}: {
  value: SportActivity | null;
  onChange: (a: SportActivity) => void;
  onClear?: () => void;
}) => (
  <div>
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      {ACTIVITIES.map((a) => (
        <button
          key={a}
          type="button"
          aria-pressed={value === a}
          onClick={() => onChange(a)}
          className={`rounded-xl border px-3 py-2.5 text-sm transition-colors ${
            value === a ? 'border-accent bg-accent/15 text-ink' : 'border-line bg-surface2 text-muted hover:text-ink'
          }`}
        >
          {ACTIVITY_LABEL[a]}
        </button>
      ))}
    </div>
    <p className="mt-2 border-l-2 border-warn pl-3 text-xs text-warn">
      Esta actividad puede modificar la carga de los entrenamientos anteriores o posteriores.
    </p>
    {onClear && (
      <button type="button" onClick={onClear} className="btn-quiet mt-1">
        Restaurar el plan original
      </button>
    )}
  </div>
);
