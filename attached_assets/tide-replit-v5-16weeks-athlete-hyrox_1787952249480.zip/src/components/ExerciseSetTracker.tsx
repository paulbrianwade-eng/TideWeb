import { useState } from 'react';
import { Check, Info, Repeat, SkipForward } from 'lucide-react';
import type { CompletedSet, ExercisePrescription } from '../types';
import { getExercise, videoUrl } from '../data/exercises';
import { describePrescription, unitLabel } from '../lib/prescription';

export const ExerciseSetTracker = ({
  prescription,
  setCount,
  rows,
  skipped,
  substitution,
  onSetChange,
  onCompleteAll,
  onSkip,
  onSubstitute,
  onRest,
}: {
  prescription: ExercisePrescription;
  setCount: number;
  rows: CompletedSet[];
  skipped: boolean;
  substitution?: string;
  onSetChange: (index: number, value: CompletedSet) => void;
  onCompleteAll: () => void;
  onSkip: () => void;
  onSubstitute: (name: string) => void;
  onRest: () => void;
}) => {
  const ex = getExercise(prescription.exerciseId);
  const [showTech, setShowTech] = useState(false);
  const [showSub, setShowSub] = useState(false);

  const alternatives = prescription.alternatives ?? [
    ex.regression,
    ex.progression,
    'Variante con mancuernas',
    'Variante con banda',
  ];

  return (
    <div className="space-y-3">
      <div>
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h3 className="font-display text-xl leading-tight">{substitution ?? ex.name}</h3>
            <p className="font-mono text-[11px] text-muted">{describePrescription(prescription)}</p>
          </div>
          <span className="shrink-0 rounded-full border border-line bg-surface2 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.12em] text-muted">
            {unitLabel(prescription)}
          </span>
        </div>
        {substitution && (
          <p className="mt-1 text-xs text-warn">Sustituido · original: {ex.name}</p>
        )}
        <p className="mt-2 text-sm leading-relaxed text-muted">
          {prescription.instructions ?? ex.cues[0]}
        </p>
      </div>

      {skipped ? (
        <div className="rounded-xl border border-line bg-surface2 p-3 text-sm text-muted">
          Ejercicio salteado.{' '}
          <button type="button" onClick={onSkip} className="text-accent underline">
            Deshacer
          </button>
        </div>
      ) : (
        <ul className="space-y-2">
          {Array.from({ length: setCount }, (_, i) => {
            const row = rows[i] ?? { done: false };
            return (
              <li
                key={i}
                className={`grid grid-cols-[2.2rem_1fr_1fr_3rem] items-center gap-2 rounded-xl border p-2 ${
                  row.done ? 'border-accent/40 bg-accent/10' : 'border-line bg-surface2'
                }`}
              >
                <span className="text-center font-mono text-xs text-muted">{i + 1}</span>
                <label className="block">
                  <span className="sr-only">{`Serie ${i + 1}: carga en kg`}</span>
                  <input
                    inputMode="decimal"
                    placeholder="kg"
                    value={row.load ?? ''}
                    onChange={(e) => onSetChange(i, { ...row, load: e.target.value })}
                    className="w-full rounded-lg border border-line bg-base px-2 py-2.5 text-center font-mono text-sm"
                  />
                </label>
                <label className="block">
                  <span className="sr-only">{`Serie ${i + 1}: ${unitLabel(prescription).toLowerCase()}`}</span>
                  <input
                    inputMode="numeric"
                    placeholder={prescription.isometric ? 'seg' : prescription.carry ? 'm' : 'reps'}
                    value={row.reps ?? ''}
                    onChange={(e) => onSetChange(i, { ...row, reps: e.target.value })}
                    className="w-full rounded-lg border border-line bg-base px-2 py-2.5 text-center font-mono text-sm"
                  />
                </label>
                <button
                  type="button"
                  aria-label={`Marcar serie ${i + 1} como completada`}
                  aria-pressed={row.done}
                  onClick={() => {
                    onSetChange(i, { ...row, done: !row.done });
                    if (!row.done) onRest();
                  }}
                  className={`grid h-11 place-items-center rounded-lg border ${
                    row.done ? 'border-accent bg-accent text-night' : 'border-line bg-base text-muted'
                  }`}
                >
                  <Check className="h-4 w-4" aria-hidden="true" />
                </button>
              </li>
            );
          })}
        </ul>
      )}

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <button type="button" onClick={onCompleteAll} className="btn-ghost">
          <Check className="h-4 w-4" aria-hidden="true" /> Completado
        </button>
        <button type="button" onClick={onSkip} className="btn-ghost">
          <SkipForward className="h-4 w-4" aria-hidden="true" /> Saltar
        </button>
        <button type="button" onClick={() => setShowSub((s) => !s)} aria-expanded={showSub} className="btn-ghost">
          <Repeat className="h-4 w-4" aria-hidden="true" /> Sustituir
        </button>
        <button type="button" onClick={() => setShowTech((s) => !s)} aria-expanded={showTech} className="btn-ghost">
          <Info className="h-4 w-4" aria-hidden="true" /> Ver técnica
        </button>
      </div>

      {showSub && (
        <div className="rounded-xl border border-line bg-surface2 p-3">
          <p className="eyebrow mb-2">Sustituir por</p>
          <div className="grid gap-2 sm:grid-cols-2">
            {alternatives.filter(Boolean).map((alt) => (
              <button
                key={alt}
                type="button"
                onClick={() => {
                  onSubstitute(alt);
                  setShowSub(false);
                }}
                className="rounded-lg border border-line bg-base px-3 py-2 text-left text-sm hover:border-accent/60"
              >
                {alt}
              </button>
            ))}
          </div>
          {substitution && (
            <button
              type="button"
              onClick={() => {
                onSubstitute('');
                setShowSub(false);
              }}
              className="btn-quiet mt-2"
            >
              Volver al ejercicio original
            </button>
          )}
        </div>
      )}

      {showTech && (
        <div className="space-y-3 rounded-xl border border-line bg-surface2 p-3 text-sm">
          <div>
            <p className="eyebrow">Objetivo</p>
            <p className="mt-1 text-ink/90">{ex.objective}</p>
          </div>
          <a href={videoUrl(ex)} target="_blank" rel="noreferrer" className="btn-ghost w-full">
            Ver video de técnica
          </a>
          <div>
            <p className="eyebrow">Indicaciones</p>
            <ul className="mt-1 space-y-1">
              {ex.cues.map((c) => (
                <li key={c} className="flex gap-2">
                  <span aria-hidden="true" className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-accent" />
                  {c}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="eyebrow">Errores frecuentes</p>
            <p className="mt-1 text-muted">{ex.mistakes.join(' · ')}</p>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <div>
              <p className="eyebrow">Regresión</p>
              <p className="mt-1 text-muted">{ex.regression}</p>
            </div>
            <div>
              <p className="eyebrow">Progresión</p>
              <p className="mt-1 text-muted">{ex.progression}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
