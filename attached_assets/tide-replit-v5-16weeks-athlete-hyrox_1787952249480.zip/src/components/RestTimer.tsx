import { useEffect, useRef, useState } from 'react';
import { Pause, Play, Plus, TimerReset, X } from 'lucide-react';

export const parseRestSeconds = (rest?: string): number => {
  if (!rest) return 60;
  const min = rest.match(/(\d+)\s*min/);
  if (min) return Number(min[1]) * 60;
  const sec = rest.match(/(\d+)\s*s/);
  if (sec) return Number(sec[1]);
  return 60;
};

export const RestTimer = ({
  seconds,
  onDone,
  onClose,
}: {
  seconds: number;
  onDone?: () => void;
  onClose: () => void;
}) => {
  const [left, setLeft] = useState(seconds);
  const [running, setRunning] = useState(true);
  const doneRef = useRef(false);

  useEffect(() => {
    setLeft(seconds);
    setRunning(true);
    doneRef.current = false;
  }, [seconds]);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => {
      setLeft((v) => {
        if (v <= 1) {
          window.clearInterval(id);
          if (!doneRef.current) {
            doneRef.current = true;
            onDone?.();
          }
          return 0;
        }
        return v - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [running, onDone]);

  const pct = seconds === 0 ? 0 : (seconds - left) / seconds;
  const mm = String(Math.floor(left / 60)).padStart(2, '0');
  const ss = String(left % 60).padStart(2, '0');

  return (
    <div
      role="timer"
      aria-live="polite"
      aria-label={`Descanso: quedan ${mm}:${ss}`}
      className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface/95 px-4 pb-[calc(env(safe-area-inset-bottom)+12px)] pt-3 backdrop-blur no-print"
    >
      <div className="mx-auto flex max-w-3xl items-center gap-3">
        <div className="flex-1">
          <div className="flex items-baseline justify-between">
            <p className="eyebrow">Descanso</p>
            <p className={`font-mono text-2xl ${left === 0 ? 'text-accent' : ''}`}>
              {mm}:{ss}
            </p>
          </div>
          <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-surface2">
            <div className="h-full rounded-full bg-accent transition-all" style={{ width: `${pct * 100}%` }} />
          </div>
        </div>
        <button
          type="button"
          onClick={() => setRunning((r) => !r)}
          aria-label={running ? 'Pausar descanso' : 'Reanudar descanso'}
          className="btn-ghost px-3 py-3"
        >
          {running ? <Pause className="h-4 w-4" aria-hidden="true" /> : <Play className="h-4 w-4" aria-hidden="true" />}
        </button>
        <button
          type="button"
          onClick={() => setLeft((v) => v + 30)}
          aria-label="Sumar 30 segundos"
          className="btn-ghost px-3 py-3"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          30
        </button>
        <button
          type="button"
          onClick={() => setLeft(seconds)}
          aria-label="Reiniciar descanso"
          className="btn-ghost px-3 py-3"
        >
          <TimerReset className="h-4 w-4" aria-hidden="true" />
        </button>
        <button type="button" onClick={onClose} aria-label="Cerrar temporizador" className="btn-ghost px-3 py-3">
          <X className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
};
