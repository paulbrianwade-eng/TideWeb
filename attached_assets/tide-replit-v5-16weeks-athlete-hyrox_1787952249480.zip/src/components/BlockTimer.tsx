import { useEffect, useRef, useState } from 'react';
import { Pause, Play, RotateCcw } from 'lucide-react';

const fmt = (sec:number) => `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;
const parseMinutes = (s:string) => {
  const m=s.match(/(\d+)\s*min/i);
  return m ? Number(m[1]) : 0;
};

export const BlockTimer = ({ kind, duration }: { kind: 'transition' | 'finisher'; duration: string }) => {
  const initial = kind === 'finisher' ? parseMinutes(duration) * 60 : 0;
  const [seconds,setSeconds]=useState(initial);
  const [running,setRunning]=useState(false);
  const runningRef=useRef(running);
  runningRef.current=running;

  useEffect(()=>{
    if(!running) return;
    const id=window.setInterval(()=>{
      setSeconds(v=>{
        if(kind==='finisher') {
          if(v<=1){ setRunning(false); return 0; }
          return v-1;
        }
        return v+1;
      });
    },1000);
    return ()=>window.clearInterval(id);
  },[running,kind]);

  const reset=()=>{ setRunning(false); setSeconds(initial); };
  return (
    <div className="card flex items-center justify-between gap-3 p-4">
      <div>
        <p className="eyebrow">{kind==='finisher'?'Timer del finisher':'Cronómetro de vuelta'}</p>
        <p className="mt-1 font-mono text-3xl font-semibold tracking-tight">{fmt(seconds)}</p>
      </div>
      <div className="flex gap-2">
        <button type="button" className="btn-ghost px-3" onClick={()=>setRunning(v=>!v)} aria-label={running?'Pausar':'Iniciar'}>
          {running?<Pause className="h-4 w-4"/>:<Play className="h-4 w-4"/>}
        </button>
        <button type="button" className="btn-ghost px-3" onClick={reset} aria-label="Reiniciar timer">
          <RotateCcw className="h-4 w-4"/>
        </button>
      </div>
    </div>
  );
};
