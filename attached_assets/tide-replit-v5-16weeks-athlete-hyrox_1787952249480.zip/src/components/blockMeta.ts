import { Activity, ArrowRight, Dumbbell, Flame, Moon, Shield, Waves, Wind, Zap, Bike } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { BlockKind } from '../types';

export interface BlockMeta { label: string; icon: LucideIcon; color: string; ring: string; text: string; }
export const BLOCK_META: Record<BlockKind, BlockMeta> = {
  core: { label: 'Zona media', icon: Shield, color: '#B8FF72', ring: 'border-[#B8FF72]', text: 'text-[#087F5B]' },
  strength: { label: 'Fuerza', icon: Dumbbell, color: '#087F5B', ring: 'border-[#087F5B]/40', text: 'text-[#087F5B]' },
  transition: { label: 'Vuelta', icon: ArrowRight, color: '#E9FFD7', ring: 'border-[#B8FF72]', text: 'text-[#087F5B]' },
  athletic: { label: 'Atleta', icon: Zap, color: '#B8FF72', ring: 'border-[#B8FF72]', text: 'text-[#087F5B]' },
  finisher: { label: 'Finisher', icon: Flame, color: '#087F5B', ring: 'border-[#087F5B]/40', text: 'text-[#087F5B]' },
  movement: { label: 'Movement', icon: Waves, color: '#B8FF72', ring: 'border-[#B8FF72]', text: 'text-[#087F5B]' },
  recovery: { label: 'Recovery', icon: Moon, color: '#A5ADB4', ring: 'border-[#A5ADB4]/30', text: 'text-muted' },
  reset: { label: 'Reset', icon: Wind, color: '#E9FFD7', ring: 'border-[#DDE2DC]', text: 'text-[#087F5B]' },
  power: { label: 'Power', icon: Zap, color: '#B8FF72', ring: 'border-[#B8FF72]', text: 'text-[#087F5B]' },
  engine: { label: 'Engine', icon: Bike, color: '#087F5B', ring: 'border-[#087F5B]/40', text: 'text-[#087F5B]' },
};
