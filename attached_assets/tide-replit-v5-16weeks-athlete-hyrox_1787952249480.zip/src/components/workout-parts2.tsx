import { Fragment } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import type { ExercisePrescription, WorkoutBlock } from '../types';
import { BLOCK_META } from './blockMeta';
import { getExercise } from '../data/exercises';
import { intensityText, sideText, volumeText } from '../lib/prescription';
import { ModuleBadge } from './ModuleBadge';

/**
 * Fila tabular: tag · ejercicio · volumen / intensidad.
 * El tag es corto por contrato (A1, B, E3); los subgrupos van como encabezado
 * de grupo, no dentro de la fila, para que nunca pisen el nombre.
 */
export const ExerciseRow = ({
  p,
  name,
  dense = false,
  withTagColumn = true,
}: {
  p: ExercisePrescription;
  name?: string;
  dense?: boolean;
  withTagColumn?: boolean;
}) => {
  const ex = getExercise(p.exerciseId);
  const side = sideText(p);
  const intensity = intensityText(p);
  return (
    <div
      className="grid items-baseline gap-x-3 border-b border-line/60 py-2.5 last:border-b-0"
      style={{ gridTemplateColumns: withTagColumn ? '1.75rem minmax(0,1fr) auto' : 'minmax(0,1fr) auto' }}
    >
      {withTagColumn && (
        <span className="truncate font-mono text-[11px] leading-5 text-accent">{p.order ?? ''}</span>
      )}
      <span className="min-w-0">
        <span className="block text-sm font-medium leading-5 text-ink">{name ?? ex.name}</span>
        {!dense && (p.instructions || side) && (
          <span className="mt-0.5 block text-xs leading-snug text-muted">
            {side && <span className="mr-1.5 font-mono uppercase tracking-[0.12em] text-muted/80">{side}</span>}
            {p.instructions}
          </span>
        )}
      </span>
      <span className="shrink-0 whitespace-nowrap text-right">
        <span className="block font-mono text-sm leading-5 text-ink">{volumeText(p)}</span>
        {intensity && <span className="block font-mono text-[11px] text-muted">{intensity}</span>}
      </span>
    </div>
  );
};

/** Lista de prescripciones con encabezados de subgrupo (Circuito, Finisher…). */
export const PrescriptionList = ({
  block,
  dense = false,
}: {
  block: WorkoutBlock;
  dense?: boolean;
}) => {
  const withTagColumn = block.items.some((i) => i.order);
  let lastGroup: string | undefined;

  return (
    <div>
      {block.items.map((item, i) => {
        const showGroup = item.group && item.group !== lastGroup;
        lastGroup = item.group;
        return (
          <Fragment key={`${block.id}-${i}`}>
            {showGroup && (
              <p className="mt-2 pb-1 font-mono text-[10px] uppercase tracking-[0.2em] text-muted">
                {item.group}
              </p>
            )}
            <ExerciseRow p={item} dense={dense} withTagColumn={withTagColumn} />
          </Fragment>
        );
      })}
    </div>
  );
};

export const BlockHeader = ({ block }: { block: WorkoutBlock }) => {
  const meta = BLOCK_META[block.kind];
  const Icon = meta.icon;
  return (
    <div className="flex items-center gap-2.5">
      <span
        aria-hidden="true"
        className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border"
        style={{ borderColor: `${meta.color}55`, backgroundColor: `${meta.color}14` }}
      >
        <Icon className="h-4 w-4" style={{ color: meta.color }} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2">
          <span className="font-display text-base font-semibold leading-tight text-ink">{block.title}</span>
          {block.module && <ModuleBadge module={block.module} size="sm" />}
        </span>
        <span className="block truncate text-xs text-muted">
          {block.rounds ? `${block.rounds} · ` : ''}
          {block.focus}
        </span>
      </span>
      <span className="shrink-0 font-mono text-[11px] text-muted">{block.duration}</span>
    </div>
  );
};

export const WorkoutBlockCard = ({
  block,
  onOpen,
  onToggle,
  progress,
  expanded = false,
}: {
  block: WorkoutBlock;
  onOpen?: () => void;
  /** Si se pasa, el encabezado despliega/pliega en vez de abrir la sesión. */
  onToggle?: () => void;
  progress?: number;
  expanded?: boolean;
}) => {
  const meta = BLOCK_META[block.kind];

  const bar =
    progress !== undefined ? (
      <div className="mt-3 h-1 w-full overflow-hidden rounded-full bg-surface2">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${Math.round(progress * 100)}%`, backgroundColor: meta.color }}
        />
      </div>
    ) : null;

  // Modo plegable: el encabezado abre y cierra la tabla del bloque.
  if (onToggle) {
    return (
      <div className="card p-4">
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={expanded}
          className="flex w-full items-center gap-2 text-left"
        >
          <span className="min-w-0 flex-1">
            <BlockHeader block={block} />
          </span>
          {expanded ? (
            <ChevronDown className="h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
          ) : (
            <ChevronRight className="h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
          )}
        </button>
        {expanded ? (
          <div className="mt-3">
            <PrescriptionList block={block} dense />
          </div>
        ) : (
          <p className="mt-2 truncate text-xs text-muted/80">
            {block.items.map((i) => getExercise(i.exerciseId).name).join(' · ')}
          </p>
        )}
        {bar}
      </div>
    );
  }

  if (expanded) {
    return (
      <div className="card p-4">
        {onOpen ? (
          <button
            type="button"
            onClick={onOpen}
            className="flex w-full items-center gap-2 text-left"
            aria-label={`Abrir el bloque ${block.title}`}
          >
            <span className="min-w-0 flex-1">
              <BlockHeader block={block} />
            </span>
            <ChevronRight className="h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
          </button>
        ) : (
          <BlockHeader block={block} />
        )}
        <div className="mt-3">
          <PrescriptionList block={block} dense />
        </div>
        {bar}
      </div>
    );
  }

  const compact = (
    <>
      <BlockHeader block={block} />
      <p className="mt-2 truncate text-xs text-muted/80">
        {block.items.map((i) => getExercise(i.exerciseId).name).join(' · ')}
      </p>
      {bar}
    </>
  );

  return onOpen ? (
    <button type="button" onClick={onOpen} className="card w-full p-4 text-left transition-colors hover:border-white/20">
      {compact}
    </button>
  ) : (
    <div className="card p-4">{compact}</div>
  );
};

/** Bloque en formato "hoja de rutina": banda + tabla. One Pager y Daily Card. */
export const BlockSheet = ({ block }: { block: WorkoutBlock }) => {
  const meta = BLOCK_META[block.kind];
  return (
    <section>
      <div className="band mb-1">
        <span className="band-label" style={{ color: meta.color }}>
          {block.title}
        </span>
        <span className="band-rule" />
        <span className="shrink-0 font-mono text-[10px] uppercase tracking-[0.18em] text-muted">
          {block.rounds ? `${block.rounds} · ` : ''}
          {block.duration}
        </span>
      </div>
      {block.module && (
        <p className="mb-1.5">
          <ModuleBadge module={block.module} size="sm" />
        </p>
      )}
      {block.rest && <p className="mb-1 font-mono text-[11px] text-muted">Descanso {block.rest}</p>}
      <PrescriptionList block={block} />
    </section>
  );
};
