import { useState } from 'react';
import { SlidersHorizontal } from 'lucide-react';
import type { DailyReadiness, Workout } from '../types';
import { ADJUSTMENTS, computeAdaptation } from '../lib/adaptations';
import { Card, ScaleSelector, SectionTitle, Toggle } from './ui';

export const ReadinessSelector = ({
  readiness,
  onChange,
}: {
  readiness: DailyReadiness;
  onChange: (p: Partial<DailyReadiness>) => void;
}) => (
  <Card className="space-y-4">
    <SectionTitle eyebrow="Antes de entrenar" title="Cómo llegás hoy" />
    <ScaleSelector label="Energía" value={readiness.energy} onChange={(v) => onChange({ energy: v })} />
    <ScaleSelector label="Sueño" value={readiness.sleep} onChange={(v) => onChange({ sleep: v })} />
    <ScaleSelector
      label="Dolor"
      value={readiness.pain}
      onChange={(v) => onChange({ pain: v })}
      min={0}
      hint="0 = sin molestias"
    />
    <ScaleSelector label="Motivación" value={readiness.motivation} onChange={(v) => onChange({ motivation: v })} />
  </Card>
);

const GROUP_TITLE: Record<string, string> = {
  estado: 'Cómo estás',
  'mañana': 'Qué hacés mañana',
  contexto: 'Contexto y equipamiento',
};

export const AdaptiveSessionPanel = ({
  selected,
  onChange,
  readiness,
  workout,
}: {
  selected: string[];
  onChange: (ids: string[]) => void;
  readiness: DailyReadiness;
  workout: Workout | null;
}) => {
  const [open, setOpen] = useState(selected.length > 0);
  const result = computeAdaptation(selected, readiness, workout);

  const toggle = (id: string) =>
    onChange(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id]);

  return (
    <Card className="space-y-3">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-3 text-left"
      >
        <span>
          <span className="eyebrow block">Adaptación</span>
          <span className="font-display text-lg">Ajustar sesión</span>
        </span>
        <span className="btn-ghost">
          <SlidersHorizontal className="h-4 w-4" aria-hidden="true" />
          {open ? 'Cerrar' : selected.length ? `${selected.length} activos` : 'Abrir'}
        </span>
      </button>

      {open && (
        <div className="space-y-4">
          {(['estado', 'mañana', 'contexto'] as const).map((group) => (
            <div key={group}>
              <p className="eyebrow mb-2">{GROUP_TITLE[group]}</p>
              <div className="grid gap-2 sm:grid-cols-2">
                {ADJUSTMENTS.filter((a) => a.group === group).map((a) => (
                  <Toggle key={a.id} active={selected.includes(a.id)} onClick={() => toggle(a.id)}>
                    {a.label}
                  </Toggle>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="rounded-xl border border-line bg-surface2 p-3">
        <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-accent">{result.headline}</p>
        {result.notes.length > 0 ? (
          <ul className="mt-2 space-y-1.5">
            {result.notes.map((n) => (
              <li key={n} className="flex gap-2 text-sm text-ink/90">
                <span aria-hidden="true" className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-accent" />
                {n}
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-1 text-sm text-muted">
            Marcá lo que aplique y ATLAS ajusta volumen, RPE y sustituciones.
          </p>
        )}
      </div>
    </Card>
  );
};
