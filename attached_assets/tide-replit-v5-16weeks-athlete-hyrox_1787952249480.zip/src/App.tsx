import { useEffect, useState } from 'react';
import { AppProvider, useApp } from './state/AppContext';
import { AppShell } from './components/AppShell';
import type { Screen } from './components/AppShell';
import { TodayScreen } from './screens/TodayScreen';
import { CalendarScreen } from './screens/CalendarScreen';
import { ProgressScreen } from './screens/ProgressScreen';
import { NutritionScreen } from './screens/NutritionScreen';
import { LibraryScreen } from './screens/LibraryScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { SessionScreen } from './screens/SessionScreen';
import { OnePagerView } from './components/OnePagerView';
import type { Workout } from './types';

const withExtras = (workout: Workout, extras: string[]): Workout => {
  if (extras.length === 0) return workout;
  return {
    ...workout,
    blocks: [
      ...workout.blocks,
      {
        id: `${workout.id}-extras`,
        kind: 'strength',
        title: 'Extra',
        duration: 'A elección',
        focus: 'Agregado desde la biblioteca',
        items: extras.map((id) => ({ exerciseId: id, sets: 3, reps: '10' })),
      },
    ],
  };
};

const Router = () => {
  const app = useApp();
  const [screen, setScreen] = useState<Screen | 'settings'>(
    (app.state.lastScreen as Screen) ?? 'today',
  );
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [sessionBlock, setSessionBlock] = useState<number | undefined>(undefined);
  const [onePagerId, setOnePagerId] = useState<string | null>(null);

  useEffect(() => {
    if (screen !== 'settings') app.setScreen(screen);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen]);

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [screen, sessionId, onePagerId]);

  const findWorkout = (id: string | null) => app.program.find((w) => w.id === id) ?? null;

  const openSession = (workoutId: string, blockIndex?: number) => {
    setSessionBlock(blockIndex);
    setSessionId(workoutId);
  };

  const sessionWorkout = findWorkout(sessionId);
  if (sessionWorkout) {
    const extras = app.state.extras[sessionWorkout.date] ?? [];
    return (
      <SessionScreen
        workout={withExtras(sessionWorkout, extras)}
        initialBlockIndex={sessionBlock}
        onExit={() => {
          setSessionId(null);
          setSessionBlock(undefined);
        }}
      />
    );
  }

  const onePagerWorkout = findWorkout(onePagerId);
  if (onePagerWorkout) {
    return <OnePagerView workout={onePagerWorkout} onBack={() => setOnePagerId(null)} />;
  }

  const navigate = (s: Screen | 'settings') => setScreen(s);

  return (
    <AppShell screen={screen === 'settings' ? 'today' : screen} onNavigate={navigate}>
      {screen === 'today' && <TodayScreen onStart={openSession} onOnePager={setOnePagerId} />}
      {screen === 'calendar' && <CalendarScreen onStart={openSession} onOnePager={setOnePagerId} />}
      {screen === 'progress' && <ProgressScreen />}
      {screen === 'nutrition' && <NutritionScreen />}
      {screen === 'library' && <LibraryScreen />}
      {screen === 'settings' && <SettingsScreen onBack={() => setScreen('today')} />}
    </AppShell>
  );
};

export const App = () => (
  <AppProvider>
    <Router />
  </AppProvider>
);

export default App;
