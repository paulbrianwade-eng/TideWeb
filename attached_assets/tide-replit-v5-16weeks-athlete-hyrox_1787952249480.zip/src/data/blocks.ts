import type { ExercisePrescription, SportModule, WorkoutBlock } from '../types';

/**
 * Pools de bloques. El generador elige por semana, de modo que el Athletic
 * Block y el Power cambian todas las semanas del macrociclo de 16.
 */

const p = (
  exerciseId: string,
  extra: Partial<ExercisePrescription> = {},
): ExercisePrescription => ({ exerciseId, ...extra });

// ─────────────────────────── RESET ───────────────────────────
export const RESET_FLOWS: ExercisePrescription[][] = [
  [
    p('nasal-breathing', { duration: '2 min', instructions: 'Inhalar 4 s · exhalar 6 s.' }),
    p('cat-cow', { reps: '10' }),
    p('foot-activation', { duration: '60 s', instructions: 'Descalzo si podés.' }),
  ],
  [
    p('nasal-breathing', { duration: '2 min' }),
    p('foam-roller', { duration: '4 min', instructions: 'Cuádriceps, glúteo y dorsal.' }),
    p('foot-activation', { duration: '60 s' }),
  ],
  [
    p('nasal-breathing', { duration: '2 min' }),
    p('hip-flow', { duration: '3 min' }),
    p('foot-activation', { duration: '60 s' }),
  ],
];

// ─────────────────────────── MOVEMENT QUALITY ───────────────────────────
export const MOVEMENT_FLOWS: ExercisePrescription[][] = [
  [
    p('hip-cars', { reps: '3', unilateral: true, duration: '20 s cada uno' }),
    p('hip-9090', { reps: '8 cambios' }),
    p('worlds-greatest-stretch', { reps: '5', unilateral: true }),
    p('dead-bug', { sets: 2, reps: '10', unilateral: true }),
  ],
  [
    p('shoulder-cars', { reps: '3', unilateral: true }),
    p('open-book', { reps: '8', unilateral: true }),
    p('scapular-push-up', { sets: 2, reps: '10' }),
    p('bear-crawl', { distance: '10 m', instructions: 'Adelante y atrás, cadera quieta.' }),
  ],
  [
    p('shin-box', { sets: 2, reps: '6', unilateral: true }),
    p('thoracic-rotation', { reps: '8', unilateral: true }),
    p('bird-dog', { sets: 2, reps: '8', unilateral: true }),
    p('monster-walk', { reps: '15 pasos', unilateral: true }),
  ],
  [
    p('jefferson-curl', { sets: 3, reps: '5', load: 'Carga muy liviana' }),
    p('hip-flow', { duration: '2 min' }),
    p('deep-squat-hold', { duration: '45 s', isometric: true }),
    p('dead-bug', { sets: 2, reps: '10', unilateral: true }),
  ],
];

// ─────────────────────────── POWER ───────────────────────────
export const POWER_MENUS: { focus: string; items: string[] }[] = [
  { focus: 'Vertical y rotacional', items: ['box-jump', 'rotational-mb-throw'] },
  { focus: 'Horizontal y lateral', items: ['broad-jump', 'lateral-bound'] },
  { focus: 'Balístico y global', items: ['mb-slam', 'push-press'] },
  { focus: 'Triple extensión', items: ['hang-clean', 'pogo-jump'] },
  { focus: 'Lateral y reactivo', items: ['skater-jump', 'rotational-mb-throw'] },
  { focus: 'Vertical y empuje', items: ['box-jump', 'push-press'] },
  { focus: 'Horizontal y elástico', items: ['bounding', 'broad-jump'] },
  { focus: 'Rotacional y balístico', items: ['rotational-mb-throw', 'mb-slam'] },
];

// ─────────────────────────── ATHLETIC BLOCK ───────────────────────────
/** 16 circuitos, uno por semana. Siempre core + antirrotación + carry + plano frontal + unilateral + tendón. */
export const ATHLETIC_CIRCUITS: { name: string; rounds: string; rest: string; items: ExercisePrescription[] }[] = [
  {
    name: 'Base atlética',
    rounds: '3 rondas',
    rest: '60 s',
    items: [
      p('single-leg-rdl', { reps: '8', unilateral: true, load: 'Peso moderado' }),
      p('pallof-press', { reps: '10', unilateral: true, instructions: 'Pausa de 2 s en extensión.' }),
      p('suitcase-carry', { distance: '25 m', unilateral: true, carry: true }),
      p('copenhagen-plank', { duration: '20–25 s', unilateral: true, isometric: true }),
    ],
  },
  {
    name: 'Plano frontal',
    rounds: '3 rondas',
    rest: '60 s',
    items: [
      p('lateral-lunge', { reps: '8', unilateral: true }),
      p('side-plank', { duration: '30 s', unilateral: true, isometric: true }),
      p('single-arm-farmer', { distance: '25 m', unilateral: true, carry: true }),
      p('tibialis-raise', { reps: '20' }),
    ],
  },
  {
    name: 'Control rotacional',
    rounds: '3 rondas',
    rest: '75 s',
    items: [
      p('landmine-rotation', { reps: '8', unilateral: true }),
      p('bear-crawl', { distance: '10 m' }),
      p('waiter-carry', { distance: '20 m', unilateral: true, carry: true }),
      p('soleus-raise', { reps: '20' }),
    ],
  },
  {
    name: 'Descarga · calidad',
    rounds: '2 rondas',
    rest: '90 s',
    items: [
      p('hip-airplane', { reps: '6', unilateral: true }),
      p('dead-bug', { reps: '10', unilateral: true }),
      p('farmer-carry', { distance: '30 m', carry: true, load: 'Moderado' }),
      p('single-leg-balance', { duration: '30 s', unilateral: true, isometric: true }),
    ],
  },
  {
    name: 'Unipodal cargado',
    rounds: '3 rondas',
    rest: '75 s',
    items: [
      p('step-down', { reps: '8', unilateral: true, instructions: 'Bajada de 3 s.' }),
      p('pallof-press', { reps: '10', unilateral: true }),
      p('bottom-up-carry', { distance: '20 m', unilateral: true, carry: true }),
      p('nordic-curl', { reps: '5', instructions: 'Excéntrico lento.' }),
    ],
  },
  {
    name: 'Antirrotación pesada',
    rounds: '3 rondas',
    rest: '75 s',
    items: [
      p('suitcase-carry', { distance: '30 m', unilateral: true, carry: true, load: 'Desafiante' }),
      p('cable-chop', { reps: '10', unilateral: true }),
      p('copenhagen-plank', { duration: '25 s', unilateral: true, isometric: true }),
      p('tibialis-raise', { reps: '20' }),
    ],
  },
  {
    name: 'Tendón y pie',
    rounds: '3 rondas',
    rest: '60 s',
    items: [
      p('soleus-raise', { reps: '20', instructions: 'Tempo 2-1-2.' }),
      p('single-leg-balance', { duration: '30 s', unilateral: true, isometric: true }),
      p('single-arm-farmer', { distance: '25 m', unilateral: true, carry: true }),
      p('side-plank', { duration: '30 s', unilateral: true, isometric: true }),
    ],
  },
  {
    name: 'Descarga · movilidad cargada',
    rounds: '2 rondas',
    rest: '90 s',
    items: [
      p('cossack-squat', { reps: '6', unilateral: true }),
      p('bird-dog', { reps: '8', unilateral: true }),
      p('waiter-carry', { distance: '20 m', unilateral: true, carry: true }),
      p('foot-activation', { duration: '60 s' }),
    ],
  },
  {
    name: 'Reactividad lateral',
    rounds: '4 rondas',
    rest: '75 s',
    items: [
      p('skater-jump', { duration: '20 s' }),
      p('side-plank', { duration: '30 s', unilateral: true, isometric: true }),
      p('single-arm-farmer', { distance: '25 m', unilateral: true, carry: true }),
      p('tibialis-raise', { reps: '20' }),
    ],
  },
  {
    name: 'Potencia rotacional aplicada',
    rounds: '3 rondas',
    rest: '75 s',
    items: [
      p('landmine-rotation', { reps: '8', unilateral: true }),
      p('single-leg-rdl', { reps: '8', unilateral: true }),
      p('bottom-up-carry', { distance: '20 m', unilateral: true, carry: true }),
      p('copenhagen-plank', { duration: '25 s', unilateral: true, isometric: true }),
    ],
  },
  {
    name: 'Desaceleración',
    rounds: '3 rondas',
    rest: '90 s',
    items: [
      p('step-down', { reps: '8', unilateral: true, instructions: 'Bajada de 5 s.' }),
      p('lateral-bound', { reps: '5', unilateral: true, instructions: 'Sostener 1 s el aterrizaje.' }),
      p('pallof-press', { reps: '10', unilateral: true }),
      p('nordic-curl', { reps: '5' }),
    ],
  },
  {
    name: 'Descarga · equilibrio',
    rounds: '2 rondas',
    rest: '90 s',
    items: [
      p('hip-airplane', { reps: '6', unilateral: true }),
      p('single-leg-balance', { duration: '40 s', unilateral: true, isometric: true }),
      p('farmer-carry', { distance: '30 m', carry: true }),
      p('dead-bug', { reps: '10', unilateral: true }),
    ],
  },
  {
    name: 'Transferencia esquí',
    rounds: '4 rondas',
    rest: '75 s',
    items: [
      p('split-squat-hold', { duration: '30 s', unilateral: true, isometric: true }),
      p('lateral-lunge', { reps: '8', unilateral: true }),
      p('single-arm-farmer', { distance: '25 m', unilateral: true, carry: true }),
      p('copenhagen-plank', { duration: '30 s', unilateral: true, isometric: true }),
    ],
  },
  {
    name: 'Transferencia surf',
    rounds: '3 rondas',
    rest: '75 s',
    items: [
      p('bear-crawl', { distance: '15 m' }),
      p('bottom-up-carry', { distance: '20 m', unilateral: true, carry: true }),
      p('ytwl', { reps: '8 de cada letra', load: 'Muy liviano' }),
      p('side-plank', { duration: '35 s', unilateral: true, isometric: true }),
    ],
  },
  {
    name: 'Transferencia golf',
    rounds: '3 rondas',
    rest: '75 s',
    items: [
      p('cable-lift', { reps: '10', unilateral: true }),
      p('hip-airplane', { reps: '6', unilateral: true }),
      p('suitcase-carry', { distance: '25 m', unilateral: true, carry: true }),
      p('single-leg-rdl', { reps: '8', unilateral: true }),
    ],
  },
  {
    name: 'Descarga · cierre de ciclo',
    rounds: '2 rondas',
    rest: '90 s',
    items: [
      p('single-leg-balance', { duration: '40 s', unilateral: true, isometric: true }),
      p('pallof-press', { reps: '10', unilateral: true }),
      p('farmer-carry', { distance: '30 m', carry: true }),
      p('soleus-raise', { reps: '20' }),
    ],
  },
];

// ─────────────────────────── ENGINE ───────────────────────────
export const ENGINE_SESSIONS: Record<string, { focus: string; items: ExercisePrescription[]; duration: string }> = {
  assault: {
    focus: 'Assault Bike · intervalos',
    duration: '10 min',
    items: [
      p('assault-bike-intervals', {
        sets: 10,
        duration: '20 s fuerte / 40 s suave',
        rpe: '85–90 %',
        instructions: 'Sin esfuerzos máximos. Terminá pudiendo una ronda más.',
        alternatives: ['Bicicleta estática', 'Remo', 'Cinta inclinada', 'SkiErg'],
      }),
    ],
  },
  skierg: {
    focus: 'SkiErg · umbral',
    duration: '15 min',
    items: [p('ski-erg', { sets: 8, distance: '250 m', rest: '60 s' })],
  },
  row: {
    focus: 'Remo · umbral',
    duration: '18 min',
    items: [p('row-intervals', { sets: 6, distance: '500 m', rest: '90 s' })],
  },
  zone2: {
    focus: 'Zona 2 continua',
    duration: '35–45 min',
    items: [
      p('zone2-run', {
        duration: '35–45 min',
        rpe: '5',
        instructions: 'Ritmo conversacional. Caminá 1 min si la respiración se dispara.',
        alternatives: ['Bicicleta', 'Remo', 'Caminata en pendiente'],
      }),
    ],
  },
  threshold: {
    focus: 'Umbral · series largas',
    duration: '35 min',
    items: [p('threshold-run', { sets: 4, duration: '6 min', rest: '2 min trote' })],
  },
  tempo: {
    focus: 'Tempo continuo',
    duration: '25 min',
    items: [p('tempo-run', { duration: '20–25 min', rpe: '6–7' })],
  },
  hyrox: {
    focus: 'HYROX · fatiga mixta',
    duration: '30 min',
    items: [
      p('hyrox-block', {
        sets: 4,
        distance: '800 m + estación',
        instructions: 'Estaciones: farmer carry 100 m · trineo 25 m · burpee broad jump 15 · wall ball 30.',
      }),
    ],
  },
};

// ─────────────────────────── RECOVERY ───────────────────────────
export const RECOVERY_PROTOCOLS: { name: string; items: ExercisePrescription[] }[] = [
  {
    name: 'Down regulation',
    items: [
      p('easy-walk', { duration: '3 min' }),
      p('hip-flexor-stretch', { duration: '40 s', unilateral: true, isometric: true }),
      p('down-regulation', { duration: '5 min' }),
    ],
  },
  {
    name: 'Tejido y respiración',
    items: [
      p('foam-roller', { duration: '5 min', instructions: 'Cuádriceps, glúteo, dorsal.' }),
      p('open-book', { reps: '6', unilateral: true }),
      p('nasal-breathing', { duration: '3 min', instructions: 'Inhalar 4 s · exhalar 8 s.' }),
    ],
  },
  {
    name: 'Movilidad de cierre',
    items: [
      p('hip-flow', { duration: '3 min' }),
      p('hip-flexor-stretch', { duration: '40 s', unilateral: true, isometric: true }),
      p('nasal-breathing', { duration: '2 min' }),
    ],
  },
];

// ─────────────────────────── MÓDULOS DEPORTIVOS ───────────────────────────
/**
 * Cada módulo reemplaza el trabajo accesorio del día, no se suma encima.
 * Rotan por semana para que las 16 no se repitan.
 */
export const SKI_MODULE: ExercisePrescription[][] = [
  [
    p('wall-sit', { sets: 3, duration: '45 s', isometric: true }),
    p('spanish-squat', { sets: 3, duration: '30 s', isometric: true }),
    p('lateral-lunge', { sets: 3, reps: '8', unilateral: true }),
  ],
  [
    p('split-squat-hold', { sets: 3, duration: '30 s', unilateral: true, isometric: true }),
    p('step-down', { sets: 3, reps: '8', unilateral: true, instructions: 'Bajada de 4 s.' }),
    p('soleus-raise', { sets: 3, reps: '20' }),
  ],
  [
    p('reverse-nordic', { sets: 3, reps: '6', instructions: 'Bajada de 4 s.' }),
    p('cossack-squat', { sets: 3, reps: '6', unilateral: true }),
    p('copenhagen-plank', { sets: 3, duration: '25 s', unilateral: true, isometric: true }),
  ],
  [
    p('wall-sit', { sets: 3, duration: '60–90 s', isometric: true, instructions: 'Sumá tiempo respecto de la semana 1.' }),
    p('skater-jump', { sets: 3, duration: '20 s' }),
    p('tibialis-raise', { sets: 3, reps: '20' }),
  ],
];

export const SURF_MODULE: ExercisePrescription[][] = [
  [
    p('trx-row', { sets: 3, reps: '12–15' }),
    p('ytwl', { sets: 2, reps: '8 de cada letra', load: 'Muy liviano' }),
    p('bottom-up-carry', { sets: 3, distance: '20 m', unilateral: true, carry: true }),
  ],
  [
    p('face-pull', { sets: 3, reps: '15', instructions: 'Pausa de 1 s.' }),
    p('bear-crawl', { sets: 3, distance: '15 m' }),
    p('landmine-rotation', { sets: 3, reps: '8', unilateral: true }),
  ],
  [
    p('trx-row', { sets: 3, reps: '15' }),
    p('shoulder-cars', { sets: 2, reps: '3', unilateral: true }),
    p('single-arm-farmer', { sets: 3, distance: '25 m', unilateral: true, carry: true }),
  ],
  [
    p('ytwl', { sets: 3, reps: '8 de cada letra' }),
    p('rotational-mb-throw', { sets: 3, reps: '5', unilateral: true, rest: '45 s' }),
    p('waiter-carry', { sets: 3, distance: '20 m', unilateral: true, carry: true }),
  ],
];

export const GOLF_MODULE: ExercisePrescription[][] = [
  [
    p('rotational-mb-throw', { sets: 4, reps: '5', unilateral: true, rest: '45 s', instructions: 'Máxima velocidad.' }),
    p('cable-chop', { sets: 3, reps: '10', unilateral: true }),
    p('hip-airplane', { sets: 2, reps: '6', unilateral: true }),
  ],
  [
    p('landmine-rotation', { sets: 3, reps: '8', unilateral: true }),
    p('cable-lift', { sets: 3, reps: '10', unilateral: true }),
    p('single-leg-rdl', { sets: 3, reps: '8', unilateral: true }),
  ],
  [
    p('rotational-mb-throw', { sets: 4, reps: '5', unilateral: true, rest: '45 s' }),
    p('pallof-press', { sets: 3, reps: '10', unilateral: true, instructions: 'Pausa de 2 s.' }),
    p('hip-9090', { sets: 2, reps: '8 cambios' }),
  ],
  [
    p('cable-chop', { sets: 3, reps: '10', unilateral: true }),
    p('cable-lift', { sets: 3, reps: '10', unilateral: true }),
    p('hip-airplane', { sets: 3, reps: '6', unilateral: true }),
  ],
];

export const RUNNING_MODULE: ExercisePrescription[][] = [
  [
    p('skipping', { sets: 3, distance: '20 m' }),
    p('pogo-jump', { sets: 3, reps: '20 contactos' }),
    p('soleus-raise', { sets: 3, reps: '20' }),
  ],
  [
    p('bounding', { sets: 4, distance: '20 m' }),
    p('tibialis-raise', { sets: 3, reps: '20' }),
    p('foot-activation', { sets: 2, duration: '60 s' }),
  ],
  [
    p('stride', { sets: 6, duration: '20 s', rest: 'Vuelta caminando', rpe: '85 %' }),
    p('pogo-jump', { sets: 3, reps: '20 contactos' }),
    p('single-leg-balance', { sets: 2, duration: '30 s', unilateral: true, isometric: true }),
  ],
  [
    p('skipping', { sets: 3, distance: '20 m' }),
    p('stride', { sets: 4, duration: '20 s', rest: 'Vuelta caminando' }),
    p('nordic-curl', { sets: 3, reps: '5' }),
  ],
];

export const MODULE_POOL: Record<SportModule, ExercisePrescription[][]> = {
  ski: SKI_MODULE,
  surf: SURF_MODULE,
  golf: GOLF_MODULE,
  running: RUNNING_MODULE,
};

export const pick = <T>(pool: T[], week: number): T => pool[(week - 1) % pool.length];

export const block = (
  id: string,
  kind: WorkoutBlock['kind'],
  title: string,
  duration: string,
  items: ExercisePrescription[],
  extra: Partial<WorkoutBlock> = {},
): WorkoutBlock => ({ id, kind, title, duration, items, ...extra });
