import type { ExercisePrescription, SportActivity, SportModule, Workout, WorkoutBlock } from '../types';
import { addDays } from '../lib/date';
import { isDeload, phaseFor } from './phases';
import { block } from './blocks';

export const TOTAL_WEEKS = 16;
/** Ciclo V5: 4 días atleta + miércoles Zona 2 + sábado HYROX-style. */
export const PROGRAM_START = '2026-08-31';

export const ACTIVITY_LABEL: Record<SportActivity, string> = {
  surf: 'Surf', golf: 'Golf', ski: 'Esquí', running: 'Running', rest: 'Descanso', gym: 'Gimnasio', home: 'Entrenamiento en casa',
};

const p = (exerciseId: string, extra: Partial<ExercisePrescription> = {}): ExercisePrescription => ({ exerciseId, ...extra });
const B = (id:string, kind:WorkoutBlock['kind'], title:string, duration:string, items:ExercisePrescription[], focus:string, extra:Partial<WorkoutBlock>={}) =>
  block(id, kind, title, duration, items, { focus, ...extra });
const vol = (week:number, normal:number, deload:number) => isDeload(week) ? deload : normal;
const rounds = (week:number, normal=3) => `${vol(week,normal,2)} vueltas`;
const pick = <T,>(items:T[], week:number, offset=0):T => items[(week - 1 + offset) % items.length];

const transition = (id:string, n:number, intensity='Sostenido · RPE 6–7') => B(
  `${id}-run-${n}`,'transition','VUELTA A LA MANZANA','2–4 min',
  [p('block-run',{sets:1,reps:'1 vuelta',rpe:intensity,instructions:'Transición cardiovascular. No sprint máximo. Volvé listo para el siguiente bloque.'})],
  'Cardio transition · mantener pulsaciones sin perder calidad'
);

// ---------------- ZONA MEDIA ----------------
const CORE_MENUS: ExercisePrescription[][] = [
  [p('ab-wheel',{reps:'8'}),p('copenhagen-plank',{duration:'20 s/lado',unilateral:true}),p('dead-bug',{reps:'8/lado',unilateral:true}),p('pallof-press',{reps:'10/lado',unilateral:true})],
  [p('trx-body-saw',{reps:'10'}),p('side-plank-rotation',{reps:'6/lado',unilateral:true}),p('bear-crawl',{distance:'10 m'}),p('hip-airplane',{reps:'5/lado',unilateral:true})],
  [p('side-plank',{duration:'25 s/lado',unilateral:true}),p('bird-dog',{reps:'8/lado',unilateral:true}),p('pallof-press',{reps:'8/lado',unilateral:true}),p('ab-wheel',{reps:'6–8'})],
  [p('dead-bug',{reps:'10/lado',unilateral:true}),p('copenhagen-plank',{duration:'15–20 s/lado',unilateral:true}),p('trx-body-saw',{reps:'8'}),p('bear-crawl',{distance:'12 m'})],
];
const core = (id:string,w:number,offset=0,duration='6–8 min') => B(`${id}-core`,'core','01 · ZONA MEDIA',duration,pick(CORE_MENUS,w,offset),
  'Core tridimensional + estabilidad de cadera',{rounds:rounds(w)});

// ---------------- FUERZA ----------------
const lowerStrength = (id:string,w:number) => {
  const ph=phaseFor(w); const sets=vol(w, ph.strength.sets, 3);
  const main = pick(['back-squat','front-squat','back-squat','front-squat'],w);
  return B(`${id}-strength`,'strength','02 · FUERZA','14–17 min',[
    p(main,{order:'A',sets,reps:ph.id===1?'6–8':ph.id===2?'5–6':'4–5',rpe:isDeload(w)?'6':'7–8',rest:ph.strength.rest,instructions:'Completar todas las series A antes de B.'}),
    p(pick(['single-leg-rdl','bulgarian-split-squat','step-down','reverse-lunge'],w),{order:'B1',sets:3,reps:'8/lado',unilateral:true,load:'KB 20 kg o peso corporal según ejercicio'}),
    p(pick(['soleus-raise','tibialis-raise','split-squat-hold','hip-airplane'],w,1),{order:'B2',sets:3,reps:'10–15/lado',duration:'20–30 s si es isométrico'})
  ],'Fuerza de piernas + unilateral + durabilidad');
};

const upperStrength = (id:string,w:number) => {
  const acc = pick([
    ['pull-up','db-lateral-raise'],
    ['trx-row','db-hammer-curl'],
    ['pull-up','db-biceps-curl'],
    ['trx-row','db-shoulder-press'],
  ],w) as string[];
  return B(`${id}-strength`,'strength','02 · FUERZA','14–17 min',[
    p('bench-press',{order:'A',sets:vol(w,4,3),reps:phaseFor(w).id<=2?'6–8':'4–6',rpe:isDeload(w)?'6':'7–8',rest:'90–120 s',instructions:'Completar A antes de B1/B2.'}),
    p(acc[0],{order:'B1',sets:3,reps:acc[0]==='pull-up'?'6–8':'10–12'}),
    p(acc[1],{order:'B2',sets:3,reps:'10–15',load:'DB disponibles'})
  ],'Músculo útil: empuje principal + tirón + hombro/bíceps');
};

const golfStrength = (id:string,w:number) => B(`${id}-strength`,'strength','02 · FUERZA','14–17 min',[
  p('romanian-deadlift',{order:'A',sets:vol(w,4,3),reps:phaseFor(w).id>=3?'5–6':'6–8',rpe:isDeload(w)?'6':'7–8',rest:'90–120 s',instructions:'Principal de bisagra. Una sola configuración de barra.'}),
  p(pick(['trx-row','pull-up','single-leg-rdl'],w,1),{order:'B1',sets:3,reps:'8–12'}),
  p(pick(['db-shoulder-press','db-hammer-curl','db-lateral-raise'],w,2),{order:'B2',sets:3,reps:'10–15',load:'DB disponibles'})
],'Cadena posterior + tirón + accesorio de masa muscular');

const fridayPowerStrength = (id:string,w:number) => B(`${id}-strength`,'strength','02 · FUERZA / POWER','13–15 min',[
  p(pick(['hang-clean','clean-high-pull','push-jerk','clean-pull'],w),{order:'A',sets:vol(w,5,3),reps:'3–5',rpe:'6–7',rest:'75–90 s',instructions:'Explosivo. Cortá si baja la velocidad o la técnica.'}),
  p(pick(['pull-up','trx-row','db-shoulder-press'],w,1),{order:'B1',sets:3,reps:'8–12'}),
  p(pick(['db-biceps-curl','db-lateral-raise','db-hammer-curl','db-curl-to-press'],w,2),{order:'B2',sets:3,reps:'10–15'})
],'Potencia olímpica + espalda/hombro/brazo');

// ---------------- ATLETA ----------------
// Cada menú mezcla un levantamiento dinámico, salto, gesto rápido y locomoción.
// La selección rota para evitar vivir de swing + slam.
const ATHLETE_MENUS: ExercisePrescription[][] = [
  [p('hang-clean',{order:'A1',reps:'4',rpe:'6–7'}),p('box-jump',{order:'A2',reps:'5'}),p('push-press',{order:'A3',reps:'5',rpe:'6–7'}),p('threshold-run',{order:'A4',distance:'25 m rápido'})],
  [p('kb-snatch',{order:'A1',reps:'5/lado',unilateral:true}),p('lateral-bound',{order:'A2',reps:'5/lado',unilateral:true}),p('trx-power-pull',{order:'A3',reps:'6/lado',unilateral:true}),p('shuttle-run',{order:'A4',reps:'10-20-10 m'})],
  [p('clean-high-pull',{order:'A1',reps:'5',rpe:'6–7'}),p('broad-jump',{order:'A2',reps:'4'}),p('front-rack-reverse-lunge',{order:'A3',reps:'6/lado',unilateral:true}),p('threshold-run',{order:'A4',distance:'30 m rápido'})],
  [p('push-jerk',{order:'A1',reps:'4',rpe:'6–7'}),p('rotational-mb-throw',{order:'A2',reps:'6/lado',unilateral:true}),p('split-jump',{order:'A3',reps:'6 total'}),p('farmer-carry',{order:'A4',distance:'30 m',carry:true})],
  [p('clean-pull',{order:'A1',reps:'5',rpe:'6–7'}),p('burpee-broad-jump',{order:'A2',reps:'5'}),p('kb-clean-push-press',{order:'A3',reps:'5/lado',unilateral:true}),p('shuttle-run',{order:'A4',reps:'10-10-10 m'})],
  [p('kb-clean',{order:'A1',reps:'6/lado',unilateral:true}),p('skater-jump',{order:'A2',reps:'6/lado',unilateral:true}),p('med-ball-chest-pass',{order:'A3',reps:'8'}),p('threshold-run',{order:'A4',duration:'20 s rápido'})],
  [p('push-press',{order:'A1',reps:'6',rpe:'6–7'}),p('pogo-jump',{order:'A2',reps:'20'}),p('rotational-mb-throw',{order:'A3',reps:'5/lado',unilateral:true}),p('shuttle-run',{order:'A4',reps:'20-20 m'})],
  [p('hang-clean',{order:'A1',reps:'3',rpe:'6–7'}),p('lateral-bound',{order:'A2',reps:'5/lado',unilateral:true}),p('db-curl-to-press',{order:'A3',reps:'10'}),p('threshold-run',{order:'A4',distance:'30 m rápido'})],
  [p('clean-high-pull',{order:'A1',reps:'4'}),p('box-jump',{order:'A2',reps:'5'}),p('db-shoulder-press',{order:'A3',reps:'10'}),p('shuttle-run',{order:'A4',reps:'10-20-10 m'})],
  [p('kb-snatch',{order:'A1',reps:'5/lado',unilateral:true}),p('broad-jump',{order:'A2',reps:'4'}),p('pull-up',{order:'A3',reps:'6'}),p('threshold-run',{order:'A4',distance:'25 m rápido'})],
  [p('push-jerk',{order:'A1',reps:'4'}),p('skater-jump',{order:'A2',reps:'6/lado',unilateral:true}),p('db-hammer-curl',{order:'A3',reps:'12'}),p('farmer-carry',{order:'A4',distance:'30 m',carry:true})],
  [p('kb-clean-push-press',{order:'A1',reps:'5/lado',unilateral:true}),p('split-jump',{order:'A2',reps:'8 total'}),p('trx-power-pull',{order:'A3',reps:'6/lado',unilateral:true}),p('shuttle-run',{order:'A4',reps:'20-20 m'})],
];
const athlete = (id:string,w:number,offset=0) => B(`${id}-athlete`,'athletic','03 · ATLETA','10–12 min',pick(ATHLETE_MENUS,w,offset),
  'Explosivo y dinámico: levantar + saltar + mover + acelerar',{rounds:rounds(w),rest:'45–60 s entre vueltas · mantener velocidad'});

// ---------------- FINISHERS ----------------
// Mixtos, competitivos y variados. La bici es una estación, nunca el finisher entero.
const FINISHERS: {mode:string; items:ExercisePrescription[]}[] = [
  {mode:'AMRAP 9 min',items:[p('spinning-bike',{duration:'35 s fuerte'}),p('db-curl-to-press',{reps:'10'}),p('box-step-over',{reps:'10'}),p('trx-row',{reps:'10'}),p('jump-rope',{reps:'40'})]},
  {mode:'FOR TIME · 4 vueltas',items:[p('threshold-run',{distance:'150 m'}),p('goblet-squat',{reps:'12',load:'KB 20 kg'}),p('db-shoulder-press',{reps:'12'}),p('burpee',{reps:'8'})]},
  {mode:'AMRAP 10 min',items:[p('kb-clean',{reps:'6/lado',unilateral:true}),p('reverse-lunge',{reps:'10 total'}),p('pull-up',{reps:'6'}),p('spinning-bike',{duration:'40 s fuerte'}),p('jump-rope',{reps:'30'})]},
  {mode:'CHIPPER',items:[p('jump-rope',{reps:'100'}),p('box-step-over',{reps:'30'}),p('db-hammer-curl',{reps:'20'}),p('burpee',{reps:'15'}),p('threshold-run',{distance:'300 m'})]},
  {mode:'AMRAP 9 min',items:[p('shuttle-run',{reps:'10-20-10 m'}),p('kb-clean-push-press',{reps:'5/lado',unilateral:true}),p('trx-row',{reps:'10'}),p('mountain-climber',{duration:'25 s'})]},
  {mode:'FOR TIME · 4 vueltas',items:[p('spinning-bike',{duration:'30 s fuerte'}),p('goblet-squat',{reps:'10'}),p('db-curl-to-press',{reps:'8'}),p('burpee-broad-jump',{reps:'5'})]},
  {mode:'LADDER 2-4-6-8-10',items:[p('push-press',{reps:'2-4-6-8-10',rpe:'6–7'}),p('pull-up',{reps:'2-4-6-8-10'}),p('threshold-run',{distance:'100 m entre escalones'})]},
  {mode:'AMRAP 10 min',items:[p('farmer-carry',{distance:'30 m',carry:true}),p('box-step-over',{reps:'12'}),p('db-biceps-curl',{reps:'12'}),p('jump-rope',{reps:'50'}),p('burpee',{reps:'6'})]},
  {mode:'FOR TIME · 3 vueltas',items:[p('threshold-run',{distance:'200 m'}),p('kb-swing',{reps:'15'}),p('push-up',{reps:'10'}),p('reverse-lunge',{reps:'12 total'}),p('jump-rope',{reps:'40'})]},
  {mode:'AMRAP 9 min',items:[p('spinning-bike',{duration:'40 s fuerte'}),p('mb-slam',{reps:'10'}),p('trx-row',{reps:'10'}),p('box-step-over',{reps:'10'}),p('mountain-climber',{duration:'20 s'})]},
  {mode:'FOR TIME · 4 vueltas',items:[p('threshold-run',{distance:'100 m'}),p('db-curl-to-press',{reps:'8'}),p('bulgarian-split-squat',{reps:'8/lado',unilateral:true}),p('bear-crawl',{distance:'10 m'}),p('jump-rope',{reps:'30'})]},
  {mode:'AMRAP 10 min',items:[p('spinning-bike',{duration:'30 s fuerte'}),p('pull-up',{reps:'5'}),p('box-step-over',{reps:'12'}),p('db-hammer-curl',{reps:'10'}),p('burpee',{reps:'6'})]},
];
const finisher = (id:string,w:number,offset=0) => {
  const chosen=pick(FINISHERS,w,offset);
  const mode=isDeload(w)?chosen.mode.replace(/10 min|9 min/g,'7 min').replace('4 vueltas','3 vueltas'):chosen.mode;
  return B(`${id}-finisher`,'finisher','04 · FINISHER',isDeload(w)?'7–8 min':'8–11 min',chosen.items,
    'AMRAP / For Time / Chipper · mixto y registrable',{rounds:mode,rest:'Solo lo necesario · RPE 8–9'});
};

// ---------------- MIÉRCOLES ZONA 2 ----------------
const zone2Day = (id:string,w:number) => [
  B(`${id}-prep`,'movement','MOVEMENT PREP','6–8 min',[
    p('foot-activation',{duration:'60 s'}),p('hip-9090',{reps:'8 cambios'}),p('open-book',{reps:'8/lado',unilateral:true}),p('shoulder-cars',{reps:'5/lado',unilateral:true})
  ],'Preparar sin fatigar'),
  B(`${id}-z2`,'engine','ZONE 2','32–45 min',[
    p(pick(['spinning-bike','zone2-run'],w),{duration:isDeload(w)?'30–35 min':'35–45 min',rpe:'4–5',instructions:'Ritmo conversacional. Debés poder hablar en frases completas.'})
  ],'Base aeróbica · favorecer recuperación y gasto energético'),
  B(`${id}-mob`,'recovery','MOBILITY','8–10 min',[
    p('hip-flexor-stretch',{duration:'45 s/lado',unilateral:true}),p('thoracic-rotation',{reps:'8/lado',unilateral:true}),p('worlds-greatest-stretch',{reps:'5/lado',unilateral:true})
  ],'Cadera + tórax + cadena anterior')
];

// ---------------- SÁBADO HYROX-STYLE ----------------
const HYROX_FINISHERS: {mode:string; items:ExercisePrescription[]}[] = [
  {mode:'HYROX STYLE · 4 vueltas FOR TIME',items:[p('threshold-run',{distance:'400 m'}),p('spinning-bike',{duration:'60 s fuerte'}),p('goblet-squat',{reps:'15'}),p('farmer-carry',{distance:'40 m',carry:true}),p('burpee',{reps:'10'})]},
  {mode:'HYROX STYLE · 5 vueltas',items:[p('threshold-run',{distance:'300 m'}),p('box-step-over',{reps:'16'}),p('pull-up',{reps:'5'}),p('reverse-lunge',{reps:'16 total'}),p('spinning-bike',{duration:'45 s fuerte'})]},
  {mode:'HYROX STYLE · CHIPPER',items:[p('threshold-run',{distance:'800 m'}),p('farmer-carry',{distance:'80 m',carry:true}),p('box-step-over',{reps:'40'}),p('burpee-broad-jump',{reps:'20'}),p('jump-rope',{reps:'150'}),p('threshold-run',{distance:'800 m'})]},
  {mode:'HYROX STYLE · 4 vueltas FOR TIME',items:[p('threshold-run',{distance:'400 m'}),p('spinning-bike',{duration:'45 s fuerte'}),p('db-curl-to-press',{reps:'12'}),p('goblet-squat',{reps:'12'}),p('bear-crawl',{distance:'15 m'})]},
];
const hyroxSaturday = (id:string,w:number) => {
  const h=pick(HYROX_FINISHERS,w);
  return [
    core(id,w,2,'5–6 min'),
    B(`${id}-strength`,'strength','02 · STRENGTH ENDURANCE','9–10 min',[
      p(pick(['front-rack-reverse-lunge','goblet-squat','bulgarian-split-squat'],w),{order:'A1',sets:3,reps:'8–10/lado',unilateral:true}),
      p(pick(['trx-row','pull-up','push-up'],w,1),{order:'A2',sets:3,reps:'8–12'}),
      p(pick(['db-shoulder-press','db-hammer-curl','db-lateral-raise'],w,2),{order:'A3',sets:3,reps:'10–15'})
    ],'Resistencia de fuerza sin cargar la barra pesada',{rounds:rounds(w)}),
    B(`${id}-athlete`,'athletic','03 · HYROX PREP','8–10 min',pick([
      [p('clean-high-pull',{reps:'4'}),p('box-jump',{reps:'5'}),p('shuttle-run',{reps:'10-20-10 m'})],
      [p('kb-snatch',{reps:'5/lado',unilateral:true}),p('lateral-bound',{reps:'5/lado',unilateral:true}),p('farmer-carry',{distance:'30 m',carry:true})],
      [p('push-jerk',{reps:'4'}),p('broad-jump',{reps:'4'}),p('threshold-run',{distance:'30 m rápido'})],
      [p('kb-clean-push-press',{reps:'5/lado',unilateral:true}),p('skater-jump',{reps:'6/lado',unilateral:true}),p('shuttle-run',{reps:'20-20 m'})]
    ],w),'Potencia corta antes del bloque largo',{rounds:rounds(w),rest:'45 s entre vueltas'}),
    B(`${id}-hyrox`,'finisher','04 · HYROX STYLE',isDeload(w)?'14–18 min':'18–22 min',h.items,
      'Sesión picante de carrera + estaciones funcionales',{rounds:isDeload(w)?h.mode.replace('5 vueltas','3 vueltas').replace('4 vueltas','3 vueltas'):h.mode,rest:'Administrá ritmo · RPE 8–9'})
  ];
};

interface DayPlan { name:string; subtitle:string; objective:string; duration:string; rpe:string; next:SportActivity|null; modules:SportModule[]; external?:SportActivity; build:(id:string,week:number)=>WorkoutBlock[]; note:(week:number)=>string; }

const DAYS:DayPlan[]=[
  {name:'LOWER IGNITION',subtitle:'Lower strength · Athlete',objective:'Construir piernas fuertes y musculares sin perder velocidad, salto ni capacidad de correr.',duration:'47–50 min',rpe:'8',next:'gym',modules:[],build:(id,w)=>[
    core(id,w,0),lowerStrength(id,w),transition(id,1),athlete(id,w,0),transition(id,2,'Sostenido/fuerte controlado · RPE 7'),finisher(id,w,0)
  ],note:()=> 'Lunes = fuerza de piernas + potencia. La explosividad se entrena antes de llegar fatigado al finisher.'},

  {name:'UPPER SURF',subtitle:'Upper muscle · Athlete · Surf',objective:'Ganar/mantener espalda, pecho, hombros y brazos con potencia y estabilidad útil para surf.',duration:'46–50 min',rpe:'8',next:'running',modules:['surf'],build:(id,w)=>[
    core(id,w,1),upperStrength(id,w),transition(id,1),athlete(id,w,3),finisher(id,w,3)
  ],note:()=> 'Más tirón, hombro sano y potencia. Evitar repetir el mismo push o row en tres bloques.'},

  {name:'ZONE 2 + MOBILITY',subtitle:'Aerobic base · Flexible & light',objective:'Mejorar el motor aeróbico, favorecer recuperación y sostener el déficit sin sumar otra sesión dura.',duration:'45–60 min',rpe:'4–5',next:'gym',modules:['running'],build:(id,w)=>zone2Day(id,w),note:()=> 'Miércoles deliberadamente fácil: construir motor para que jueves, viernes y sábado rindan.'},

  {name:'ROTATE & DRIVE',subtitle:'Full body · Athlete · Golf',objective:'Fuerza global, potencia rotacional, aceleración y capacidad de frenar para transferir al golf.',duration:'47–50 min',rpe:'8',next:'gym',modules:['golf'],build:(id,w)=>[
    core(id,w,3),golfStrength(id,w),transition(id,1),athlete(id,w,6),transition(id,2),finisher(id,w,6)
  ],note:()=> 'Jueves = bisagra + potencia rotacional + velocidad. Producir fuerza y frenarla con control.'},

  {name:'FULL SEND',subtitle:'Athletic hybrid · Explosive variety',objective:'Entrenar levantamientos dinámicos, saltos, desplazamientos y músculo útil con alta densidad.',duration:'47–50 min',rpe:'8–9',next:'gym',modules:['surf','golf'],build:(id,w)=>[
    core(id,w,1),fridayPowerStrength(id,w),transition(id,1),athlete(id,w,9),transition(id,2,'Fuerte controlado · RPE 7–8'),finisher(id,w,9)
  ],note:()=> 'Viernes = variedad explosiva real. Los olímpicos progresan; los accesorios y finishers rotan.'},

  {name:'HYROX SATURDAY',subtitle:'Race engine · Strength endurance',objective:'Sesión larga y picante de carrera + estaciones para capacidad de trabajo, gasto energético y tolerancia al esfuerzo.',duration:'45–55 min',rpe:'8–9',next:'rest',modules:['running'],build:(id,w)=>hyroxSaturday(id,w),note:()=> 'No es una simulación oficial de HYROX: usa tu equipamiento para mezclar carrera, carga, piernas y tren superior sin aburrir.'},

  {name:'REST',subtitle:'Recovery',objective:'Recuperar para preservar músculo, potencia y adherencia durante el déficit.',duration:'Descanso',rpe:'1–2',next:'gym',modules:[],external:'rest',build:(id)=>[
    B(`${id}-restore`,'recovery','RESTORE','10–20 min',[p('nasal-breathing',{duration:'3 min'}),p('hip-flow',{duration:'5 min'}),p('easy-walk',{duration:'10–20 min'})],'Recuperación opcional')
  ],note:()=> 'Domingo sin trabajo duro.'}
];

export const WEEK_STRUCTURE=DAYS.map(d=>({name:d.name,subtitle:d.subtitle}));
const buildWorkout=(week:number,dayIndex:number,date:string):Workout=>{const plan=DAYS[dayIndex];const id=`w${week}d${dayIndex+1}`;const blocks=plan.build(id,week);return{id,week,day:dayIndex+1,date,name:plan.name,subtitle:plan.subtitle,objective:plan.objective,duration:plan.duration,plannedRpe:isDeload(week)?'6–7':plan.rpe,coachNote:plan.note(week),nextDayActivity:plan.next,blocks,adaptations:[],status:plan.external?'external':'pending',externalActivity:plan.external,phase:phaseFor(week).id,modules:plan.modules};};
export const buildProgram=(start:string=PROGRAM_START):Workout[]=>{const out:Workout[]=[];for(let w=1;w<=TOTAL_WEEKS;w++)for(let d=0;d<DAYS.length;d++)out.push(buildWorkout(w,d,addDays(start,(w-1)*7+d)));return out;};
export { phaseFor, weekInPhase, isDeload, PHASES } from './phases';
