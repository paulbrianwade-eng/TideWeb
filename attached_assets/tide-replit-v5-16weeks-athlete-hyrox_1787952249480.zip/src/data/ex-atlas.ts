import type { Exercise } from '../types';
import { x } from './ex-helpers';

export const ATLAS_EXERCISES: Exercise[] = [
  x('ab-wheel', 'Ab Wheel', {
    cat: ['Core'], obj: 'Antiextensión fuerte del tronco para transferir fuerza sin perder la pelvis.',
    cap: ['Antirrotación'], tgt: ['Recto abdominal', 'Oblicuos', 'Dorsal'], typ: '3 × 6–10',
    cues: ['Costillas abajo.', 'Glúteos activos.', 'Volvé antes de perder la pelvis.'],
    err: ['Arquear la lumbar', 'Buscar rango sin control'], reg: 'TRX fallout o dead bug.', pro: 'Más rango o pausa extendida.', eq: ['Ab Wheel']
  }),
  x('trx-body-saw', 'TRX Body Saw', {
    cat: ['Core', 'Surf'], obj: 'Antiextensión dinámica y control escapular.', cap: ['Antirrotación', 'Estabilidad escapular'],
    tgt: ['Core', 'Serrato'], mod: ['surf'], typ: '3 × 8–12', cues: ['Cuerpo en bloque.', 'Movimiento desde hombros.', 'No hundir lumbar.'],
    err: ['Cadera cae', 'Rango excesivo'], reg: 'Plancha.', pro: 'Mayor inclinación.', eq: ['TRX']
  }),
  x('side-plank-rotation', 'Side Plank Rotation', {
    cat: ['Core', 'Rotación', 'Golf', 'Surf'], obj: 'Rotar el tórax manteniendo pelvis estable.', cap: ['Rotación', 'Antirrotación'],
    tgt: ['Oblicuos', 'Tórax'], mod: ['golf','surf'], typ: '3 × 6–8/lado', cues: ['Pelvis alta.', 'Rotá desde tórax.', 'Control en ambos sentidos.'],
    err: ['Caer de cadera', 'Mover solo el brazo'], reg: 'Side plank.', pro: 'Con banda.', eq: ['Peso corporal']
  }),
  x('kb-swing', 'Kettlebell Swing', {
    cat: ['Potencia'], obj: 'Bisagra balística para producir potencia repetida sin una segunda barra.', cap: ['Potencia', 'Resistencia local'],
    tgt: ['Glúteos','Isquiotibiales','Core'], typ: '10–15 reps', cues: ['Bisagra, no sentadilla.', 'Cadera impulsa.', 'Brazos acompañan.'],
    err: ['Levantar con hombros', 'Hiperextender arriba'], reg: 'KB deadlift.', pro: 'Más cadencia con técnica.', eq: ['Kettlebell']
  }),
  x('kb-clean-push-press', 'KB Clean + Push Press', {
    cat: ['Potencia', 'Unilateral'], obj: 'Levantar y transferir fuerza de suelo a mano en un gesto dinámico full-body.', cap: ['Potencia', 'Unilateral'],
    tgt: ['Cadera','Hombro','Core'], typ: '5–6/lado', cues: ['Clean pegado.', 'Dip corto.', 'Bloqueá sin arquear lumbar.'],
    err: ['Golpear el antebrazo', 'Press estricto bajo fatiga'], reg: 'KB clean solo.', pro: 'Complejo continuo.', eq: ['Kettlebell']
  }),
  x('burpee', 'Burpee', {
    cat: ['Cardio'], obj: 'Subir pulsaciones con un patrón global simple.', cap: ['Resistencia local'], tgt: ['Full body'], typ: '6–10 reps',
    cues: ['Ritmo sostenible.', 'Apoyo firme de manos.', 'Respirá cada repetición.'], err: ['Colapsar lumbar', 'Sprintar la primera ronda'],
    reg: 'Step-back burpee.', pro: 'Burpee over line.', eq: ['Peso corporal']
  }),
  x('jump-rope', 'Jump Rope', {
    cat: ['Cardio', 'Running'], obj: 'Cardio elástico con bajo espacio y buena demanda de pie/tobillo.', cap: ['Pie y tobillo', 'Capacidad aeróbica'],
    tgt: ['Pantorrilla','Pie'], mod: ['running'], typ: '40–60 saltos', cues: ['Saltos bajos.', 'Muñecas rápidas.', 'Ritmo parejo.'],
    err: ['Saltar alto', 'Girar con hombros'], reg: 'Saltos sin soga.', pro: 'Double unders.', eq: ['Soga']
  }),
  x('spinning-bike', 'Spinning Bike', {
    cat: ['Cardio'], obj: 'Sumar trabajo cardiovascular sin impacto y funcionar como estación dentro de circuitos.', cap: ['Capacidad aeróbica', 'Umbral'],
    tgt: ['Cuádriceps','Glúteos','Sistema cardiovascular'], typ: '30–60 s fuerte o 30–50 min Zona 2',
    cues: ['Cadencia controlada.', 'Resistencia que permita pedalear fluido.', 'No rebotar en el asiento.'],
    err: ['Resistencia absurda', 'Cadencia caótica'], reg: 'Menos resistencia.', pro: 'Más watts/cadencia a mismo RPE.', eq: ['Bicicleta de spinning']
  }),
  x('block-run', 'Vuelta a la manzana', {
    cat: ['Cardio', 'Running'], obj: 'Transición cardiovascular que mantiene pulsaciones entre bloques sin reemplazar el trabajo atlético.',
    cap: ['Capacidad aeróbica'], tgt: ['Sistema cardiovascular'], mod: ['running'], typ: '1 vuelta · ritmo sostenido',
    cues: ['RPE 6–7.', 'No sprint.', 'Volvé listo para el siguiente bloque.'], err: ['Correr a fondo', 'Convertirla en otra serie de piernas'],
    reg: 'Trote/caminata.', pro: 'Ritmo sostenido más rápido.', eq: ['Espacio exterior']
  }),
  x('shuttle-run', 'Shuttle Run', {
    cat: ['Cardio', 'Running'], obj: 'Acelerar, frenar y volver a acelerar con control.', cap: ['Cambio de dirección','Desaceleración','Velocidad'],
    tgt: ['Piernas','Core'], mod: ['running'], typ: '10-20-10 m', cues: ['Bajá centro de masa antes de frenar.', 'Apoyo debajo del cuerpo.', 'Acelerá progresivo.'],
    err: ['Frenar erguido', 'Girar sobre rodilla bloqueada'], reg: 'Distancias cortas.', pro: 'Más velocidad.', eq: ['Espacio exterior']
  }),
  x('mountain-climber', 'Mountain Climber', {
    cat: ['Cardio','Core'], obj: 'Cardio simple manteniendo tronco estable.', cap: ['Resistencia local'], tgt: ['Core','Flexores de cadera'], typ: '30–40 s',
    cues: ['Hombros sobre manos.', 'Cadera estable.', 'Rodillas rápidas sin rebotar.'], err: ['Cadera muy alta', 'Lumbar colapsada'],
    reg: 'Marcha en plancha.', pro: 'Mayor cadencia.', eq: ['Peso corporal']
  }),

  x('db-biceps-curl', 'DB Biceps Curl', {
    cat: ['Fuerza'], obj: 'Sumar volumen de brazo con bajo costo sistémico para preservar/ganar masa muscular.', cap: ['Resistencia local'],
    tgt: ['Bíceps'], typ: '10–15 reps', cues: ['Codos quietos.', 'Controlá la bajada.', 'No balancear tronco.'],
    err: ['Impulso con espalda', 'Recortar rango'], reg: 'Curl alternado.', pro: 'Tempo 3 s excéntrico.', eq: ['Mancuernas']
  }),
  x('db-hammer-curl', 'DB Hammer Curl', {
    cat: ['Fuerza'], obj: 'Trabajo de bíceps/braquial y agarre con bajo costo de recuperación.', cap: ['Resistencia local'],
    tgt: ['Bíceps','Braquial','Antebrazo'], typ: '10–15 reps', cues: ['Muñeca neutra.', 'Codos pegados.', 'Subí sin balanceo.'],
    err: ['Impulso lumbar', 'Muñeca doblada'], reg: 'Alternado.', pro: 'Tempo lento.', eq: ['Mancuernas']
  }),
  x('db-lateral-raise', 'DB Lateral Raise', {
    cat: ['Fuerza'], obj: 'Añadir volumen de deltoides sin interferir con el levantamiento principal.', cap: ['Resistencia local'],
    tgt: ['Deltoides medio'], typ: '12–20 reps', cues: ['Hombros bajos.', 'Subí hasta línea de hombro.', 'Controlá la bajada.'],
    err: ['Encoger trapecio', 'Balancear'], reg: 'Menor rango.', pro: 'Pausa arriba.', eq: ['Mancuernas']
  }),
  x('db-curl-to-press', 'DB Curl to Press', {
    cat: ['Potencia','Fuerza'], obj: 'Combinar brazo y hombro en un patrón continuo útil para circuitos mixtos.', cap: ['Resistencia local'],
    tgt: ['Bíceps','Hombros','Core'], typ: '8–12 reps', cues: ['Curl limpio.', 'Press sin arquear lumbar.', 'Ritmo continuo.'],
    err: ['Balanceo', 'Hiperextender lumbar'], reg: 'Curl + press separados.', pro: 'Más densidad.', eq: ['Mancuernas']
  }),
  x('kb-snatch', 'KB Snatch', {
    cat: ['Potencia','Unilateral'], obj: 'Potencia unilateral desde cadera hasta overhead.', cap: ['Potencia','Unilateral'],
    tgt: ['Cadera','Hombro','Core'], typ: '4–6/lado', cues: ['Pegá la KB al cuerpo.', 'Punch arriba.', 'Cadera inicia.'],
    err: ['Golpear antebrazo', 'Tirar solo con brazo'], reg: 'KB clean.', pro: 'Complejo clean + snatch.', eq: ['Kettlebell']
  }),
  x('kb-clean', 'KB Clean', {
    cat: ['Potencia','Unilateral'], obj: 'Levantar la kettlebell al rack con potencia de cadera y control unilateral.', cap: ['Potencia','Unilateral'],
    tgt: ['Cadera','Core','Antebrazo'], typ: '5–8/lado', cues: ['Codo cerca.', 'Cadera mueve la carga.', 'Recibí suave.'],
    err: ['Curl de brazo', 'Golpear muñeca'], reg: 'Deadlift + high pull.', pro: 'Clean + press.', eq: ['Kettlebell']
  }),
  x('clean-high-pull', 'Clean High Pull', {
    cat: ['Potencia'], obj: 'Desarrollar triple extensión sin exigir recepción técnica del clean.', cap: ['Potencia'],
    tgt: ['Glúteos','Cuádriceps','Trapecio'], typ: '3–5 reps', cues: ['Empujá el piso.', 'Cadera y rodillas terminan juntas.', 'Barra cerca.'],
    err: ['Remar demasiado pronto', 'Barra lejos'], reg: 'Clean pull.', pro: 'Hang power clean.', eq: ['Barra olímpica']
  }),
  x('clean-pull', 'Clean Pull', {
    cat: ['Potencia'], obj: 'Entrenar aceleración de barra y triple extensión con baja complejidad.', cap: ['Potencia'],
    tgt: ['Cadena posterior','Cuádriceps','Trapecio'], typ: '3–5 reps', cues: ['Barra cerca.', 'Extensión violenta.', 'Brazos largos hasta terminar cadera.'],
    err: ['Tirar con brazos', 'Perder postura'], reg: 'RDL explosivo.', pro: 'High pull.', eq: ['Barra olímpica']
  }),
  x('push-jerk', 'Push Jerk', {
    cat: ['Potencia'], obj: 'Transferir fuerza del suelo a overhead con velocidad y recepción estable.', cap: ['Potencia'],
    tgt: ['Piernas','Hombros','Core'], typ: '3–5 reps', cues: ['Dip vertical.', 'Drive rápido.', 'Recibí con rodillas blandas.'],
    err: ['Press lento', 'Dip hacia adelante'], reg: 'Push press.', pro: 'Más velocidad con misma carga.', eq: ['Barra olímpica']
  }),
  x('trx-power-pull', 'TRX Power Pull', {
    cat: ['Potencia','Rotación','Surf'], obj: 'Tirón unilateral dinámico con rotación controlada.', cap: ['Potencia','Rotación','Estabilidad escapular'],
    tgt: ['Dorsal','Escápula','Oblicuos'], mod: ['surf'], typ: '6–8/lado', cues: ['Cadera estable.', 'Tirá fuerte.', 'Controlá la vuelta.'],
    err: ['Colapsar hombro', 'Rotar desde lumbar'], reg: 'TRX row.', pro: 'Mayor inclinación.', eq: ['TRX']
  }),
  x('front-rack-reverse-lunge', 'Front Rack Reverse Lunge', {
    cat: ['Unilateral','Fuerza'], obj: 'Unilateral dinámico con demanda de tronco y transferencia atlética.', cap: ['Unilateral','Desaceleración'],
    tgt: ['Glúteos','Cuádriceps','Core'], typ: '6–8/lado', cues: ['Paso atrás largo.', 'Tronco firme.', 'Empujá el piso al volver.'],
    err: ['Rodilla colapsa', 'Perder rack'], reg: 'Reverse lunge con KB.', pro: 'Más carga.', eq: ['Barra olímpica']
  }),
  x('split-jump', 'Split Jump', {
    cat: ['Potencia','Unilateral'], obj: 'Potencia reactiva unilateral y cambio rápido de apoyo.', cap: ['Potencia','Absorción de impacto'],
    tgt: ['Piernas','Tobillo'], typ: '6–10 total', cues: ['Saltá vertical.', 'Caé suave.', 'Rodilla alineada.'],
    err: ['Caída rígida', 'Rodilla hacia adentro'], reg: 'Split squat rápido.', pro: 'Mayor altura.', eq: ['Peso corporal']
  }),
  x('burpee-broad-jump', 'Burpee Broad Jump', {
    cat: ['Potencia','Cardio'], obj: 'Combinar transición al piso con salto horizontal y alta demanda metabólica.', cap: ['Potencia','Resistencia local'],
    tgt: ['Full body'], typ: '4–6 reps', cues: ['Burpee limpio.', 'Armá el salto.', 'Caé estable.'],
    err: ['Saltar fatigado sin control', 'Caída dura'], reg: 'Burpee + paso.', pro: 'Mayor distancia.', eq: ['Peso corporal']
  }),
  x('med-ball-chest-pass', 'Medicine Ball Chest Pass', {
    cat: ['Potencia'], obj: 'Potencia de empuje horizontal sin fatiga de fuerza pesada.', cap: ['Potencia'],
    tgt: ['Pecho','Tríceps','Core'], typ: '6–10 reps', cues: ['Explosivo.', 'Costillas abajo.', 'Recuperá rápido.'],
    err: ['Lanzamiento lento', 'Arquear lumbar'], reg: 'MB más liviana.', pro: 'Desde split stance.', eq: ['Medicine Ball']
  }),
  x('box-step-over', 'Box Step Over', {
    cat: ['Cardio','Unilateral'], obj: 'Trabajo cíclico de piernas con bajo impacto para finishers.', cap: ['Resistencia local','Unilateral'],
    tgt: ['Cuádriceps','Glúteos'], typ: '10–16 total', cues: ['Apoyo completo.', 'Ritmo continuo.', 'Control al bajar.'],
    err: ['Saltar sin control', 'Apoyo parcial'], reg: 'Step-up.', pro: 'Más ritmo.', eq: ['Cajón']
  }),
  x('goblet-squat', 'Goblet Squat', {
    cat: ['Fuerza','Cardio'], obj: 'Sentadilla simple y segura para circuitos y finishers.', cap: ['Resistencia local'],
    tgt: ['Cuádriceps','Glúteos','Core'], typ: '10–15 reps', cues: ['KB pegada.', 'Rodillas acompañan pies.', 'Tronco firme.'],
    err: ['Colapsar tronco', 'Talones se levantan'], reg: 'Box squat goblet.', pro: 'Más densidad.', eq: ['Kettlebell']
  }),
  x('push-up', 'Push Up', {
    cat: ['Fuerza','Cardio'], obj: 'Empuje horizontal de peso corporal útil en circuitos sin tocar la barra.', cap: ['Resistencia local'],
    tgt: ['Pecho','Tríceps','Core'], typ: '8–15 reps', cues: ['Cuerpo en bloque.', 'Pecho entre manos.', 'Costillas abajo.'],
    err: ['Cadera cae', 'Codos muy abiertos'], reg: 'Manos elevadas.', pro: 'Explosivo.', eq: ['Peso corporal']
  }),
];
