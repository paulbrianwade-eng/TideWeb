import type { Phase } from '../types';

/** 16 semanas para recomposición atlética y preparación progresiva para surf + golf. */
export const PHASES: Phase[] = [
  {
    id: 1,
    name: 'Base + Recomp',
    weeks: [1, 4],
    focus: 'Técnica, volumen útil, base aeróbica y tolerancia',
    strength: { sets: 4, reps: '6–8', rpe: '7', rest: '90–120 s' },
    power: { sets: 3, reps: '4–6', rest: '60 s', intent: 'Rápido y limpio' },
    accessoryReps: '10–12',
    coachNote: 'Construir sin acumular basura. Técnica sólida, cardio distribuido y finishers intensos pero controlados.',
  },
  {
    id: 2,
    name: 'Strength + Muscle',
    weeks: [5, 8],
    focus: 'Subir fuerza y preservar/ganar masa muscular durante el déficit',
    strength: { sets: 5, reps: '5–6', rpe: '7–8', rest: '2 min' },
    power: { sets: 4, reps: '3–5', rest: '75 s', intent: 'Velocidad con carga moderada' },
    accessoryReps: '8–10',
    coachNote: 'La carga sube, pero el objetivo sigue siendo moverte bien. No sacrifiques velocidad ni rango por kilos.',
  },
  {
    id: 3,
    name: 'Power + Engine',
    weeks: [9, 12],
    focus: 'Potencia, levantamientos dinámicos, saltos, sprint y work capacity',
    strength: { sets: 4, reps: '4–5', rpe: '8', rest: '2–3 min' },
    power: { sets: 4, reps: '3–5', rest: '60–75 s', intent: 'Máxima intención' },
    accessoryReps: '8–10',
    coachNote: 'El bloque Atleta se vuelve protagonista: rápido, dinámico y exigente, sin convertir potencia en cardio desordenado.',
  },
  {
    id: 4,
    name: 'Surf + Golf Ready',
    weeks: [13, 16],
    focus: 'Llegar liviano, fuerte, móvil y explosivo al agua y al campo',
    strength: { sets: 4, reps: '4–6', rpe: '7–8', rest: '2 min' },
    power: { sets: 4, reps: '3–5', rest: '60–75 s', intent: 'Potencia aplicada' },
    accessoryReps: '8–12',
    coachNote: 'Mantener fuerza, subir transferencia y llegar fresco. Más calidad atlética, menos fatiga innecesaria.',
  },
];

export const phaseFor = (week: number): Phase => {
  const w = ((week - 1) % 16) + 1;
  return PHASES.find((ph) => w >= ph.weeks[0] && w <= ph.weeks[1]) ?? PHASES[0];
};

export const weekInPhase = (week: number): number => {
  const w = ((week - 1) % 16) + 1;
  const ph = phaseFor(w);
  return w - ph.weeks[0] + 1;
};

export const isDeload = (week: number): boolean => weekInPhase(week) === 4;
