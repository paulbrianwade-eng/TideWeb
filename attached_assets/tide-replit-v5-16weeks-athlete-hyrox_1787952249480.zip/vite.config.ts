import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Replit expone el puerto detrás de un proxy HTTPS con un dominio propio,
// así que ahí hay que escuchar en 0.0.0.0, permitir cualquier host y
// apuntar el HMR al 443. En local se usa la configuración normal.
const onReplit = Boolean(process.env.REPL_ID || process.env.REPLIT_DEV_DOMAIN);

export default defineConfig({
  plugins: [react()],
  server: {
    host: onReplit ? '0.0.0.0' : 'localhost',
    port: 5173,
    strictPort: true,
    ...(onReplit ? { allowedHosts: true as const, hmr: { clientPort: 443 } } : {}),
  },
  preview: {
    host: onReplit ? '0.0.0.0' : 'localhost',
    port: 5173,
    ...(onReplit ? { allowedHosts: true as const } : {}),
  },
});
