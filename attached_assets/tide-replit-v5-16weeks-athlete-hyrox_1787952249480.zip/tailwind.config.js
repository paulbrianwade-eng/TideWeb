/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { base:'#F4F5F2', night:'#087F5B', surface:'#FFFFFF', surface2:'#EEF1ED', line:'#DDE2DC', ink:'#161816', muted:'#6E746F', accent:'#B8FF72', warn:'#E99C2B', danger:'#D64545', success:'#087F5B', foam:'#087F5B', deep:'#E9FFD7' },
    fontFamily: { display:['"Arial Narrow"','"Barlow Condensed"','Impact','sans-serif'], sans:['Inter','system-ui','-apple-system','Segoe UI','Roboto','sans-serif'], mono:['Inter','ui-monospace','monospace'] },
    boxShadow:{card:'none'}, borderRadius:{xl2:'1.25rem'}
  }}, plugins:[],
};
