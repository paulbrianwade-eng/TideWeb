/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { base:'#F4F3EF', night:'#111111', surface:'#FFFFFF', surface2:'#ECECE7', line:'#D7D7D0', ink:'#111111', muted:'#6B6B6B', accent:'#D8FF3E', warn:'#D98C10', danger:'#D94444', success:'#2E8B57', foam:'#111111', deep:'#E7E6E0' },
    fontFamily: { display:['"Arial Narrow"','"Barlow Condensed"','Impact','sans-serif'], sans:['Inter','system-ui','-apple-system','Segoe UI','Roboto','sans-serif'], mono:['Inter','ui-monospace','monospace'] },
    boxShadow:{card:'none'}, borderRadius:{xl2:'1.25rem'}
  }}, plugins:[],
};
