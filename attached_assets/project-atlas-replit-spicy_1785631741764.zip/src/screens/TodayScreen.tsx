import { useState } from 'react';
import { FileText, Flag, Play, RotateCcw } from 'lucide-react';
import { useApp } from '../state/AppContext';
import { ACTIVITY_LABEL } from '../data/program';
import { addDays, longDate } from '../lib/date';
import { readinessState } from '../lib/adaptations';
import { PHASES, TOTAL_WEEKS, isDeload } from '../data/program';
import { ModuleBadge } from '../components/ModuleBadge';
import { sessionProgress } from '../lib/prescription';
import { Card, EmptyState, StatusBadge } from '../components/ui';
import { TideLevel } from '../components/ui2';
import { ActivitySelector, CoachNote, WorkoutBlockCard } from '../components/workout-parts';
import { AdaptiveSessionPanel, ReadinessSelector } from '../components/readiness';
import type { SportActivity } from '../types';

const Meta = ({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) => (
  <div>
    <p className="eyebrow">{label}</p>
    <p className={`font-mono text-sm ${accent ? 'text-accent' : 'text-ink'}`}>{value}</p>
  </div>
);

export const TodayScreen = ({
  onStart,
  onOnePager,
}: {
  onStart: (workoutId: string, blockIndex?: number) => void;
  onOnePager: (workoutId: string) => void;
}) => {
  const app = useApp();
  const { today } = app;
  const workout = app.workoutFor(today);
  const readiness = app.readinessFor(today);
  const state = readinessState(readiness);
  const selected = app.state.adjustments[today] ?? [];
  const session = workout ? app.sessionFor(workout.id) : undefined;
  const summary = workout ? app.summaryFor(workout.id) : undefined;
  const [showActivity, setShowActivity] = useState(false);
  const [openBlocks, setOpenBlocks] = useState<string[] | null>(null);
  const extras = app.state.extras[today] ?? [];

  const tomorrow = addDays(today, 1);
  const tomorrowOverride = app.state.calendarOverrides[tomorrow] ?? null;
  const tomorrowWorkout = app.workoutFor(tomorrow);
  const tomorrowActivity: SportActivity | null =
    tomorrowOverride ?? tomorrowWorkout?.externalActivity ?? workout?.nextDayActivity ?? null;

  if (!workout) {
    return (
      <EmptyState
        title="No hay sesión programada para hoy"
        hint="Abrí el calendario para elegir una actividad o adelantar la próxima sesión."
      />
    );
  }

  const phase = PHASES.find((x) => x.id === workout.phase) ?? PHASES[0];
  const progress = sessionProgress(workout, session);
  const started = !!session && !session.completedAt;

  // Por defecto se abren los bloques que definen el día: fuerza y el módulo deportivo.
  const defaultOpen = workout.blocks.filter((b) => b.kind === 'strength').map((b) => b.id);
  const expandedBlocks = openBlocks ?? defaultOpen;
  const toggleBlock = (id: string) =>
    setOpenBlocks((prev) => {
      const base = prev ?? defaultOpen;
      return base.includes(id) ? base.filter((x) => x !== id) : [...base, id];
    });

  return (
    <div className="space-y-4">
      <header className="flex items-start justify-between gap-3">
        <div>
          <p className="eyebrow">{longDate(today)}</p>
          <p className="mt-1 font-mono text-sm uppercase tracking-[0.2em] text-muted">
            Week {workout.week}/{TOTAL_WEEKS} · Day {workout.day}
          </p>
        </div>
        <StatusBadge tone={state.tone}>{state.label}</StatusBadge>
      </header>

      <Card className="space-y-5 overflow-hidden">
        <div className="editorial-hero -m-6 mb-0">
          <p className="eyebrow !text-white/70">TODAY · {workout.duration}</p>
          <h2 className="mt-3 max-w-[12ch] font-display text-[3.25rem] font-bold uppercase leading-[0.84] tracking-[-0.04em]">{workout.name}</h2>
          <p className="mt-4 max-w-md text-sm text-white/75">{workout.objective}</p>
        </div>
        <div>
          <p className="eyebrow mb-1.5">
            Fase {phase.id} · {phase.name}
            {isDeload(workout.week) ? ' · descarga' : ''}
          </p>
          <h1 className="font-display text-2xl font-bold uppercase leading-none">Session details</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-line px-3 py-1 text-xs text-muted">
              {workout.subtitle}
            </span>
            {workout.modules.map((m) => (
              <ModuleBadge key={m} module={m} size="sm" />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 border-y border-line py-4 sm:grid-cols-4">
          <Meta label="Duración" value={workout.duration} />
          <Meta label="RPE objetivo" value={workout.plannedRpe} accent />
          <Meta label="Bloques" value={String(workout.blocks.length)} />
          <Meta label="Mañana" value={tomorrowActivity ? ACTIVITY_LABEL[tomorrowActivity] : '—'} />
        </div>

        <div className="flex items-center justify-between gap-3">
          <TideLevel plannedRpe={workout.plannedRpe} />
          <p className="text-right text-xs text-muted">Carga del día</p>
        </div>

        <CoachNote text={workout.coachNote} />

        {summary ? (
          <p className="border-l-2 border-success pl-3 text-sm">
            <span className="eyebrow block text-success">Completado</span>
            {summary.durationMin} min · RPE {summary.rpe} · {summary.setsCompleted} series registradas
          </p>
        ) : (
          started && (
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-surface2">
              <div className="h-full rounded-full bg-accent" style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
          )
        )}

        <div className="space-y-2">
          <button type="button" onClick={() => onStart(workout.id)} className="btn-primary w-full">
            {summary ? (
              <>
                <RotateCcw className="h-5 w-5" aria-hidden="true" /> Repasar la sesión
              </>
            ) : started ? (
              <>
                <Play className="h-5 w-5" aria-hidden="true" /> Retomar · {Math.round(progress * 100)} %
              </>
            ) : (
              <>
                <Play className="h-5 w-5" aria-hidden="true" /> Comenzar entrenamiento
              </>
            )}
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setShowActivity((s) => !s)}
              className="btn-ghost whitespace-nowrap"
              aria-label="Cambiar la actividad de mañana"
            >
              <Flag className="h-4 w-4 shrink-0" aria-hidden="true" /> Mañana
            </button>
            <button
              type="button"
              onClick={() => onOnePager(workout.id)}
              className="btn-ghost whitespace-nowrap"
              aria-label="Abrir la vista One Pager"
            >
              <FileText className="h-4 w-4 shrink-0" aria-hidden="true" /> One Pager
            </button>
          </div>
        </div>

        {showActivity && (
          <div className="space-y-2 border-t border-line pt-4">
            <p className="eyebrow">Mañana · {longDate(tomorrow)}</p>
            <ActivitySelector
              value={tomorrowActivity}
              onChange={(a) => app.setOverride(tomorrow, a)}
              onClear={tomorrowOverride ? () => app.setOverride(tomorrow, null) : undefined}
            />
          </div>
        )}
      </Card>

      <section>
        <div className="band mb-2">
          <span className="band-label">La sesión</span>
          <span className="band-rule" />
          <button
            type="button"
            onClick={() =>
              setOpenBlocks(
                expandedBlocks.length === workout.blocks.length ? [] : workout.blocks.map((b) => b.id),
              )
            }
            className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted hover:text-ink"
          >
            {expandedBlocks.length === workout.blocks.length ? 'Plegar todo' : `${workout.blocks.length} bloques`}
          </button>
        </div>
        <div className="space-y-2">
          {workout.blocks.map((block, i) => (
            <WorkoutBlockCard
              key={block.id}
              block={block}
              expanded={expandedBlocks.includes(block.id)}
              onToggle={() => toggleBlock(block.id)}
              onOpen={() => onStart(workout.id, i)}
            />
          ))}
          {extras.length > 0 && (
            <p className="rounded-xl border border-dashed border-line p-3 text-sm text-muted">
              {extras.length} ejercicio{extras.length > 1 ? 's' : ''} agregado{extras.length > 1 ? 's' : ''} desde la
              biblioteca se suma{extras.length > 1 ? 'n' : ''} como bloque Extra al final de la sesión.
            </p>
          )}
        </div>
      </section>

      <ReadinessSelector readiness={readiness} onChange={(p) => app.setReadiness(today, p)} />

      <AdaptiveSessionPanel
        selected={selected}
        onChange={(ids) => app.setAdjustments(today, ids)}
        readiness={readiness}
        workout={workout}
      />
    </div>
  );
};
