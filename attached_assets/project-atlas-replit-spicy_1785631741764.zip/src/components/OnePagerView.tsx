import { ArrowLeft, Printer } from 'lucide-react';
import type { Workout } from '../types';
import { longDate } from '../lib/date';
import { ACTIVITY_LABEL } from '../data/program';
import { TideLevel, TideMark, Wordmark } from './ui2';
import { ModuleBadge } from './ModuleBadge';
import { PHASES } from '../data/program';
import { BlockSheet, CoachNote } from './workout-parts';

const Meta = ({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) => (
  <div>
    <p className="eyebrow">{label}</p>
    <p className={`font-mono text-sm ${accent ? 'text-accent' : 'text-ink'}`}>{value}</p>
  </div>
);

export const OnePagerView = ({ workout, onBack }: { workout: Workout; onBack: () => void }) => (
  <div className="min-h-screen bg-base">
    <div className="mx-auto max-w-3xl px-4 pb-10 pt-[calc(env(safe-area-inset-top)+1rem)]">
      <div className="mb-4 flex items-center justify-between no-print">
        <button type="button" onClick={onBack} className="btn-quiet px-1">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Volver
        </button>
        <button type="button" onClick={() => window.print()} className="btn-ghost">
          <Printer className="h-4 w-4" aria-hidden="true" /> Imprimir o guardar en PDF
        </button>
      </div>

      <article className="print-page overflow-hidden rounded-3xl border border-line bg-surface">
        <span aria-hidden="true" className="tide-gradient block h-1 w-full" />

        <header className="border-b border-line p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <TideMark />
              <Wordmark size="sm" />
            </div>
            <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted">
              W{workout.week} · D{workout.day}
            </p>
          </div>

          <p className="eyebrow mt-6">
            {longDate(workout.date)} · Fase {workout.phase} ·{' '}
            {(PHASES.find((p) => p.id === workout.phase) ?? PHASES[0]).name}
          </p>
          <h1 className="mt-1 font-display text-[2.5rem] font-bold leading-[0.95] tracking-[-0.035em]">
            {workout.name}
          </h1>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-line px-3 py-1 text-xs text-muted">
              {workout.subtitle}
            </span>
            {workout.modules.map((m) => (
              <ModuleBadge key={m} module={m} size="sm" />
            ))}
          </div>

          <div className="mt-5 grid grid-cols-2 gap-4 border-t border-line pt-4 sm:grid-cols-4">
            <Meta label="Duración" value={workout.duration} />
            <Meta label="RPE objetivo" value={workout.plannedRpe} accent />
            <Meta label="Bloques" value={String(workout.blocks.length)} />
            <Meta
              label="Mañana"
              value={workout.nextDayActivity ? ACTIVITY_LABEL[workout.nextDayActivity] : '—'}
            />
          </div>
          <div className="mt-3">
            <TideLevel plannedRpe={workout.plannedRpe} />
          </div>
        </header>

        <div className="space-y-6 p-6">
          <section>
            <div className="band mb-1.5">
              <span className="band-label">Objetivo</span>
              <span className="band-rule" />
            </div>
            <p className="text-sm leading-relaxed text-ink/90">{workout.objective}</p>
          </section>

          <CoachNote text={workout.coachNote} />

          <div className="space-y-5">
            {workout.blocks.map((block) => (
              <BlockSheet key={block.id} block={block} />
            ))}
          </div>

          <section>
            <div className="band mb-1.5">
              <span className="band-label">Registrar</span>
              <span className="band-rule" />
            </div>
            <p className="text-sm text-muted">
              Carga y repeticiones por serie · RPE de la sesión · energía y dolor al terminar · sensación final
              (fresco, justo o destruido).
            </p>
          </section>
        </div>

        <footer className="flex items-center justify-between border-t border-line px-6 py-4">
          <p className="eyebrow">TIDE · High Performance Training System</p>
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted">
            W{workout.week}D{workout.day}
          </p>
        </footer>
      </article>
    </div>
  </div>
);
