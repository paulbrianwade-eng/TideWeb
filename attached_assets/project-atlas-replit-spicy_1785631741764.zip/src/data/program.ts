import type { ExercisePrescription, SportActivity, SportModule, Workout, WorkoutBlock } from '../types';
import { addDays, todayISO } from '../lib/date';
import { isDeload, phaseFor } from './phases';
import { block } from './blocks';

export const TOTAL_WEEKS = 16;
export const PROGRAM_START = todayISO();

export const ACTIVITY_LABEL: Record<SportActivity, string> = {
  surf: 'Surf', golf: 'Golf', ski: 'Esquí', running: 'Running', rest: 'Descanso', gym: 'Gimnasio', home: 'Entrenamiento en casa',
};

const p = (exerciseId: string, extra: Partial<ExercisePrescription> = {}): ExercisePrescription => ({ exerciseId, ...extra });
const B = (id:string, kind:WorkoutBlock['kind'], title:string, duration:string, items:ExercisePrescription[], focus:string, extra:Partial<WorkoutBlock>={}) =>
  block(id, kind, title, duration, items, { focus, ...extra });

const reset = (id:string, upper=false) => B(`${id}-reset`,'reset','Reset + Movement','6 min', upper ? [
  p('nasal-breathing',{duration:'60 s',instructions:'Inhalá 4 s · exhalá 6 s.'}),
  p('open-book',{reps:'6/lado',unilateral:true}), p('scapular-push-up',{reps:'10'}), p('dead-bug',{reps:'6/lado',unilateral:true}),
] : [
  p('nasal-breathing',{duration:'60 s'}), p('hip-9090',{reps:'6 cambios'}), p('worlds-greatest-stretch',{reps:'4/lado',unilateral:true}), p('monster-walk',{reps:'10 pasos/lado',unilateral:true}),
], upper ? 'Hombro, tórax y core' : 'Cadera, tobillo y activación');

const powerMenus = [
  [p('box-jump',{sets:3,reps:'3',rest:'45 s'}),p('rotational-mb-throw',{sets:3,reps:'4/lado',unilateral:true})],
  [p('broad-jump',{sets:3,reps:'3',rest:'45 s'}),p('lateral-bound',{sets:3,reps:'4/lado',unilateral:true})],
  [p('mb-slam',{sets:3,reps:'5'}),p('rotational-mb-throw',{sets:3,reps:'4/lado',unilateral:true})],
  [p('pogo-jump',{sets:3,reps:'15 contactos'}),p('box-jump',{sets:3,reps:'3'})],
];
const power = (id:string,week:number) => B(`${id}-power`,'power','Power','5 min',powerMenus[(week-1)%powerMenus.length],'Velocidad máxima; cortar si cae la potencia');

const recovery = (id:string) => B(`${id}-recovery`,'recovery','Recovery','2 min',[
  p('nasal-breathing',{duration:'2 min',instructions:'Exhalación larga para bajar pulsaciones.'}),
],'Bajar revoluciones');

const lowerAthletic = (id:string,week:number) => {
  const menus = [
    [p('split-squat-hold',{duration:'30 s/lado',unilateral:true,isometric:true}),p('step-down',{reps:'8/lado',unilateral:true,instructions:'Bajada de 3 s.'}),p('soleus-raise',{reps:'18'})],
    [p('wall-sit',{duration:'45 s',isometric:true}),p('lateral-lunge',{reps:'8/lado',unilateral:true}),p('copenhagen-plank',{duration:'20 s/lado',unilateral:true,isometric:true})],
    [p('spanish-squat',{duration:'40 s',isometric:true}),p('single-leg-rdl',{reps:'8/lado',unilateral:true,load:'KB 20 kg si la técnica es sólida'}),p('tibialis-raise',{reps:'20'})],
    [p('reverse-nordic',{reps:'8',instructions:'Descenso lento'}),p('hip-airplane',{reps:'5/lado',unilateral:true}),p('side-plank',{duration:'25 s/lado',unilateral:true,isometric:true})],
  ];
  return B(`${id}-athletic`,'athletic','Ski Athletic Block','10 min',menus[(week-1)%4],'Resistencia excéntrica, isométrica y plano frontal',{rounds:isDeload(week)?'2 rondas':'3 rondas',rest:'30–45 s'});
};

const upperAthletic = (id:string,week:number) => {
  const menus = [
    [p('trx-row',{reps:'10–12'}),p('pallof-press',{reps:'10/lado',unilateral:true}),p('bottom-up-carry',{distance:'20 m/lado',unilateral:true,carry:true})],
    [p('ytwl',{reps:'6 de cada letra',load:'3 kg o sin carga'}),p('bear-crawl',{distance:'10 m ida y vuelta'}),p('suitcase-carry',{distance:'25 m/lado',unilateral:true,carry:true})],
    [p('trx-row',{reps:'12'}),p('dead-bug',{reps:'10/lado',unilateral:true}),p('single-arm-farmer',{distance:'25 m/lado',unilateral:true,carry:true})],
    [p('scapular-push-up',{reps:'12'}),p('dead-bug',{reps:'8/lado',unilateral:true}),p('bottom-up-carry',{distance:'20 m/lado',unilateral:true,carry:true})],
  ];
  return B(`${id}-athletic`,'athletic','Surf Athletic Block','10 min',menus[(week-1)%4],'Escápula, antirotación y resistencia de hombro',{rounds:isDeload(week)?'2 rondas':'3 rondas',rest:'30–45 s'});
};

const golfAthletic = (id:string,week:number) => {
  const menus = [
    [p('rotational-mb-throw',{reps:'5/lado',unilateral:true}),p('pallof-press',{reps:'10/lado',unilateral:true}),p('hip-airplane',{reps:'5/lado',unilateral:true})],
    [p('landmine-rotation',{reps:'8/lado',unilateral:true,load:'Barra sola o carga mínima'}),p('single-leg-rdl',{reps:'8/lado',unilateral:true}),p('suitcase-carry',{distance:'25 m/lado',unilateral:true,carry:true})],
    [p('lateral-bound',{reps:'5/lado',unilateral:true}),p('rotational-mb-throw',{reps:'5/lado',unilateral:true}),p('side-plank',{duration:'25 s/lado',unilateral:true,isometric:true})],
    [p('mb-slam',{reps:'8'}),p('pallof-press',{reps:'10/lado',unilateral:true}),p('hip-airplane',{reps:'5/lado',unilateral:true})],
  ];
  return B(`${id}-athletic`,'athletic','Golf Athletic Block','10 min',menus[(week-1)%4],'Rotación rápida y desaceleración controlada',{rounds:isDeload(week)?'2 rondas':'3 rondas',rest:'30–45 s'});
};

const runEngine = (id:string,week:number,kind:'zone2'|'intervals'|'hybrid') => {
  if(kind==='zone2') return B(`${id}-engine`,'engine','Engine','30 min',[p('zone2-run',{duration:'30 min',rpe:'5',instructions:'Ritmo conversacional; alterná trote/caminata si hace falta.'})],'Base aeróbica');
  if(kind==='intervals') return B(`${id}-engine`,'engine','Engine','8 min',[p('threshold-run',{sets:8,duration:'30 s rápido / 30 s caminar',rpe:'8'})],'Pasadas cortas, técnica estable');
  return B(`${id}-engine`,'engine','Engine','8 min',[
    p('threshold-run',{sets:8,duration:'30 s rápido / 30 s caminar',rpe:'7–8',alternatives:['Soga','Shuttle run 20 m']}),
  ],'Acondicionamiento sin máquinas');
};


const spicyFinisher = (id:string, week:number, type:'ski'|'surf'|'rotate'|'hybrid') => {
  const deload = isDeload(week);
  const duration = deload ? '7 min' : '9 min';
  if(type==='ski') return B(`${id}-engine`,'engine','FINISHER // Ski Burner',duration,[
    p('wall-sit',{duration:'35 s'}),
    p('reverse-lunge',{reps:'8/lado',unilateral:true,load:'MB 10 kg o KB 20 kg'}),
    p('mb-slam',{reps:'10',load:'MB 10 kg'}),
    p('threshold-run',{duration:'30 s rápido',alternatives:['Soga rápida 45 s','Shuttle run 20 m']})
  ],'Cuádriceps bajo fatiga + pulsaciones altas',{rounds:deload?'2 rondas':'AMRAP 9 min',rest:'Solo lo necesario · RPE 8–9'});
  if(type==='surf') return B(`${id}-engine`,'engine','FINISHER // Surf Engine',duration,[
    p('trx-row',{reps:'10'}),
    p('scapular-push-up',{reps:'12'}),
    p('mb-slam',{reps:'10',load:'MB 10 kg'}),
    p('threshold-run',{duration:'30 s rápido',alternatives:['Soga rápida 45 s']})
  ],'Tren superior resistente + motor',{rounds:deload?'2 rondas':'AMRAP 9 min',rest:'Solo lo necesario · RPE 8–9'});
  if(type==='rotate') return B(`${id}-engine`,'engine','FINISHER // Rotate Fast',duration,[
    p('rotational-mb-throw',{reps:'5/lado',unilateral:true,load:'MB 5 kg'}),
    p('lateral-bound',{reps:'6/lado',unilateral:true}),
    p('mb-slam',{reps:'8',load:'MB 10 kg'}),
    p('threshold-run',{duration:'40 s rápido / 20 s caminar'})
  ],'Potencia rotacional repetida + desaceleración',{rounds:deload?'2 rondas':'AMRAP 9 min',rest:'Calidad alta · RPE 8–9'});
  return B(`${id}-engine`,'engine','FINISHER // Red Line',deload?'8 min':'10 min',[
    p('mb-slam',{reps:'10',load:'MB 10 kg'}),
    p('reverse-lunge',{reps:'8/lado',unilateral:true,load:'KB 20 kg'}),
    p('trx-row',{reps:'10'}),
    p('threshold-run',{duration:'45 s rápido',alternatives:['Soga rápida 60 s','Shuttle run 20 m']})
  ],'Full body conditioning medible',{rounds:deload?'AMRAP 8 min':'AMRAP 10 min',rest:'Sin descanso fijo · RPE 9'});
};

interface DayPlan { name:string; subtitle:string; objective:string; duration:string; rpe:string; next:SportActivity|null; modules:SportModule[]; external?:SportActivity; build:(id:string,week:number)=>WorkoutBlock[]; note:(week:number)=>string; }

const DAYS:DayPlan[] = [
  { name:'BUILD // Ski Legs', subtitle:'Lower strength · Ski endurance', objective:'Construir fuerza y resistencia específica de piernas para esquiar sin perder control.', duration:'49–50 min', rpe:'7–8', next:'gym', modules:['ski'], build:(id,w)=>[
    reset(id), power(id,w),
    B(`${id}-strength`,'strength','Strength','20 min',[p(w%2?'back-squat':'front-squat',{sets:isDeload(w)?3:5,reps:isDeload(w)?'5':'5',rpe:isDeload(w)?'6':'7–8',rest:'2 min'}),p('tibialis-raise',{sets:4,reps:'15',instructions:'Hacer durante los descansos; no requiere cambiar la barra.'})],'Una sola configuración de barra'),
    lowerAthletic(id,w), spicyFinisher(id,w,'ski'), recovery(id)
  ], note:()=> 'Una barra, una carga principal. Después: resistencia específica y un finisher picante de 9 minutos para que las piernas aprendan a rendir con pulsaciones altas.' },

  { name:'CONTROL // Surf Upper', subtitle:'Upper strength · Scapular endurance', objective:'Aumentar fuerza de empuje y tracción, estabilidad escapular y capacidad de remada.', duration:'49–50 min', rpe:'7–8', next:'running', modules:['surf'], build:(id,w)=>[
    reset(id,true), power(id,w+1),
    B(`${id}-strength`,'strength','Strength','20 min',[p('bench-press',{sets:isDeload(w)?3:5,reps:'5',rpe:isDeload(w)?'6':'7–8',rest:'90 s'}),p('pull-up',{sets:isDeload(w)?3:5,reps:'5–8',rpe:'8',instructions:'Alternar con bench; la barra queda cargada.'})],'Bench + dominadas, sin cambio de discos'),
    upperAthletic(id,w), spicyFinisher(id,w,'surf'), recovery(id)
  ], note:()=> 'El bench es la única estación con barra. Terminamos con un bloque corto y fuerte: respiración alta, técnica limpia y una ronda en reserva.' },

  { name:'FLOW // Run Base', subtitle:'Running mechanics · Zone 2', objective:'Mejorar mecánica, pie y tobillo mientras construís la base para un 10K cómodo.', duration:'48–50 min', rpe:'5–6', next:'gym', modules:['running'], build:(id,w)=>[
    B(`${id}-reset`,'reset','Run Prep','8 min',[p('nasal-breathing',{duration:'60 s'}),p('foot-activation',{duration:'60 s'}),p('pogo-jump',{sets:2,reps:'15'}),p('bounding',{sets:2,distance:'20 m'}),p('hip-cars',{reps:'3/lado',unilateral:true})],'Técnica y rigidez de tobillo'),
    B(`${id}-engine`,'engine','Zone 2','24 min',[p('zone2-run',{duration:'24 min',rpe:'5',instructions:'Ritmo conversacional; alterná trote/caminata si hace falta.'})],'Base aeróbica'),
    B(`${id}-athletic`,'athletic','Durability','6 min',[p('soleus-raise',{sets:2,reps:'20'}),p('tibialis-raise',{sets:2,reps:'20'}),p('hip-flexor-stretch',{duration:'40 s/lado',unilateral:true})],'Pie, sóleo y cadera'),
    B(`${id}-finisher`,'engine','FINISHER // Fast Finish','8 min',[p('threshold-run',{sets:8,duration:'30 s fuerte / 30 s suave',rpe:'8–9'})],'Cerrar con velocidad sin sprint máximo'), recovery(id)
  ], note:()=> 'La base va primero; el cierre rápido levanta pulsaciones sin convertir todo el día en HIIT: es terminar más fresco de lo que empezaste y acumular minutos de calidad.' },

  { name:'ROTATE // Golf Athlete', subtitle:'Rotation · Unilateral control · Power', objective:'Generar velocidad rotacional y frenarla con control para transferir potencia al swing.', duration:'47–50 min', rpe:'7–8', next:'gym', modules:['golf'], build:(id,w)=>[
    reset(id), power(id,w+2),
    B(`${id}-strength`,'strength','Strength','18 min',[p('single-leg-rdl',{sets:4,reps:'8/lado',unilateral:true,load:'KB 20 kg'}),p('trx-row',{sets:4,reps:'10–12',rpe:'7–8'})],'Unipodal + empuje, sin barra'),
    golfAthletic(id,w), spicyFinisher(id,w,'rotate'), recovery(id)
  ], note:()=> 'La velocidad se entrena fresco. Los lanzamientos deben sonar y sentirse rápidos; frená antes de que pierdan calidad.' },

  { name:'PERFORM // Hybrid', subtitle:'Full body · Work capacity', objective:'Sostener técnica bajo fatiga usando kettlebell, TRX, medicine ball y carrera.', duration:'45–48 min', rpe:'8', next:'surf', modules:[], build:(id,w)=>[
    reset(id), power(id,w+3),
    B(`${id}-strength`,'strength','Strength Density','18 min',[p('reverse-lunge',{sets:4,reps:'8/lado',unilateral:true,load:'KB 20 kg'}),p('trx-row',{sets:4,reps:'10–12'})],'Superserie simple, estación rápida'),
    B(`${id}-athletic`,'athletic','Athletic Control','8 min',[p('bear-crawl',{distance:'10 m'}),p('suitcase-carry',{distance:'20 m/lado',unilateral:true,carry:true}),p('dead-bug',{reps:'8/lado',unilateral:true})],'Control antes de acelerar',{rounds:'2–3 rondas',rest:'30 s'}),
    spicyFinisher(id,w,'hybrid'), recovery(id)
  ], note:()=> 'Hoy sí buscamos intensidad: RPE 9 en el finisher, pero sin regalar postura ni control por una ronda extra.' },

  { name:'PLAY // Outdoor', subtitle:'Surf · Golf · Running · Ski', objective:'Usar las capacidades entrenadas en el deporte o actividad que elijas.', duration:'Actividad libre', rpe:'6–8', next:'rest', modules:[], external:'surf', build:(id)=>[
    B(`${id}-prep`,'movement','Outdoor Prep','10 min',[p('hip-9090',{reps:'8 cambios'}),p('worlds-greatest-stretch',{reps:'4/lado',unilateral:true}),p('monster-walk',{reps:'10 pasos/lado',unilateral:true}),p('pogo-jump',{reps:'15'})],'Preparación antes de salir')
  ], note:()=> 'Elegí deporte, no castigo. El sábado suma experiencia y disfrute; no tiene que compensar nada.' },

  { name:'RESTORE', subtitle:'Mobility · Down regulation', objective:'Recuperar tejidos, movilidad y sistema nervioso para comenzar bien la semana.', duration:'20–30 min', rpe:'2–3', next:'gym', modules:[], build:(id)=>[
    B(`${id}-restore`,'recovery','Restore Flow','25 min',[p('nasal-breathing',{duration:'3 min'}),p('hip-flow',{duration:'5 min'}),p('open-book',{reps:'8/lado',unilateral:true}),p('hip-flexor-stretch',{duration:'45 s/lado',unilateral:true}),p('easy-walk',{duration:'15 min'})],'Recuperación real')
  ], note:()=> 'Si estás muy cansado, hacé solo respiración y caminata. Recuperar también es entrenar.' },
];

export const WEEK_STRUCTURE = DAYS.map(d=>({name:d.name,subtitle:d.subtitle}));
const buildWorkout=(week:number,dayIndex:number,date:string):Workout=>{ const plan=DAYS[dayIndex]; const id=`w${week}d${dayIndex+1}`; const blocks=plan.build(id,week); return {id,week,day:dayIndex+1,date,name:plan.name,subtitle:plan.subtitle,objective:plan.objective,duration:plan.duration,plannedRpe:isDeload(week)?'6':plan.rpe,coachNote:plan.note(week),nextDayActivity:plan.next,blocks,adaptations:[],status:plan.external?'external':'pending',externalActivity:plan.external,phase:phaseFor(week).id,modules:plan.modules}; };
export const buildProgram=(start:string=PROGRAM_START):Workout[]=>{ const out:Workout[]=[]; for(let w=1;w<=TOTAL_WEEKS;w++) for(let d=0;d<DAYS.length;d++) out.push(buildWorkout(w,d,addDays(start,(w-1)*7+d))); return out; };
export { phaseFor, weekInPhase, isDeload, PHASES } from './phases';
