import type { Phase } from '../types';

/**
 * Macrociclo de 16 semanas en cuatro bloques de cuatro.
 * Cada fase cambia el esquema de la fuerza principal, la potencia y el
 * volumen accesorio. Los módulos deportivos siguen presentes todas las
 * semanas: cambian de dosis, no desaparecen.
 */
export const PHASES: Phase[] = [
  {
    id: 1,
    name: 'Movement + Base',
    weeks: [1, 4],
    focus: 'Calidad de movimiento, tejido y volumen',
    strength: { sets: 4, reps: '8–10', rpe: '7', rest: '90 s' },
    power: { sets: 4, reps: '4', rest: '60 s', intent: 'Aprender la posición y aterrizar bien' },
    accessoryReps: '12–15',
    coachNote:
      'Fase de construcción. Más repeticiones, menos carga y foco absoluto en cómo se mueve cada patrón. Si algo se siente mal técnicamente, bajá el peso: todavía no es momento de forzar.',
  },
  {
    id: 2,
    name: 'Strength',
    weeks: [5, 8],
    focus: 'Fuerza máxima con tejido ya preparado',
    strength: { sets: 5, reps: '5', rpe: '7–8', rest: '2–3 min' },
    power: { sets: 4, reps: '3', rest: '75 s', intent: 'Velocidad con técnica sólida' },
    accessoryReps: '8–10',
    coachNote:
      'Acá se construye la fuerza que sostiene todo el resto del año. Descansos largos y series pesadas pero limpias: RPE 8 significa que te quedaban dos repeticiones.',
  },
  {
    id: 3,
    name: 'Power',
    weeks: [9, 12],
    focus: 'Velocidad, potencia y expresión de la fuerza',
    strength: { sets: 5, reps: '3', rpe: '8', rest: '3 min' },
    power: { sets: 5, reps: '3', rest: '90 s', intent: 'Máxima intención en cada repetición' },
    accessoryReps: '6–8',
    coachNote:
      'Menos repeticiones, más velocidad. Si la barra o el salto se ponen lentos, cortá la serie: entrenar potencia con fatiga es entrenar otra cosa.',
  },
  {
    id: 4,
    name: 'Athletic Performance',
    weeks: [13, 16],
    focus: 'Transferencia deportiva y resistencia específica',
    strength: { sets: 4, reps: '5', rpe: '7', rest: '2 min' },
    power: { sets: 4, reps: '3', rest: '75 s', intent: 'Potencia aplicada al deporte' },
    accessoryReps: '10–12',
    coachNote:
      'La fuerza baja un escalón para que suba la calidad atlética. Los módulos de esquí, surf y golf se llevan el protagonismo: es la fase que se nota en la nieve y en el agua.',
  },
];

export const phaseFor = (week: number): Phase => {
  const w = ((week - 1) % 16) + 1;
  return PHASES.find((p) => w >= p.weeks[0] && w <= p.weeks[1]) ?? PHASES[0];
};

/** Semana dentro de la fase (1-4). La cuarta es de descarga. */
export const weekInPhase = (week: number): number => {
  const w = ((week - 1) % 16) + 1;
  const p = phaseFor(w);
  return w - p.weeks[0] + 1;
};

export const isDeload = (week: number): boolean => weekInPhase(week) === 4;
