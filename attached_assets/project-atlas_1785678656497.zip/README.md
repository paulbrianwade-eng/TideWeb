# PROJECT ATLAS

**Athletic Performance System** — aplicación web personal de entrenamiento.

Responde una sola pregunta en menos de tres segundos: **¿qué entrenamiento me toca hoy?**

---

## Arrancar

```bash
npm install
npm run dev
```

Abre en `http://localhost:5173`. No necesita backend, base de datos, API keys ni autenticación.
Todo se guarda en `localStorage`.

### Subirlo a Replit

1. **Create Repl → Import from GitHub** (o arrastrá el ZIP en un Repl de Node.js vacío).
2. Replit detecta el `.replit` incluido y usa Node 20.
3. Botón **Run**. El `vite.config.ts` detecta el entorno (`REPL_ID` / `REPLIT_DEV_DOMAIN`) y
   escucha en `0.0.0.0` con `allowedHosts` abierto, así el webview funciona sin tocar nada.
4. Para publicar: **Deploy → Static**, build `npm run build`, carpeta `dist/`.

---

## La metodología

Cuatro bloques. Siempre los mismos, siempre en este orden.

| # | Bloque | Duración | Para qué está |
|---|---|---|---|
| 1 | **Zona media** | 7–9 min | Antiextensión, antirrotación, antiflexión lateral, rotación controlada. Nunca al fallo: prepara para el resto. |
| 2 | **Fuerza** | 15–18 min | Un principal + dos accesorios de transferencia. Nada más. |
| 3 | **Atleta** | 10–12 min | Sprint, saltos, cambios de dirección, carries, rotación. El bloque que te hace sentir atleta. |
| 4 | **Finisher** | 8–12 min | Obligatorio. RPE 8–9, medible y distinto cada día. |

**Ninguna sesión supera los 50 minutos.** El rango real del programa es 43–48 min, verificado por test.

### La semana

| Día | Sesión | Estación | Transfiere a |
|---|---|---|---|
| Lunes | **Strong Legs** · Ski Performance | Barra | Esquí, running |
| Martes | **Paddle Power** · Upper + Surf | Barra | Surf |
| Miércoles | **Run Fast** · Running Performance | Exterior | Running |
| Jueves | **Rotate** · Golf Performance | Barra | Golf, surf |
| Viernes | **Full Send** · Hybrid Athletic | Barra | Esquí, surf, running |
| Sábado | **Outdoor** | Exterior | Libre según temporada |
| Domingo | **Recovery** | Suelo | — |

Primera fase: **4 semanas** (28 sesiones). La cuarta semana es de descarga: una serie menos
en el principal y RPE 6. El finisher no se toca.

---

## La regla de la barra única

Tenés **una sola barra olímpica**. El programa está construido alrededor de esa limitación:

- **Una configuración de barra por sesión.** Se monta una vez y no se toca más.
- Después del principal con barra: TRX, bandas, kettlebells, medicine ball o peso corporal.
- Nunca sentadilla pesada y press pesado el mismo día.
- Cero cambios de altura de rack a mitad de bloque.

`qa/program.ts` **falla el build** si alguna sesión programa más de un ejercicio de barra cargada.

### Equipamiento real

Rack · barra de 20 kg · discos (2×20, 2×10, 2×5) · banco inclinable · TRX ·
kettlebells 8/12/20 · mancuernas 3/5 · medicine balls 5/10 · bandas largas · mini bands ·
rueda abdominal · soga · cajón pliométrico · espacio exterior.

**No existe**: assault bike, SkiErg, rower, trineo, poleas, máquinas, segunda barra.
El inventario vive en `src/data/equipment.ts` y el test verifica que ningún ejercicio de la
biblioteca pida algo fuera de esa lista.

---

## Temporizadores

Todos cuentan contra `Date.now()`, así que no se desincronizan si el teléfono suspende la pestaña.

- **Descanso** — cuenta regresiva a pantalla completa, anuncia el próximo ejercicio.
- **AMRAP** — regresivo con la lista de ejercicios siempre visible.
- **For Time / Chipper** — cronómetro ascendente.
- **Sprint intervals** — 20 s fuerte / 40 s caminata × 10.
- **40/20** — muestra ejercicio actual, próximo y vuelta actual; el fondo cambia de verde
  (trabajo) a negro (transición) como señal visual. Pausa, reanuda y reinicia.

### Los dos formatos Tabata

Se muestran con tu nomenclatura, sin renombrar:

- **TABATA EXPRESS** — 4 ejercicios · 40/20 · 2 vueltas · **8 minutos**.
  Se usa como finisher dentro de una sesión normal.
- **TABATA EXTENDIDO** — 8 ejercicios · 40/20 · 4 vueltas · **~32 minutos**.
  Sesión especial independiente. Un test verifica que nunca aparezca dentro de la semana normal.

---

## Adaptaciones

Antes de entrenar, la app pregunta: sueño, energía, dolor (y dónde), tiempo disponible,
lugar y deporte de mañana.

**No son sugerencias de texto.** Cada respuesta transforma los bloques antes de empezar,
y el panel muestra en vivo qué va a cambiar:

| Respuesta | Efecto real sobre la sesión |
|---|---|
| Dormiste menos de 6 h | Una vuelta menos en Atleta · fuerza limitada a RPE 7 · finisher intacto |
| Dolor lumbar | Deadlift → hip thrust · remo inclinado → inverted row · ab wheel → dead bug |
| Dolor de rodilla | Sentadilla → hip thrust · saltos → KB swing · step down → isométrico |
| Dolor de hombro | Press banca → push-up · press militar → KB press |
| Mañana esquío | Dos series menos en el principal · Atleta a 2 vueltas · core y potencia breve se mantienen |
| Mañana surfeo | Una serie menos en todo el trabajo de tracción · sin carries overhead |
| Mañana golf | Lanzamientos rotacionales a 3 repeticiones: velocidad sin fatiga |
| En casa | Todos los ejercicios de barra pasan a kettlebell, TRX o peso corporal |
| Solo 30 min | Zona media 5′ · Fuerza 12′ · Atleta 6′ · Finisher 7′ |

Las reglas se combinan. `qa/adaptations.ts` verifica cada una contra la sesión resultante.

---

## Estructura

```
src/
  data/
    equipment.ts        Inventario real, estaciones y cargas disponibles
    ex-helpers.ts       Constructor compacto de ejercicios
    ex-movement.ts      Movilidad y activación
    ex-strength.ts      Fuerza y potencia
    ex-modules.ts       Módulos deportivos, zona media, finishers y atleta
    exercises.ts        Índice unificado de los 108 ejercicios + link de video
    session-blocks.ts   Pools de Zona media, Atleta y Finishers · Tabata Extendido
    program.ts          Generador de las 28 sesiones · presupuesto de tiempo
    defaults.ts         Perfil y métricas iniciales
  lib/
    timers.ts           Motor de temporizadores (countdown, cronómetro, intervalos)
    adaptations.ts      Reglas que transforman la sesión
    prescription.ts     Progreso, series planificadas y completadas
    records.ts          Marcas personales
    storage.ts          Persistencia en localStorage
    date.ts             Utilidades de fecha
  components/
    AppShell.tsx        Navegación inferior (Hoy · Semana · Progreso · Biblioteca · Perfil)
    media.tsx           Sistema de imágenes con placeholders generativos
    workout-parts2.tsx  CollapsibleBlock y ExerciseRow
    timers.tsx          RestTimer, ClockTimer, IntervalTimer
    readiness.tsx       ReadinessCheck previo a la sesión
    EquipmentList.tsx   Checklist "HOY NECESITÁS"
    ScoreInput.tsx      Registro del score del finisher
    WorkoutSummaryModal.tsx  Resumen con coach feedback automático
  screens/
    TodayScreen.tsx     Hero, coach note, equipamiento, vista previa de bloques
    WeekScreen.tsx      La semana como colección de tarjetas
    SessionScreen.tsx   Modo entrenamiento (vista bloque y vista ejercicio)
    ProgressScreen.tsx  Métricas e historial
    LibraryScreen.tsx   Biblioteca de ejercicios
    ProfileScreen.tsx   Perfil y restablecer datos
qa/                     Suite de verificación (ver abajo)
```

---

## Imágenes

La app **no depende de ninguna URL externa**. Cada sesión y cada ejercicio dibuja un
placeholder generativo en SVG: determinista, monocromo, con la paleta del bloque.

Para poner tus fotos:

1. Copiá los archivos a `public/img/`.
2. Agregá la entrada en el mapa `IMAGES` de `src/components/media.tsx`:

```ts
export const IMAGES: Record<string, string> = {
  'w1d1': '/img/strong-legs.jpg',
  'box-squat': '/img/box-squat.jpg',
};
```

Las claves válidas son el id de la sesión (`w1d1`), el día (`day-1`) o el id del ejercicio.

> Los videos de técnica son **links de búsqueda**, no archivos alojados. El campo `video`
> de cada ejercicio se puede reemplazar por una URL propia cuando grabes tu biblioteca.

---

## Verificación

```bash
npm run qa
```

Corre la suite completa contra el build real:

- **`qa/flow.mjs`** — 36 verificaciones del recorrido completo: Hoy → preguntas previas →
  bloques → registrar series → descanso → finisher → score → resumen → historial.
- **`qa/buttons.mjs`** — hace clic en todos los botones de todas las pantallas y reporta
  los que no tienen efecto visible o carecen de nombre accesible.
- **`qa/persist.mjs`** — inyecta un estado guardado, recarga y verifica que se restaure.
- **`qa/program.ts`** — audita las reglas duras: cuatro bloques en orden, techo de 50 min,
  finisher con score, equipamiento real, una sola barra por sesión, sin técnicos pesados
  en el finisher, Tabata Extendido fuera de la semana.
- **`qa/adaptations.ts`** — verifica que cada regla transforme la sesión de verdad.
- **`qa/timers.mjs`** — verifica la matemática de los formatos (Express = 8 min,
  Extendido ≈ 32 min, sprint intervals = 10 min).

Estado actual: **36/36** en el flujo · **0** botones muertos · **0** errores de consola ·
todas las auditorías en verde · `tsc --noEmit` sin errores.

---

## Paleta

| Rol | Color |
|---|---|
| Verde principal | `#087F5B` |
| Verde oscuro | `#056647` |
| Verde brillante (encabezados de bloque) | `#B8FF72` |
| Verde muy claro | `#E9FFD7` |
| Fondo | `#F4F5F2` |
| Superficie | `#FFFFFF` |
| Texto | `#161816` |
| Texto secundario | `#6E746F` |
| Borde | `#DDE2DC` |

Tipografías open source: **Archivo Narrow** para títulos, **Inter** para texto.
