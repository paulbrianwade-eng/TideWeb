import type { CompletedSet, WorkoutSession, Workout, WorkoutBlock } from '../types';

export const setKey = (blockId: string, index: number) => `${blockId}:${index}`;

/** Cuántas entradas de series debería tener un ejercicio. */
export const plannedSets = (item: WorkoutBlock['items'][number], block: WorkoutBlock): number =>
  item.sets ?? block.rounds ?? 3;

export const totalPlannedSets = (workout: Workout): number =>
  workout.blocks.reduce(
    (sum, b) => sum + b.items.reduce((s, it) => s + plannedSets(it, b), 0),
    0,
  );

export const completedSets = (session?: WorkoutSession): number =>
  session ? (Object.values(session.sets) as CompletedSet[][]).flat().filter((s) => s.done).length : 0;

export const sessionProgress = (workout: Workout, session?: WorkoutSession): number => {
  if (!session) return 0;
  const total = totalPlannedSets(workout);
  return total ? Math.min(1, completedSets(session) / total) : 0;
};

/** Ejercicios marcados como completos, por clave bloque:índice. */
export const doneKeys = (session?: WorkoutSession): string[] => {
  if (!session) return [];
  return Object.entries(session.sets)
    .filter(([, sets]) => (sets as CompletedSet[]).length > 0 && (sets as CompletedSet[]).every((s) => s.done))
    .map(([k]) => k);
};
