import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

/**
 * Motor de temporizadores. Un solo hook para todos los formatos: cuenta el
 * tiempo contra `Date.now()`, así no se desincroniza si el teléfono suspende
 * la pestaña o la app pasa a segundo plano.
 */
export type TimerMode = 'countdown' | 'stopwatch' | 'interval';

export interface IntervalStep {
  label: string;
  seconds: number;
  kind: 'work' | 'pause';
  /** Qué viene después, para anunciarlo en pantalla. */
  next?: string;
  round: number;
}

export interface TimerState {
  running: boolean;
  /** Segundos transcurridos desde el arranque. */
  elapsed: number;
  /** Segundos restantes (countdown e interval). */
  remaining: number;
  finished: boolean;
  /** Paso actual en modo intervalos. */
  step?: IntervalStep;
  stepIndex: number;
  totalSteps: number;
}

export const formatClock = (totalSeconds: number): string => {
  const s = Math.max(0, Math.round(totalSeconds));
  const m = Math.floor(s / 60);
  const rest = s % 60;
  return `${String(m).padStart(2, '0')}:${String(rest).padStart(2, '0')}`;
};

/** Construye la secuencia de un 40/20: trabajo y pausa por ejercicio, por vuelta. */
export const buildIntervalSteps = (
  exercises: string[],
  { work, pause, rounds }: { work: number; pause: number; rounds: number },
): IntervalStep[] => {
  const steps: IntervalStep[] = [];
  for (let r = 1; r <= rounds; r += 1) {
    exercises.forEach((name, i) => {
      const isLast = r === rounds && i === exercises.length - 1;
      const nextName = i + 1 < exercises.length ? exercises[i + 1] : r < rounds ? exercises[0] : undefined;
      steps.push({ label: name, seconds: work, kind: 'work', next: nextName, round: r });
      if (!isLast) steps.push({ label: 'Transición', seconds: pause, kind: 'pause', next: nextName, round: r });
    });
  }
  return steps;
};

export const useTimer = ({
  mode,
  seconds = 0,
  steps = [],
  onFinish,
  autoStart = false,
}: {
  mode: TimerMode;
  /** Duración para countdown. */
  seconds?: number;
  /** Secuencia para modo intervalos. */
  steps?: IntervalStep[];
  onFinish?: () => void;
  autoStart?: boolean;
}) => {
  const [running, setRunning] = useState(autoStart);
  const [elapsed, setElapsed] = useState(0);
  const [finished, setFinished] = useState(false);
  const anchor = useRef<number | null>(null);
  const accumulated = useRef(0);
  const finishRef = useRef(onFinish);
  finishRef.current = onFinish;

  const totalIntervalSeconds = useMemo(() => steps.reduce((s, x) => s + x.seconds, 0), [steps]);
  const totalSeconds = mode === 'interval' ? totalIntervalSeconds : seconds;

  useEffect(() => {
    if (!running) return undefined;
    anchor.current = Date.now();
    const tick = () => {
      const base = accumulated.current + (Date.now() - (anchor.current ?? Date.now())) / 1000;
      setElapsed(base);
    };
    const h = window.setInterval(tick, 200);
    tick();
    return () => window.clearInterval(h);
  }, [running]);

  // Fin por tiempo agotado
  useEffect(() => {
    if (finished || mode === 'stopwatch' || totalSeconds <= 0) return;
    if (elapsed >= totalSeconds) {
      setFinished(true);
      setRunning(false);
      accumulated.current = totalSeconds;
      setElapsed(totalSeconds);
      finishRef.current?.();
    }
  }, [elapsed, finished, mode, totalSeconds]);

  const start = useCallback(() => {
    if (finished) return;
    accumulated.current = elapsed;
    setRunning(true);
  }, [elapsed, finished]);

  const pause = useCallback(() => {
    accumulated.current = elapsed;
    setRunning(false);
  }, [elapsed]);

  const reset = useCallback(() => {
    accumulated.current = 0;
    anchor.current = null;
    setElapsed(0);
    setFinished(false);
    setRunning(false);
  }, []);

  const toggle = useCallback(() => (running ? pause() : start()), [running, pause, start]);

  // Paso actual en modo intervalos
  const { step, stepIndex, stepRemaining } = useMemo(() => {
    if (mode !== 'interval' || !steps.length) {
      return { step: undefined, stepIndex: 0, stepRemaining: 0 };
    }
    let acc = 0;
    for (let i = 0; i < steps.length; i += 1) {
      const end = acc + steps[i].seconds;
      if (elapsed < end) return { step: steps[i], stepIndex: i, stepRemaining: end - elapsed };
      acc = end;
    }
    const last = steps[steps.length - 1];
    return { step: last, stepIndex: steps.length - 1, stepRemaining: 0 };
  }, [mode, steps, elapsed]);

  const state: TimerState = {
    running,
    elapsed,
    remaining: mode === 'stopwatch' ? 0 : mode === 'interval' ? stepRemaining : Math.max(0, totalSeconds - elapsed),
    finished,
    step,
    stepIndex,
    totalSteps: steps.length,
  };

  return { ...state, start, pause, reset, toggle, totalSeconds };
};
