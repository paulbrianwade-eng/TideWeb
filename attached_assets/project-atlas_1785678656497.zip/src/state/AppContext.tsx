import { useCallback, createContext, useContext, useEffect, useMemo, useReducer } from 'react';
import type { ReactNode } from 'react';
import type {
  AppState,
  FinisherScore,
  CompletedSet,
  DailyReadiness,
  MetricEntry,
  NutritionDay,
  NutritionDayType,
  SessionSummary,
  SportActivity,
  UserProfile,
  Workout,
  WorkoutSession,
} from '../types';
import { clearState, emptyState, loadState, saveState } from '../lib/storage';
import { buildProgram } from '../data/program';
import { todayISO } from '../lib/date';

type Action =
  | { type: 'profile'; payload: Partial<UserProfile> }
  | { type: 'readiness'; date: string; payload: Partial<DailyReadiness> }
  | { type: 'adjustments'; date: string; payload: string[] }
  | { type: 'session'; workoutId: string; payload: WorkoutSession }
  | { type: 'summary'; payload: SessionSummary }
  | { type: 'override'; date: string; activity: SportActivity | null }
  | { type: 'metric'; metricId: string; entry: MetricEntry }
  | { type: 'nutrition'; date: string; payload: Partial<NutritionDay> }
  | { type: 'extra'; date: string; exerciseId: string }
  | { type: 'screen'; payload: string }
  | { type: 'reset' };

const defaultReadiness: DailyReadiness = { energy: null, sleep: null, pain: null, motivation: null };

const reducer = (state: AppState, action: Action): AppState => {
  switch (action.type) {
    case 'profile':
      return { ...state, profile: { ...state.profile, ...action.payload } };
    case 'readiness':
      return {
        ...state,
        readiness: {
          ...state.readiness,
          [action.date]: { ...defaultReadiness, ...state.readiness[action.date], ...action.payload },
        },
      };
    case 'adjustments':
      return { ...state, adjustments: { ...state.adjustments, [action.date]: action.payload } };
    case 'session':
      return { ...state, sessions: { ...state.sessions, [action.workoutId]: action.payload } };
    case 'summary':
      return {
        ...state,
        history: [action.payload, ...state.history.filter((h) => h.workoutId !== action.payload.workoutId)],
      };
    case 'override': {
      const next = { ...state.calendarOverrides };
      if (action.activity === null) delete next[action.date];
      else next[action.date] = action.activity;
      return { ...state, calendarOverrides: next };
    }
    case 'metric': {
      const list = state.metrics[action.metricId] ?? [];
      const filtered = list.filter((x) => x.date !== action.entry.date);
      return {
        ...state,
        metrics: {
          ...state.metrics,
          [action.metricId]: [...filtered, action.entry].sort((a, b) => a.date.localeCompare(b.date)),
        },
      };
    }
    case 'nutrition': {
      const current: NutritionDay = state.nutrition[action.date] ?? {
        date: action.date,
        dayType: 'fuerza',
        mealsDone: [],
        water: 0,
        creatine: false,
      };
      return { ...state, nutrition: { ...state.nutrition, [action.date]: { ...current, ...action.payload } } };
    }
    case 'extra': {
      const list = state.extras[action.date] ?? [];
      const next = list.includes(action.exerciseId)
        ? list.filter((x) => x !== action.exerciseId)
        : [...list, action.exerciseId];
      return { ...state, extras: { ...state.extras, [action.date]: next } };
    }
    case 'screen':
      return { ...state, lastScreen: action.payload };
    case 'reset':
      return emptyState();
    default:
      return state;
  }
};

interface Ctx {
  state: AppState;
  program: Workout[];
  today: string;
  workoutFor: (date: string) => Workout | null;
  readinessFor: (date: string) => DailyReadiness;
  sessionFor: (workoutId: string) => WorkoutSession | undefined;
  summaryFor: (workoutId: string) => SessionSummary | undefined;
  nutritionFor: (date: string) => NutritionDay;
  setProfile: (p: Partial<UserProfile>) => void;
  setReadiness: (date: string, p: Partial<DailyReadiness>) => void;
  setAdjustments: (date: string, ids: string[]) => void;
  saveSession: (s: WorkoutSession) => void;
  saveSummary: (s: SessionSummary) => void;
  setOverride: (date: string, a: SportActivity | null) => void;
  setMetric: (metricId: string, entry: MetricEntry) => void;
  setNutrition: (date: string, p: Partial<NutritionDay>) => void;
  setDayType: (date: string, t: NutritionDayType) => void;
  toggleExtra: (date: string, exerciseId: string) => void;
  setScreen: (s: string) => void;
  resetDemo: () => void;
  emptySet: () => CompletedSet;
  workoutById: (id: string) => Workout | undefined;
  recordSet: (workoutId: string, key: string, index: number, entry: Partial<CompletedSet>) => void;
  setFinisherScore: (workoutId: string, score: FinisherScore) => void;
}

const AppCtx = createContext<Ctx | null>(null);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [state, dispatch] = useReducer(reducer, undefined, loadState);
  const program = useMemo(() => buildProgram(), []);
  const today = todayISO();

  useEffect(() => {
    saveState(state);
  }, [state]);

  const workoutById = useCallback(
    (id: string) => program.find((w) => w.id === id),
    [program],
  );

  /** Registra una serie creando la sesión si todavía no existe. */
  const recordSet = useCallback(
    (workoutId: string, key: string, index: number, entry: Partial<CompletedSet>) => {
      const workout = program.find((w) => w.id === workoutId);
      if (!workout) return;
      const existing = state.sessions[workoutId];
      const base: WorkoutSession = existing ?? {
        workoutId,
        date: workout.date,
        startedAt: Date.now(),
        elapsedMs: 0,
        blockIndex: 0,
        activeKey: key,
        sets: {},
        skipped: [],
        substitutions: {},
      };
      const rows = [...(base.sets[key] ?? [])];
      while (rows.length <= index) rows.push({ done: false, load: '', reps: '' });
      rows[index] = { ...rows[index], ...entry };
      dispatch({
        type: 'session',
        workoutId,
        payload: { ...base, activeKey: key, sets: { ...base.sets, [key]: rows } },
      });
    },
    [program, state.sessions],
  );

  const setFinisherScore = useCallback(
    (workoutId: string, score: FinisherScore) => {
      const existing = state.sessions[workoutId];
      if (!existing) return;
      dispatch({ type: 'session', workoutId, payload: { ...existing, finisherScore: score } });
    },
    [state.sessions],
  );

  const value: Ctx = {
    state,
    program,
    today,
    workoutFor: (date) => program.find((w) => w.date === date) ?? null,
    readinessFor: (date) => state.readiness[date] ?? defaultReadiness,
    sessionFor: (workoutId) => state.sessions[workoutId],
    summaryFor: (workoutId) => state.history.find((h) => h.workoutId === workoutId),
    nutritionFor: (date) =>
      state.nutrition[date] ?? { date, dayType: 'fuerza', mealsDone: [], water: 0, creatine: false },
    setProfile: (p) => dispatch({ type: 'profile', payload: p }),
    setReadiness: (date, p) => dispatch({ type: 'readiness', date, payload: p }),
    setAdjustments: (date, ids) => dispatch({ type: 'adjustments', date, payload: ids }),
    saveSession: (s) => dispatch({ type: 'session', workoutId: s.workoutId, payload: s }),
    saveSummary: (s) => dispatch({ type: 'summary', payload: s }),
    setOverride: (date, a) => dispatch({ type: 'override', date, activity: a }),
    setMetric: (metricId, entry) => dispatch({ type: 'metric', metricId, entry }),
    setNutrition: (date, p) => dispatch({ type: 'nutrition', date, payload: p }),
    setDayType: (date, t) => dispatch({ type: 'nutrition', date, payload: { dayType: t } }),
    toggleExtra: (date, exerciseId) => dispatch({ type: 'extra', date, exerciseId }),
    setScreen: (s) => dispatch({ type: 'screen', payload: s }),
    resetDemo: () => {
      clearState();
      dispatch({ type: 'reset' });
    },
    emptySet: () => ({ done: false }),
    workoutById,
    recordSet,
    setFinisherScore,
  };

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
};

export const useApp = (): Ctx => {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error('useApp debe usarse dentro de AppProvider');
  return ctx;
};
