import { useState } from 'react';
import { Check } from 'lucide-react';
import { useApp } from '../state/AppContext';
import type { SessionSummary } from '../types';
import { completedSets } from '../lib/prescription';
import { ScaleSelector, Stat } from './ui';

/** Resumen de cierre: duración, score, sensaciones y feedback automático. */
export const WorkoutSummaryModal = ({
  workoutId,
  onClose,
}: {
  workoutId: string;
  onClose: () => void;
}) => {
  const app = useApp();
  const workout = app.workoutById(workoutId);
  const session = app.sessionFor(workoutId);
  const [rpe, setRpe] = useState<number | null>(null);
  const [energy, setEnergy] = useState<number | null>(null);
  const [pain, setPain] = useState<number | null>(null);
  const [comment, setComment] = useState('');

  if (!workout) return null;

  const sets = completedSets(session);
  const durationMin = session ? Math.max(1, Math.round((Date.now() - session.startedAt) / 60000)) : workout.blocks.reduce((s, b) => s + b.minutes, 0);
  const score = session?.finisherScore;
  const finisher = workout.blocks.find((b) => b.kind === 'finisher');

  /** Feedback automático: se calcula del RPE declarado contra el planificado. */
  const coachFeedback = (): string => {
    if (rpe === null) return 'Cargá el RPE para recibir la lectura del día.';
    const planned = parseInt(workout.plannedRpe, 10) || 7;
    if (rpe >= planned + 2) return 'Te fuiste bastante por encima de lo planificado. Si se repite, revisá el descanso entre series antes de subir carga.';
    if (rpe <= planned - 2) return 'Quedó corto respecto de lo planificado: la próxima podés subir carga o sumar una vuelta al bloque Atleta.';
    if (pain !== null && pain >= 5) return 'El dolor está alto. Mañana priorizá movilidad y bajá el volumen de piernas.';
    return 'Sesión en el rango planificado. Repetí esta carga la semana que viene y sumá desde ahí.';
  };

  const save = () => {
    const summary: SessionSummary = {
      workoutId,
      workoutName: workout.name,
      date: workout.date,
      durationMin,
      blocksCompleted: workout.blocks.length,
      blocksTotal: workout.blocks.length,
      volumeKg: 0,
      setsCompleted: sets,
      finisherScore: score,
      rpe: rpe ?? 0,
      energy: energy ?? 0,
      pain: pain ?? 0,
      feeling: null,
      comment,
      highlight: null,
      personalRecord: null,
      coachNote: coachFeedback(),
    };
    app.saveSummary(summary);
    onClose();
  };

  return (
    <div className="min-h-screen bg-canvas pb-24">
      <div className="mx-auto max-w-2xl space-y-5 px-5 pb-8 pt-[calc(env(safe-area-inset-top)+1.5rem)]">
        <header>
          <p className="label text-brand">Sesión completa</p>
          <h1 className="mt-1 text-3xl">{workout.name}</h1>
        </header>

        <div className="grid grid-cols-3 gap-3">
          <Stat label="Duración" value={`${durationMin}′`} />
          <Stat label="Bloques" value={`${workout.blocks.length}`} />
          <Stat label="Series" value={`${sets}`} />
        </div>

        {finisher && score && (
          <section className="card p-4">
            <p className="label">Score del finisher</p>
            <p className="figure mt-1 text-3xl">
              {score.rounds ? `${score.rounds} + ${score.reps ?? 0}` : score.time ?? score.reps ?? score.distance ?? '—'}
            </p>
            <p className="meta mt-1">{finisher.formatLabel}</p>
          </section>
        )}

        <section className="card space-y-5 p-4">
          <ScaleSelector label="RPE final" value={rpe} onChange={setRpe} />
          <ScaleSelector label="Energía" value={energy} onChange={setEnergy} />
          <ScaleSelector label="Dolor" value={pain} onChange={setPain} min={0} hint="0 = sin molestias" />
          <label className="block">
            <span className="label">Comentario</span>
            <input
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Cómo se sintió la sesión"
              className="field mt-1"
            />
          </label>
        </section>

        <section className="rounded-2xl border-l-4 border-brand bg-lime-soft px-4 py-3">
          <p className="label text-brand-dark">Coach feedback</p>
          <p className="mt-1 text-sm leading-relaxed">{coachFeedback()}</p>
        </section>

        <button type="button" onClick={save} className="btn-primary w-full">
          <Check className="h-5 w-5" aria-hidden="true" /> Guardar y salir
        </button>
      </div>
    </div>
  );
};
