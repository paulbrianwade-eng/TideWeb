import type { ReactNode } from 'react';
import { CalendarDays, Home, Library, User, TrendingUp } from 'lucide-react';
import { Logo } from './ui';

export type Screen = 'today' | 'week' | 'progress' | 'library' | 'profile';

export const NAV_ITEMS: { id: Screen; label: string; icon: typeof Home }[] = [
  { id: 'today', label: 'Hoy', icon: Home },
  { id: 'week', label: 'Semana', icon: CalendarDays },
  { id: 'progress', label: 'Progreso', icon: TrendingUp },
  { id: 'library', label: 'Biblioteca', icon: Library },
  { id: 'profile', label: 'Perfil', icon: User },
];

export const AppShell = ({
  screen,
  onNavigate,
  children,
  /** Las pantallas con hero manejan su propio header y padding superior. */
  bleed = false,
}: {
  screen: Screen;
  onNavigate: (s: Screen) => void;
  children: ReactNode;
  bleed?: boolean;
}) => (
  <div className="min-h-screen bg-canvas lg:flex">
    {!bleed && (
      <header className="sticky top-0 z-30 border-b border-line bg-canvas/95 pt-[env(safe-area-inset-top)] backdrop-blur lg:hidden">
        <div className="flex items-center justify-between px-5 py-3">
          <Logo compact />
          <button
            type="button"
            onClick={() => onNavigate('profile')}
            aria-label="Abrir perfil"
            className="rounded-full border border-line bg-surface p-2 text-muted transition-colors duration-200 hover:text-ink"
          >
            <User className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </header>
    )}

    <nav
      aria-label="Navegación principal"
      className="hidden w-56 shrink-0 border-r border-line bg-surface p-5 lg:flex lg:flex-col lg:gap-1"
    >
      <div className="mb-8">
        <Logo compact />
        <p className="label mt-3 leading-relaxed">
          High Performance
          <br />
          Training System
        </p>
      </div>
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const active = screen === item.id;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onNavigate(item.id)}
            aria-current={active ? 'page' : undefined}
            className={`flex items-center gap-3 rounded-full px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.1em] transition-all duration-200 ${
              active ? 'bg-brand text-white' : 'text-muted hover:bg-canvas hover:text-brand'
            }`}
          >
            <Icon className="h-4 w-4" aria-hidden="true" />
            {item.label}
          </button>
        );
      })}
      <div className="mt-auto pt-4">
        <button
          type="button"
          onClick={() => onNavigate('profile')}
          className={`flex w-full items-center gap-3 rounded-full px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.1em] transition-all duration-200 ${
            screen === 'profile' ? 'bg-brand text-white' : 'text-muted hover:bg-canvas hover:text-brand'
          }`}
        >
          <User className="h-4 w-4" aria-hidden="true" />
          Perfil
        </button>
      </div>
    </nav>

    <main className={`mx-auto w-full flex-1 pb-28 lg:pb-12 ${bleed ? 'max-w-2xl' : 'max-w-2xl px-5 pt-5 lg:pt-10'}`}>
      {children}
    </main>

    <nav
      aria-label="Navegación principal"
      className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden"
    >
      <ul className="grid grid-cols-5">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = screen === item.id;
          return (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => onNavigate(item.id)}
                aria-current={active ? 'page' : undefined}
                className={`flex w-full flex-col items-center gap-1 px-1 py-2.5 text-[10px] font-semibold uppercase tracking-[0.08em] transition-colors duration-200 ${
                  active ? 'text-brand' : 'text-muted'
                }`}
              >
                <Icon className="h-5 w-5" aria-hidden="true" strokeWidth={active ? 2.4 : 1.7} />
                {item.label}
                <span
                  aria-hidden="true"
                  className={`h-1 w-1 rounded-full ${active ? 'bg-brand' : 'bg-transparent'}`}
                />
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  </div>
);
