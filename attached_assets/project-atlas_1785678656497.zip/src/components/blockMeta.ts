import { Dumbbell, Flame, Target, Waves, Moon, Mountain } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { BlockKind } from '../types';

export interface BlockMeta {
  label: string;
  icon: LucideIcon;
  /** Color del encabezado. El verde brillante es el de los bloques principales. */
  head: string;
  text: string;
}

export const BLOCK_META: Record<BlockKind, BlockMeta> = {
  'zona-media': { label: 'Zona media', icon: Target, head: 'bg-lime', text: 'text-ink' },
  fuerza: { label: 'Fuerza', icon: Dumbbell, head: 'bg-lime', text: 'text-ink' },
  atleta: { label: 'Atleta', icon: Waves, head: 'bg-lime', text: 'text-ink' },
  finisher: { label: 'Finisher', icon: Flame, head: 'bg-brand', text: 'text-white' },
  outdoor: { label: 'Outdoor', icon: Mountain, head: 'bg-lime', text: 'text-ink' },
  recovery: { label: 'Recuperación', icon: Moon, head: 'bg-lime-soft', text: 'text-brand-dark' },
};
