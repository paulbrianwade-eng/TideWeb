import { useState } from 'react';
import { useApp } from '../state/AppContext';
import { STATION_LABEL, TOTAL_WEEKS } from '../data/program';
import { shortDate, weekdayShort } from '../lib/date';
import { Placeholder } from '../components/media';
import { ModuleBadge } from '../components/ModuleBadge';

/** La semana como colección de entrenamientos, no como tabla. */
export const WeekScreen = ({ onOpen }: { onOpen: (workoutId: string) => void }) => {
  const app = useApp();
  const today = app.workoutFor(app.today);
  const [week, setWeek] = useState(today?.week ?? 1);
  const days = app.program.filter((w) => w.week === week);

  return (
    <div className="space-y-4 animate-fade-in">
      <header className="section-head">
        <div>
          <p className="label">Programa · fase 1</p>
          <h1 className="text-2xl">Semana {week}</h1>
        </div>
        <div className="flex gap-1">
          {Array.from({ length: TOTAL_WEEKS }, (_, i) => i + 1).map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setWeek(n)}
              aria-current={n === week ? 'true' : undefined}
              className={`h-8 w-8 rounded-full text-xs font-semibold transition-colors duration-200 ${
                n === week ? 'bg-brand text-white' : 'border border-line bg-surface text-muted'
              }`}
            >
              {n}
            </button>
          ))}
        </div>
      </header>

      <ul className="space-y-3">
        {days.map((w) => {
          const isToday = w.date === app.today;
          const summary = app.summaryFor(w.id);
          return (
            <li key={w.id}>
              <button
                type="button"
                onClick={() => onOpen(w.id)}
                className={`card flex w-full items-stretch gap-0 overflow-hidden text-left transition-colors duration-200 ${
                  isToday ? 'border-brand' : ''
                }`}
              >
                <Placeholder tone={w.blocks[0]?.kind ?? 'fuerza'} seed={w.week * 7 + w.day} className="w-24 shrink-0" />
                <span className="min-w-0 flex-1 p-4">
                  <span className="label flex items-center gap-2">
                    {weekdayShort(w.date)} {shortDate(w.date)}
                    {isToday && <span className="chip-brand">Hoy</span>}
                    {summary && <span className="chip-lime">Hecho</span>}
                  </span>
                  <span className="mt-1 block font-display text-xl uppercase leading-none">{w.name}</span>
                  <span className="mt-0.5 block text-xs text-muted">{w.subtitle}</span>
                  <span className="label mt-2 flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span>{w.duration}</span>
                    <span aria-hidden="true">·</span>
                    <span>{STATION_LABEL[w.station]}</span>
                    <span aria-hidden="true">·</span>
                    <span>{w.capability}</span>
                  </span>
                  <span className="mt-2 flex flex-wrap gap-1.5">
                    {w.transfersTo.map((m) => (
                      <ModuleBadge key={m} module={m} size="sm" />
                    ))}
                  </span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
};
