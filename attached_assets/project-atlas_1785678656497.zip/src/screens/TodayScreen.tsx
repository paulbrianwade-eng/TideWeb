import { Play, RotateCcw } from 'lucide-react';
import { useApp } from '../state/AppContext';
import { ACTIVITY_LABEL, BLOCK_LABEL, STATION_LABEL } from '../data/program';
import { longDate } from '../lib/date';
import { sessionProgress } from '../lib/prescription';
import { EmptyState } from '../components/ui';
import { Logo } from '../components/ui';
import { TodayHero } from '../components/media';
import { CollapsibleBlock } from '../components/workout-parts2';
import { EquipmentList } from '../components/EquipmentList';
import { ModuleBadge } from '../components/ModuleBadge';

export const TodayScreen = ({
  onStart,
  onProfile,
}: {
  onStart: (workoutId: string, blockIndex?: number) => void;
  onProfile: () => void;
}) => {
  const app = useApp();
  const { today } = app;
  const workout = app.workoutFor(today);
  const session = workout ? app.sessionFor(workout.id) : undefined;
  const summary = workout ? app.summaryFor(workout.id) : undefined;

  if (!workout) {
    return (
      <div className="px-5 pt-8">
        <EmptyState title="Sin sesión programada" hint="Abrí la semana para elegir una actividad." />
      </div>
    );
  }

  const progress = sessionProgress(workout, session);
  const started = !!session && !session.completedAt;

  return (
    <div className="animate-fade-in">
      {/* HERO — imagen, nombre, duración, botón. Nada más. */}
      <TodayHero workout={workout} className="min-h-[42vh]">
        <div className="flex min-h-[42vh] flex-col justify-between px-5 pb-6 pt-[calc(env(safe-area-inset-top)+1rem)]">
          <button type="button" onClick={onProfile} className="self-start text-left">
            <Logo compact light />
          </button>
          <div className="animate-rise-in">
            <p className="label text-white/70">
              Semana {workout.week} · {longDate(today)}
            </p>
            <h1 className="mt-2 text-[3rem] leading-[0.9] sm:text-6xl">{workout.name}</h1>
            <p className="mt-1 font-display text-xl uppercase text-lime">{workout.subtitle}</p>
            <p className="label mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-white">
              <span>{workout.duration}</span>
              <span aria-hidden="true" className="text-white/40">·</span>
              <span>RPE {workout.plannedRpe}</span>
              <span aria-hidden="true" className="text-white/40">·</span>
              <span>{STATION_LABEL[workout.station]}</span>
              <span aria-hidden="true" className="text-white/40">·</span>
              <span>{workout.capability}</span>
            </p>
          </div>
        </div>
      </TodayHero>

      <div className="space-y-5 px-5 pt-5">
        <button type="button" onClick={() => onStart(workout.id)} className="btn-primary w-full py-5 text-base">
          {summary ? (
            <>
              <RotateCcw className="h-5 w-5" aria-hidden="true" /> Repasar la sesión
            </>
          ) : started ? (
            <>
              <Play className="h-5 w-5" aria-hidden="true" /> Retomar · {Math.round(progress * 100)} %
            </>
          ) : (
            <>
              <Play className="h-5 w-5" aria-hidden="true" /> Comenzar
            </>
          )}
        </button>

        {started && !summary && (
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-line">
            <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${progress * 100}%` }} />
          </div>
        )}

        {summary && (
          <p className="flex items-center justify-between rounded-xl border border-brand/30 bg-lime-soft px-4 py-3 text-sm">
            <span className="label text-brand-dark">Completado</span>
            <span className="text-muted">
              {summary.durationMin} min · RPE {summary.rpe}
              {summary.finisherScore?.rounds ? ` · ${summary.finisherScore.rounds} rondas` : ''}
              {summary.finisherScore?.time ? ` · ${summary.finisherScore.time}` : ''}
            </span>
          </p>
        )}

        {/* Objetivo y coach note */}
        <section>
          <p className="label">Objetivo</p>
          <p className="mt-1.5 text-sm leading-relaxed text-ink">{workout.objective}</p>
        </section>

        <section className="rounded-2xl border-l-4 border-brand bg-lime-soft px-4 py-3">
          <p className="label text-brand-dark">Coach note</p>
          <p className="mt-1 text-sm leading-relaxed text-ink">{workout.coachNote}</p>
        </section>

        {/* Transferencia deportiva */}
        {workout.transfersTo.length > 0 && (
          <section>
            <p className="label">Transfiere a</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {workout.transfersTo.map((m) => (
                <ModuleBadge key={m} module={m} size="sm" />
              ))}
            </div>
          </section>
        )}

        {/* HOY NECESITÁS */}
        <EquipmentList workoutId={workout.id} items={workout.equipment} />

        {/* Vista previa de bloques */}
        <section className="space-y-3">
          <div className="section-head">
            <h2 className="text-lg">La sesión</h2>
            <span className="label">
              {workout.blocks.length} bloques · {workout.duration}
            </span>
          </div>
          {workout.blocks.map((b, i) => (
            <CollapsibleBlock key={b.id} block={b} onOpenExercise={() => onStart(workout.id, i)} />
          ))}
        </section>

        <section className="pb-4">
          <div className="section-head">
            <h2 className="text-lg">Mañana</h2>
          </div>
          <p className="figure text-3xl">
            {workout.nextDayActivity ? ACTIVITY_LABEL[workout.nextDayActivity] : '—'}
          </p>
        </section>
      </div>
    </div>
  );
};

export { BLOCK_LABEL };
