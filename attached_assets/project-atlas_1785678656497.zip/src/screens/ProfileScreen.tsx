import { useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { useApp } from '../state/AppContext';
import { EQUIPMENT_OPTIONS, PREFERENCES, SPORT_OPTIONS } from '../data/defaults';
import { Card, Field, SectionTitle, Toggle } from '../components/ui';

export const ProfileScreen = () => {
  const app = useApp();
  const p = app.state.profile;
  const [confirmReset, setConfirmReset] = useState(false);

  const toggleIn = (list: string[], value: string) =>
    list.includes(value) ? list.filter((x) => x !== value) : [...list, value];

  return (
    <div className="space-y-4">

      <header>
        <p className="eyebrow">Perfil</p>
        <h1 className="font-display text-3xl leading-none">Configuración</h1>
      </header>

      <Card className="space-y-3">
        <SectionTitle eyebrow="Datos" title="Perfil del atleta" />
        <Field label="Nombre" value={p.name} onChange={(v) => app.setProfile({ name: v })} />
        <div className="grid grid-cols-2 gap-3">
          <Field
            label="Edad"
            value={String(p.age)}
            inputMode="numeric"
            onChange={(v) => app.setProfile({ age: Number(v) || 0 })}
            suffix="años"
          />
          <Field
            label="Altura"
            value={String(p.height)}
            inputMode="numeric"
            onChange={(v) => app.setProfile({ height: Number(v) || 0 })}
            suffix="cm"
          />
          <Field
            label="Peso actual"
            value={String(p.weight)}
            inputMode="decimal"
            onChange={(v) => app.setProfile({ weight: Number(v.replace(',', '.')) || 0 })}
            suffix="kg"
          />
          <Field
            label="Peso objetivo"
            value={String(p.targetWeight)}
            inputMode="decimal"
            onChange={(v) => app.setProfile({ targetWeight: Number(v.replace(',', '.')) || 0 })}
            suffix="kg"
          />
          <Field
            label="Días disponibles"
            value={String(p.daysAvailable)}
            inputMode="numeric"
            onChange={(v) => app.setProfile({ daysAvailable: Number(v) || 0 })}
            suffix="por semana"
          />
          <Field
            label="Hora de entrenamiento"
            value={p.trainingTime}
            onChange={(v) => app.setProfile({ trainingTime: v })}
          />
        </div>
        <Field
          label="Duración preferida"
          value={p.preferredDuration}
          onChange={(v) => app.setProfile({ preferredDuration: v })}
        />
        <Field
          label="Molestias actuales"
          value={p.complaints.join(', ')}
          onChange={(v) => app.setProfile({ complaints: v.split(',').map((x) => x.trim()).filter(Boolean) })}
        />
      </Card>

      <Card className="space-y-3">
        <SectionTitle eyebrow="Disponible" title="Equipamiento" />
        <div className="grid gap-2 sm:grid-cols-2">
          {EQUIPMENT_OPTIONS.map((eq) => (
            <Toggle
              key={eq}
              active={p.equipment.includes(eq)}
              onClick={() => app.setProfile({ equipment: toggleIn(p.equipment, eq) })}
            >
              {eq}
            </Toggle>
          ))}
        </div>
      </Card>

      <Card className="space-y-3">
        <SectionTitle eyebrow="Práctica" title="Deportes" />
        <div className="grid gap-2 sm:grid-cols-2">
          {SPORT_OPTIONS.map((s) => (
            <Toggle
              key={s}
              active={p.sports.includes(s)}
              onClick={() => app.setProfile({ sports: toggleIn(p.sports, s) })}
            >
              {s}
            </Toggle>
          ))}
        </div>
      </Card>

      <Card>
        <SectionTitle eyebrow="Programación" title="Preferencias de entrenamiento" />
        <ul className="space-y-1 text-sm text-muted">
          {PREFERENCES.map((pref) => (
            <li key={pref} className="flex gap-2">
              <span aria-hidden="true" className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-accent" />
              {pref}
            </li>
          ))}
        </ul>
      </Card>

      <Card className="space-y-3">
        <SectionTitle eyebrow="Datos locales" title="Almacenamiento" />
        <p className="text-sm text-muted">
          Todo se guarda en este dispositivo (localStorage). Restablecer borra sesiones, métricas, nutrición y
          cambios de calendario.
        </p>
        {confirmReset ? (
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => {
                app.resetDemo();
                setConfirmReset(false);
              }}
              className="btn-ghost flex-1 border-danger/50 text-danger"
            >
              Confirmar restablecimiento
            </button>
            <button type="button" onClick={() => setConfirmReset(false)} className="btn-quiet">
              Cancelar
            </button>
          </div>
        ) : (
          <button type="button" onClick={() => setConfirmReset(true)} className="btn-ghost w-full">
            <RefreshCw className="h-4 w-4" aria-hidden="true" /> Restablecer datos de demostración
          </button>
        )}
      </Card>
    </div>
  );
};
