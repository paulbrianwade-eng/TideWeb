import type { PrimaryCapability, SportActivity, SportModule, Workout, WorkoutBlock } from '../types';
import { addDays, todayISO } from '../lib/date';
import type { Station } from './equipment';
import { STATION_LABEL } from './equipment';
import { getExercise } from './exercises';
import { ATLETA, FINISHERS, TABATA_FULL, ZONA_MEDIA, mk } from './session-blocks';
import type { BlockDraft } from './session-blocks';

/** Primera fase: cuatro semanas. */
export const TOTAL_WEEKS = 4;
export const PROGRAM_START = todayISO();

export const ACTIVITY_LABEL: Record<SportActivity, string> = {
  surf: 'Surf', golf: 'Golf', ski: 'Esquí', running: 'Running',
  rest: 'Descanso', gym: 'Gimnasio', home: 'Entrenamiento en casa',
};

export const BLOCK_LABEL: Record<WorkoutBlock['kind'], string> = {
  'zona-media': 'Zona media',
  fuerza: 'Fuerza',
  atleta: 'Atleta',
  finisher: 'Finisher',
  outdoor: 'Outdoor',
  recovery: 'Recuperación',
};

const pick = <T,>(pool: T[], week: number, offset = 0): T => pool[(week - 1 + offset) % pool.length];

/**
 * BLOQUE 2 · FUERZA — 15-18 min.
 * 1 principal + 2 accesorios. Una sola configuración de barra por sesión:
 * después del principal se pasa a TRX, bandas, kettlebells o peso corporal.
 */
interface StrengthDraft {
  main: { id: string; sets: number; reps: string; rpe?: string; rest: string; unilateral?: boolean; load?: string };
  accessories: { id: string; sets: number; reps?: string; duration?: string; unilateral?: boolean; instructions?: string; load?: string }[];
}

const fuerzaBlock = (id: string, d: StrengthDraft, minutes = 17): WorkoutBlock =>
  mk(id, {
    kind: 'fuerza', index: 2, title: 'Fuerza', minutes,
    format: 'sets', formatLabel: `${d.main.sets} × ${d.main.reps} + accesorios`,
    focus: 'Un principal, una sola carga de barra',
    rest: d.main.rest,
    items: [
      { exerciseId: d.main.id, order: 'A', sets: d.main.sets, reps: d.main.reps, rpe: d.main.rpe, rest: d.main.rest, unilateral: d.main.unilateral, load: d.main.load },
      ...d.accessories.map((a, i) => ({
        exerciseId: a.id, order: `B${i + 1}`, sets: a.sets, reps: a.reps, duration: a.duration,
        unilateral: a.unilateral, instructions: a.instructions, load: a.load,
      })),
    ],
  });

interface DayPlan {
  name: string;
  tagline: string;
  objective: string;
  rpe: string;
  station: Station;
  capability: PrimaryCapability;
  transfersTo: SportModule[];
  next: SportActivity | null;
  external?: SportActivity;
  build: (id: string, week: number) => WorkoutBlock[];
  note: (week: number) => string;
}

/** Progresión de carga a lo largo de las 4 semanas. La cuarta es de descarga. */
const wave = (week: number) => {
  const w = ((week - 1) % 4) + 1;
  if (w === 4) return { sets: 3, rpe: '6', deload: true };
  return { sets: 4 + (w > 1 ? 1 : 0), rpe: w === 1 ? '7' : w === 2 ? '7–8' : '8', deload: false };
};

const DAYS: DayPlan[] = [
  // ─────────── LUNES ───────────
  {
    name: 'Strong Legs',
    tagline: 'Ski Performance',
    objective:
      'Fuerza de piernas, resistencia excéntrica, estabilidad unilateral y capacidad para tolerar bajadas largas de esquí.',
    rpe: '8', station: 'barra', capability: 'Strength',
    transfersTo: ['ski', 'running'], next: 'gym',
    build: (id, week) => {
      const w = wave(week);
      return [
        mk(id, pick(ZONA_MEDIA, week, 0)),
        fuerzaBlock(id, {
          main: { id: 'box-squat', sets: w.sets, reps: w.deload ? '5' : '5', rpe: w.rpe, rest: '90 s' },
          accessories: [
            { id: 'split-squat-hold', sets: 3, duration: '30 s', unilateral: true },
            { id: 'step-down', sets: 3, reps: '6', unilateral: true, instructions: 'Descenso de 3 s desde el cajón.' },
          ],
        }),
        mk(id, pick(ATLETA, week, 0)),
        mk(id, pick(FINISHERS, week, 0)),
      ];
    },
    note: (week) =>
      wave(week).deload
        ? 'Semana de descarga: misma barra, una serie menos y RPE 6. El finisher se mantiene.'
        : 'La barra se monta una vez para el box squat y no se toca más. Los accesorios salen del cajón y del peso corporal.',
  },
  // ─────────── MARTES ───────────
  {
    name: 'Paddle Power',
    tagline: 'Upper Body + Surf',
    objective:
      'Fuerza de empuje, resistencia de tracción y estabilidad escapular para sostener horas de remada.',
    rpe: '7–8', station: 'barra', capability: 'Strength',
    transfersTo: ['surf'], next: 'gym',
    build: (id, week) => {
      const w = wave(week);
      return [
        mk(id, pick(ZONA_MEDIA, week, 1)),
        fuerzaBlock(id, {
          main: { id: 'bench-press', sets: w.sets, reps: '5', rpe: w.rpe, rest: '2 min' },
          accessories: [
            { id: 'trx-row', sets: 3, reps: '10–12' },
            { id: 'bottom-up-carry', sets: 3, duration: '20 s', unilateral: true, instructions: 'Sostenido, sin caminar.', load: 'KB 12 kg' },
          ],
        }),
        mk(id, pick(ATLETA, week, 1)),
        mk(id, pick(FINISHERS, week, 1)),
      ];
    },
    note: () =>
      'Banco y barra armados de principio a fin. Después del press no se toca un disco: TRX y kettlebell.',
  },
  // ─────────── MIÉRCOLES ───────────
  {
    name: 'Run Fast',
    tagline: 'Running Performance',
    objective:
      'Ordenar la mecánica de carrera, fortalecer pie y tobillo y sumar motor sin castigar las piernas.',
    rpe: '6–7', station: 'outdoor', capability: 'Engine',
    transfersTo: ['running'], next: 'gym',
    build: (id, week) => [
      mk(id, pick(ZONA_MEDIA, week, 2)),
      fuerzaBlock(
        id,
        {
          main: { id: 'single-leg-rdl', sets: 4, reps: '8', unilateral: true, rest: '60 s', load: 'KB 20 kg' },
          accessories: [
            { id: 'tibialis-raise', sets: 3, reps: '15' },
            { id: 'soleus-raise', sets: 3, reps: '15' },
          ],
        },
        15,
      ),
      mk(id, pick(ATLETA, week, 2)),
      mk(id, pick(FINISHERS, week, 2)),
    ],
    note: () =>
      'Sin barra hoy. Los drills van con las piernas frescas: skipping, pogo y aceleraciones ordenan la zancada antes del motor.',
  },
  // ─────────── JUEVES ───────────
  {
    name: 'Rotate',
    tagline: 'Golf Performance',
    objective:
      'Potencia rotacional, control de la desaceleración y transferencia directa a la velocidad de swing.',
    rpe: '7–8', station: 'barra', capability: 'Rotation',
    transfersTo: ['golf', 'surf'], next: 'gym',
    build: (id, week) => {
      const w = wave(week);
      return [
        mk(id, pick(ZONA_MEDIA, week, 3)),
        fuerzaBlock(id, {
          main: { id: 'push-press', sets: w.deload ? 4 : 5, reps: '4', rpe: w.deload ? '6' : '7', rest: '2 min' },
          accessories: [
            { id: 'single-leg-rdl', sets: 3, reps: '8', unilateral: true, load: 'KB 20 kg' },
            { id: 'trx-row', sets: 3, reps: '10' },
          ],
        }),
        mk(id, pick(ATLETA, week, 3)),
        mk(id, pick(FINISHERS, week, 3)),
      ];
    },
    note: () =>
      'La velocidad rotacional se entrena fresca. Si el lanzamiento pierde potencia, cortá la serie: no hay premio por completarla lenta.',
  },
  // ─────────── VIERNES ───────────
  {
    name: 'Full Send',
    tagline: 'Hybrid Athletic',
    objective:
      'Sesión híbrida: potencia con carga técnica, trabajo unilateral y un finisher que deja la semana cerrada.',
    rpe: '8', station: 'barra', capability: 'Athletic',
    transfersTo: ['ski', 'surf', 'running'], next: 'surf',
    build: (id, week) => {
      const w = wave(week);
      return [
        mk(id, pick(ZONA_MEDIA, week, 4)),
        fuerzaBlock(id, {
          main: { id: 'hang-power-clean', sets: 6, reps: '3', rpe: w.deload ? '6' : '6–7', rest: '90 s', load: 'Carga técnica' },
          accessories: [
            { id: 'bulgarian-split-squat', sets: 3, reps: '8', unilateral: true, load: 'KB 20 kg' },
            { id: 'trx-push-up', sets: 3, reps: '10' },
          ],
        }),
        mk(id, pick(ATLETA, week, 4)),
        mk(id, pick(FINISHERS, week, 4)),
      ];
    },
    note: () =>
      'El hang power clean es técnico: seis series de tres con carga que se mueve rápido. Nunca al fallo y nunca dentro del finisher.',
  },
  // ─────────── SÁBADO ───────────
  {
    name: 'Outdoor',
    tagline: 'Surf · Golf · Trail · Esquí',
    objective: 'El día en que el entrenamiento se transforma en deporte. Estructura libre según lo que haya.',
    rpe: '6–8', station: 'outdoor', capability: 'Power',
    transfersTo: ['surf', 'golf', 'ski', 'running'], next: 'rest', external: 'surf',
    build: (id, week) => [
      mk(id, {
        kind: 'outdoor', index: 1, title: 'Preparación', minutes: 10,
        format: 'rounds', formatLabel: '2 vueltas', rounds: 2,
        focus: 'Antes de salir',
        items: [
          { exerciseId: 'hip-9090', reps: '8 cambios' },
          { exerciseId: 'worlds-greatest-stretch', reps: '5', unilateral: true },
          { exerciseId: 'skipping', distance: '20 m' },
          { exerciseId: 'pogo-jump', reps: '15' },
        ],
      }),
      mk(id, {
        kind: 'outdoor', index: 2, title: 'Actividad', minutes: 60,
        format: 'sets', formatLabel: 'Libre',
        focus: 'Surf, golf, trail, esquí o cuestas',
        scoreType: 'time', scoreHint: 'Duración total',
        items: [
          { exerciseId: 'hill-sprint', sets: 8, duration: '12 s', rest: 'Vuelta caminando', instructions: 'Solo si no hay olas, cancha ni nieve.' },
        ],
      }),
      mk(id, pick(RECOVERY_POOL, week)),
    ],
    note: () =>
      'Si hay olas, nieve o cancha, ese es el entrenamiento. Si no, ocho cuestas de doce segundos rinden más que cuarenta minutos trotando.',
  },
  // ─────────── DOMINGO ───────────
  {
    name: 'Recovery',
    tagline: 'Movilidad y respiración',
    objective: 'Bajar el sistema nervioso, devolverle rango a la cadera y llegar entero al lunes.',
    rpe: '2–3', station: 'suelo', capability: 'Recovery',
    transfersTo: [], next: 'gym',
    build: (id, week) => [
      mk(id, {
        kind: 'recovery', index: 1, title: 'Movilidad', minutes: 15,
        format: 'rounds', formatLabel: '2 vueltas', rounds: 2,
        focus: 'Cadera y torácica',
        items: [
          { exerciseId: 'hip-flow', duration: '3 min' },
          { exerciseId: 'hip-9090', reps: '8 cambios' },
          { exerciseId: 'open-book', reps: '8', unilateral: true },
          { exerciseId: 'hip-flexor-stretch', duration: '40 s', unilateral: true, isometric: true },
        ],
      }),
      mk(id, pick(RECOVERY_POOL, week)),
    ],
    note: () =>
      'Día de recuperación real. Si te levantás cansado, quedate con la movilidad y la respiración: la caminata es opcional.',
  },
];

const RECOVERY_POOL: BlockDraft[] = [
  {
    kind: 'recovery', index: 2, title: 'Down regulation', minutes: 8,
    format: 'sets', formatLabel: 'Continuo', focus: 'Bajar pulsaciones',
    items: [
      { exerciseId: 'foam-roller', duration: '4 min', instructions: 'Cuádriceps, glúteo y dorsal.' },
      { exerciseId: 'down-regulation', duration: '4 min' },
    ],
  },
  {
    kind: 'recovery', index: 2, title: 'Respiración', minutes: 6,
    format: 'sets', formatLabel: 'Continuo', focus: 'Sistema nervioso',
    items: [
      { exerciseId: 'nasal-breathing', duration: '3 min', instructions: 'Inhalar 4 s · exhalar 8 s.' },
      { exerciseId: 'easy-walk', duration: '20 min', instructions: 'Opcional.' },
    ],
  },
];

/** Sesión especial: no forma parte de la semana, se abre a demanda. */
export const TABATA_SESSION = TABATA_FULL;

export const WEEK_STRUCTURE = DAYS.map((d) => ({
  name: d.name, tagline: d.tagline, station: STATION_LABEL[d.station],
}));

/** Equipamiento a preparar: derivado de los ejercicios reales de la sesión. */
export const equipmentFor = (blocks: WorkoutBlock[]): string[] => {
  const set = new Set<string>();
  blocks.forEach((b) => b.items.forEach((it) => getExercise(it.exerciseId).equipment.forEach((e) => set.add(e))));
  set.delete('Peso corporal');
  set.delete('Colchoneta');
  return [...set].sort();
};

/** Minutos totales. Criterio de aceptación: nunca más de 50. */
export const totalMinutes = (blocks: WorkoutBlock[]): number =>
  blocks.reduce((sum, b) => sum + b.minutes, 0);

const buildWorkout = (week: number, dayIndex: number, date: string): Workout => {
  const plan = DAYS[dayIndex];
  const id = `w${week}d${dayIndex + 1}`;
  const blocks = plan.build(id, week);
  const mins = totalMinutes(blocks);

  return {
    id, week, day: dayIndex + 1, date,
    name: plan.name,
    subtitle: plan.tagline,
    objective: plan.objective,
    duration: plan.external ? 'Jornada' : `${mins} min`,
    plannedRpe: wave(week).deload && !plan.external ? '6–7' : plan.rpe,
    coachNote: plan.note(week),
    nextDayActivity: plan.next,
    blocks,
    adaptations: [],
    status: plan.external ? 'external' : 'pending',
    externalActivity: plan.external,
    phase: 1,
    modules: plan.transfersTo,
    station: plan.station,
    capability: plan.capability,
    equipment: equipmentFor(blocks),
    transfersTo: plan.transfersTo,
  };
};

export const buildProgram = (start: string = PROGRAM_START): Workout[] => {
  const out: Workout[] = [];
  for (let w = 1; w <= TOTAL_WEEKS; w += 1) {
    for (let d = 0; d < DAYS.length; d += 1) {
      out.push(buildWorkout(w, d, addDays(start, (w - 1) * 7 + d)));
    }
  }
  return out;
};

export { STATION_LABEL } from './equipment';
