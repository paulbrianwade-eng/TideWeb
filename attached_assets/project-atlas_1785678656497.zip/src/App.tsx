import { useState } from 'react';
import { AppProvider, useApp } from './state/AppContext';
import { AppShell } from './components/AppShell';
import type { Screen } from './components/AppShell';
import { TodayScreen } from './screens/TodayScreen';
import { WeekScreen } from './screens/WeekScreen';
import { SessionScreen } from './screens/SessionScreen';
import { ProgressScreen } from './screens/ProgressScreen';
import { LibraryScreen } from './screens/LibraryScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { WorkoutSummaryModal } from './components/WorkoutSummaryModal';
import { ReadinessCheck } from './components/readiness';
import { applyAdaptations, emptyAnswers } from './lib/adaptations';
import type { AdaptationAnswers } from './lib/adaptations';

const Router = () => {
  const app = useApp();
  const [screen, setScreen] = useState<Screen>((app.state.lastScreen as Screen) ?? 'today');
  const [session, setSession] = useState<{ id: string; block: number } | null>(null);
  const [checking, setChecking] = useState<{ id: string; block: number } | null>(null);
  const [answers, setAnswers] = useState<AdaptationAnswers>(emptyAnswers);
  const [finishing, setFinishing] = useState<string | null>(null);

  const navigate = (s: Screen) => {
    setScreen(s);
    app.setScreen(s);
  };

  /** Toda entrada al modo sesión pasa primero por las preguntas previas. */
  const openSession = (id: string, block = 0) => setChecking({ id, block });

  const adaptedWorkout = (id: string) => {
    const base = app.workoutById(id);
    if (!base) return undefined;
    const { blocks, rules } = applyAdaptations(base, answers);
    return { ...base, blocks, adaptations: rules.map((r) => r.label) };
  };

  if (checking) {
    const workout = app.workoutById(checking.id);
    if (workout) {
      return (
        <ReadinessCheck
          workout={workout}
          onBack={() => setChecking(null)}
          onStart={(a) => {
            setAnswers(a);
            setSession(checking);
            setChecking(null);
          }}
        />
      );
    }
  }

  if (session) {
    return (
      <SessionScreen
        workoutId={session.id}
        workout={adaptedWorkout(session.id)}
        initialBlockIndex={session.block}
        onExit={() => setSession(null)}
        onFinish={() => {
          setFinishing(session.id);
          setSession(null);
        }}
      />
    );
  }

  if (finishing) {
    return <WorkoutSummaryModal workoutId={finishing} onClose={() => setFinishing(null)} />;
  }

  return (
    <AppShell screen={screen} onNavigate={navigate} bleed={screen === 'today'}>
      {screen === 'today' && (
        <TodayScreen onStart={openSession} onProfile={() => navigate('profile')} />
      )}
      {screen === 'week' && <WeekScreen onOpen={(id) => openSession(id)} />}
      {screen === 'progress' && <ProgressScreen />}
      {screen === 'library' && <LibraryScreen />}
      {screen === 'profile' && <ProfileScreen />}
    </AppShell>
  );
};

export default function App() {
  return (
    <AppProvider>
      <Router />
    </AppProvider>
  );
}
