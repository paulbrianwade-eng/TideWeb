/** Audita las reglas duras del programa. Falla el build si algo se rompe. */
import { buildProgram, totalMinutes, TOTAL_WEEKS } from '../src/data/program';
import { EXERCISES, getExercise } from '../src/data/exercises';
import { INVENTORY, UNAVAILABLE } from '../src/data/equipment';

let failed = 0;
const check = (name: string, ok: boolean, detail = '') => {
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failed += 1;
};

const prog = buildProgram('2026-01-05');
const main = prog.filter((w) => !w.externalActivity && w.name !== 'Recovery');

check('4 semanas × 7 días = 28 sesiones', prog.length === TOTAL_WEEKS * 7, `${prog.length}`);

// 1. Cuatro bloques exactos en toda sesión principal
const wrongBlocks = main.filter(
  (w) => w.blocks.length !== 4 || !['zona-media', 'fuerza', 'atleta', 'finisher'].every((k, i) => w.blocks[i].kind === k),
);
check('Toda sesión principal tiene los 4 bloques en orden', wrongBlocks.length === 0, `${wrongBlocks.length} fallan`);

// 2. Duración máxima 50 min
const tooLong = main.filter((w) => totalMinutes(w.blocks) > 50);
const durations = main.map((w) => totalMinutes(w.blocks));
check('Ninguna sesión supera los 50 min', tooLong.length === 0,
  `rango ${Math.min(...durations)}–${Math.max(...durations)} min`);

// 3. Finisher obligatorio y medible
const noFinisher = main.filter((w) => !w.blocks.some((b) => b.kind === 'finisher' && b.scoreType));
check('Todas tienen finisher con score', noFinisher.length === 0, `${noFinisher.length} sin score`);

// 4. Equipamiento real
const bad: string[] = [];
EXERCISES.forEach((e) =>
  e.equipment.forEach((q) => {
    if (UNAVAILABLE.includes(q)) bad.push(`${e.name}: ${q}`);
    else if (!INVENTORY.includes(q as never)) bad.push(`${e.name}: ${q} (fuera del inventario)`);
  }),
);
check('Ningún ejercicio pide material inexistente', bad.length === 0, bad.slice(0, 3).join(' · '));

// 5. Una sola configuración de barra por sesión
const BARBELL_LIFTS = new Set(
  EXERCISES.filter((e) => e.equipment.includes('Barra') && e.equipment.includes('Discos')).map((e) => e.id),
);
const multiBar = main.filter((w) => {
  const used = new Set<string>();
  w.blocks.forEach((b) => b.items.forEach((it) => BARBELL_LIFTS.has(it.exerciseId) && used.add(it.exerciseId)));
  return used.size > 1;
});
check('Máximo un ejercicio de barra cargada por sesión', multiBar.length === 0,
  multiBar.map((w) => w.name).join(', '));

// 6. Bloque fuerza: 1 principal + máximo 2 accesorios
const fatStrength = main.filter((w) => {
  const f = w.blocks.find((b) => b.kind === 'fuerza');
  return !f || f.items.length > 3;
});
check('Fuerza = 1 principal + 2 accesorios', fatStrength.length === 0, `${fatStrength.length} exceden`);

// 7. Zona media: 3-4 ejercicios, 7-9 min
const badCore = main.filter((w) => {
  const z = w.blocks[0];
  return z.items.length < 3 || z.items.length > 4 || z.minutes < 7 || z.minutes > 9;
});
check('Zona media: 3-4 ejercicios y 7-9 min', badCore.length === 0, `${badCore.length} fallan`);

// 8. Atleta: 3-4 ejercicios, 10-12 min
const badAthlete = main.filter((w) => {
  const a = w.blocks[2];
  return a.items.length < 3 || a.items.length > 4 || a.minutes < 10 || a.minutes > 12;
});
check('Atleta: 3-4 ejercicios y 10-12 min', badAthlete.length === 0, `${badAthlete.length} fallan`);

// 9. Nada técnico y pesado dentro del finisher
const TECHNICAL = ['hang-power-clean', 'back-squat', 'front-squat', 'box-squat', 'bench-press', 'push-press', 'deadlift', 'drop-jump'];
const riskyFinisher = main.filter((w) =>
  w.blocks.find((b) => b.kind === 'finisher')!.items.some((it) => TECHNICAL.includes(it.exerciseId)),
);
check('Sin levantamientos técnicos dentro del finisher', riskyFinisher.length === 0, `${riskyFinisher.length}`);

// 10. Tabata Extendido completo nunca dentro de una sesión normal
const tabataInside = main.filter((w) => w.blocks.some((b) => b.format === 'tabata-full'));
check('Tabata Extendido completo queda fuera de la semana', tabataInside.length === 0);

// 11. Variedad de finishers
const finisherFormats = new Set(main.map((w) => w.blocks[3].formatLabel));
check('Los finishers varían durante la semana', finisherFormats.size >= 5, `${finisherFormats.size} formatos distintos`);

// 12. Biblioteca completa
const incomplete = EXERCISES.filter((e) => !e.objective || !e.cues.length || !e.mistakes.length || !e.regression || !e.progression || !e.video);
check('Biblioteca sin fichas incompletas', incomplete.length === 0, `${incomplete.length}`);
console.log(`\nEjercicios: ${EXERCISES.length} · sesiones: ${prog.length}`);
console.log(`Equipamiento de la sesión 1: ${prog[0].equipment.join(', ')}`);
console.log(`Bloques del lunes: ${prog[0].blocks.map((b) => `${b.index}.${b.title} (${b.minutes}′ ${b.formatLabel})`).join(' | ')}`);

if (failed) {
  console.error(`\n${failed} verificaciones fallaron`);
  process.exit(1);
}
