# PROJECT ATLAS · Athletic Performance

Aplicación web responsive (React + TypeScript + Tailwind + Vite) que responde una sola pregunta al abrirse:
**¿qué entrenamiento me toca hoy?**

Todo funciona sin backend: los datos iniciales viven en archivos TypeScript y el progreso se guarda en
`localStorage`.

---

## Replit

El repo ya viene configurado: incluye `.replit` (Node 20, puerto 5173 → 80, deploy estático desde `dist/`) y
un `vite.config.ts` que detecta Replit para escuchar en `0.0.0.0`, aceptar el dominio del proxy y apuntar el
HMR al 443.

1. En Replit: **Create Repl → Import → Upload zip** (o *Import from ZIP*) y subí este archivo.
2. Esperá a que instale las dependencias, o corré `npm install` en la Shell.
3. Botón **Run** (equivale a `npm run dev`) y abrí la ventana de preview.
4. Para publicarla: **Deploy → Static**, ya queda tomado `npm run build` con salida en `dist/`.

Si la instalación no arranca sola: `npm install && npm run dev`.

## Instalación local

```bash
npm install
npm run dev
```

Abrí `http://localhost:5173`.

Otros comandos:

```bash
npm run build         # typecheck + build de producción en /dist
npm run preview       # sirve el build
npm run typecheck     # solo TypeScript
npm run preview:file  # genera dist-preview/index.html: la app entera en un solo archivo
npm run qa            # suite de QA automatizada (ver abajo)
```

## QA automatizada

`npm run qa` levanta la app en un DOM simulado y la maneja como un usuario:

- **`qa/flow.mjs`** — 43 chequeos del flujo completo: Hoy → readiness → panel adaptativo → Comenzar →
  registrar carga y repeticiones → temporizador → completar / saltar / sustituir / ver técnica → Finalizar →
  resumen con RPE y comentario → historial → calendario, progreso, nutrición, biblioteca, One Pager,
  configuración y reset.
- **`qa/buttons.mjs`** — recorre las cinco pantallas y hace clic en cada botón (295 en total) buscando
  controles decorativos, sin nombre accesible o que tiren error.
- **`qa/persist.mjs`** — inyecta un estado guardado antes de arrancar y verifica que al recargar se restaure
  la pantalla, las métricas, la readiness y la sesión a medio hacer.
- **`qa/program.ts`** — audita el macrociclo: que las 112 sesiones existan, que ninguna sesión de entrenamiento
  se quede sin los siete bloques, que Power nunca falte, que haya 16 circuitos Athletic distintos y que la
  progresión de fuerza y la descarga sean las esperadas.

Requisitos: Node 18 o superior.

---


## El sistema de entrenamiento

No es una rutina: es un macrociclo de **16 semanas** (112 sesiones) para un atleta híbrido.

### Los siete bloques

Toda sesión de entrenamiento contiene los siete, en este orden:

| Bloque | Para qué está |
|---|---|
| **Reset** | Respiración, tejido y activación del pie |
| **Movement** | Calidad de movimiento: CARs, 90/90, shin box, Jefferson curl, bear crawl |
| **Power** | Nunca se saca. Rota entre salto vertical, horizontal, lateral, balístico y triple extensión |
| **Strength** | Fuerza principal con el esquema de la fase |
| **Athletic Block** | El corazón del programa. Cambia las 16 semanas |
| **Engine** | Zona 2, umbral, tempo, HYROX, intervalos, SkiErg, remo |
| **Recovery** | Down regulation, foam roller, movilidad |

El **Athletic Block** siempre combina core, antirrotación, carry, plano frontal, unilateral y tendón. Hay 16
circuitos distintos, uno por semana, incluidas cuatro variantes de descarga.

### Periodización

| Fase | Semanas | Fuerza principal | Foco |
|---|---|---|---|
| 1 · Movement + Base | 1–4 | 4 × 8–10 · RPE 7 | Calidad de movimiento y tejido |
| 2 · Strength | 5–8 | 5 × 5 · RPE 7–8 | Fuerza máxima |
| 3 · Power | 9–12 | 5 × 3 · RPE 8 | Velocidad y expresión de fuerza |
| 4 · Athletic Performance | 13–16 | 4 × 5 · RPE 7 | Transferencia deportiva |

La cuarta semana de cada fase es de **descarga**: dos series menos y RPE 6.

### Módulos deportivos

Reemplazan el trabajo accesorio del día. No agregan un día extra ni se suman encima.

- **Ski Performance** (lunes) — wall sit, spanish squat, split squat hold, step-down lento, reverse nordic,
  copenhagen, lateral lunge, cossack, skater jump, soleus y tibialis. Isometría, excéntrico, unilateral, plano
  frontal y resistencia local: exactamente lo que faltó en la nieve.
- **Surf Performance** (martes) — TRX row, YTWL, bottom-up carry, face pull, bear crawl, landmine rotation,
  single arm farmer. Hombro resistente, escápula estable y rotación torácica.
- **Golf Performance** (jueves) — med ball rotacional, landmine rotation, cable chop y lift, pallof, hip
  airplane, single-leg RDL. Velocidad, rotación y desaceleración.
- **Running Mechanics** (miércoles) — A-skip, pogo, bounding, strides, fuerza de pie, tibial, sóleo, rigidez de
  tobillo. No solo correr.

### La semana

Lunes Lower Strength + Ski · Martes Upper Strength + Surf · Miércoles Zone 2 + Running Mechanics ·
Jueves Athletic Performance + Golf · Viernes Hybrid Performance · Sábado Outdoor · Domingo Recovery.

### La biblioteca

Cada uno de los ejercicios trae **objetivo** (por qué está en el programa), **capacidades que desarrolla**
(antirrotación, tendón, desaceleración, plano frontal…), músculos, indicaciones, errores frecuentes,
regresión, progresión, equipamiento y **link al video de técnica**.

> Los videos son links de búsqueda, no archivos alojados: esta versión no incluye contenido audiovisual propio.
> Si más adelante grabás tu propia biblioteca, se reemplaza el campo `video` de cada ejercicio por una URL.

## Cómo está armado

```
src/
  types/index.ts              Modelo de datos (Workout, Exercise, Session, Metric…)
  data/
    ex-helpers.ts             Constructor compacto de ejercicios
    ex-movement.ts            Movement quality y activación
    ex-strength.ts            Fuerza y potencia
    ex-modules.ts             Ski, surf, golf, running, engine y recovery
    exercises.ts              Índice unificado de la biblioteca + link de video
    phases.ts                 Las 4 fases del macrociclo y las semanas de descarga
    blocks.ts                 Pools de bloques: movement, power, 16 circuitos athletic, engine, módulos
    program.ts                Generador de las 112 sesiones
    defaults.ts               Perfil inicial, métricas, tipos de día y plan de comidas
  lib/
    date.ts                   Fechas en español, semana y matriz mensual
    adaptations.ts            Reglas de ajuste de sesión y estado de recuperación
    prescription.ts           Formato de prescripciones, progreso y volumen
    records.ts                Detección de récords personales
    storage.ts                Persistencia en localStorage
  state/AppContext.tsx        Estado global (useReducer) + guardado automático
  components/                 AppShell, navegación, tarjetas de bloque, tracker de series,
                              temporizador, resumen, One Pager, UI base
  screens/                    Hoy · Calendario · Progreso · Nutrición · Biblioteca · Sesión · Configuración
```

### Anclaje del programa

`PROGRAM_START` en `src/data/program.ts` está fijado en **hoy**: el Day 1 (Athletic Upper Performance) siempre
aparece al abrir la app, y la secuencia sigue con esquí, recuperación activa, movilidad, lower, upper y zona 2.
Si preferís anclar la semana a un lunes fijo, cambiá `PROGRAM_START` por una fecha `'YYYY-MM-DD'` y reordená
`TEMPLATES`.

---

## Qué hace cada pantalla

**Hoy** — fecha, semana y día, estado de recuperación calculado, tarjeta de la sesión (objetivo, duración, RPE,
coach note, actividad de mañana), los seis bloques como tarjetas con ícono y acento propio, indicadores de
energía / sueño / dolor / motivación de 1 a 10, y el panel **Ajustar sesión** con las once condiciones
(dormí poco, dolor lumbar, mañana esquío, solo 30 minutos, sin Assault Bike…). Las reglas devuelven un ajuste
concreto de volumen y RPE.

**Modo sesión** — un bloque por vez, series marcables, carga y repeticiones reales por serie, temporizador de
descanso con pausa y +30 s, botones Completado / Saltar / Sustituir / Ver técnica, barra de progreso, próximo
ejercicio y guardado automático. Se puede salir y retomar donde quedó.

**Resumen** — duración, bloques completados, volumen, series, ejercicio destacado, récord personal si lo hay, y
registro de RPE, energía, dolor, sensación final y comentario. Genera una coach note automática y guarda todo en
el historial.

**Calendario** — vista semanal y mensual, estado por día (pendiente, completado, modificado, actividad externa,
descanso), RPE planificado vs real, Daily Card de cada día y cambio de actividad con la advertencia de impacto
en la carga.

**Progreso** — peso y objetivo con barra de avance, adherencia semanal, y métricas editables agrupadas en
composición, fuerza, atlético, engine y recuperación. Cada métrica muestra su estado (sin datos, mejorando,
estable, requiere atención) y una miniserie histórica. No se inventa ningún valor: hasta que cargues datos,
la métrica queda en "sin datos".

**Nutrición** — objetivo diario, siete tipos de día que cambian la recomendación de carbohidratos, plan de un día
con entrenamiento temprano con casillas por comida, tracker de agua y creatina, y la nota sobre el mate.

**Biblioteca** — 43 ejercicios filtrables por categoría y búsqueda, con músculos, indicaciones, errores
frecuentes, regresión, progresión y equipamiento. "Agregar a sesión" suma el ejercicio como bloque **Extra** al
final de la sesión de hoy.

**Configuración** — perfil editable (edad, peso, altura, objetivo, días, duración, equipamiento, deportes,
molestias, horario) y "Restablecer datos de demostración".

---

## Persistencia

Clave única `tide.state.v1`. Se guarda: perfil, readiness diaria, ajustes seleccionados, sesiones en curso con
sus series y cargas, historial de resúmenes, cambios de calendario, métricas, nutrición, agua, extras y última
pantalla abierta. Si `localStorage` no está disponible, la app sigue funcionando en memoria.

---

## Diseño

Identidad propia, sin relación con ninguna referencia externa.

- **Marca**: wordmark `TIDE` en Space Grotesk con tracking amplio + marca de dos líneas de marea (lima sobre
  agua). Sin ilustraciones ni mascota.
- **Elemento distintivo**: el indicador de **marea**, tres barras que traducen el RPE planificado en carga del
  día (marea alta / media / baja). Es información, no adorno: aparece en Hoy, en la Daily Card y en el One Pager.
- **Jerarquía de rutina**: bandas de sección (`RESET · POWER · STRENGTH…`) con hairline, y filas tabulares
  `tag · ejercicio · volumen · RPE` alineadas a la derecha, para leer la sesión de un vistazo sin abrir nada.
- **Color**: fondo carbón `#0B0D0F`, superficies `#15191D` / `#20252A`, acento lima `#C7F000`, agua `#58E0C8`,
  alerta `#FFB547`, dolor `#FF6464`, éxito `#56D68A`.
- **Tipografía**: Space Grotesk (títulos, en caja mixta y tracking negativo), Inter (texto), IBM Plex Mono
  (datos, etiquetas y volúmenes). Si no hay conexión caen a las fuentes del sistema y el layout no cambia.

Mobile-first desde 320 px, navegación inferior en teléfono y lateral en escritorio, botones grandes, foco
visible, `aria-label` en controles de ícono, estados que no dependen solo del color y `prefers-reduced-motion`
respetado.

---

## Detalles de experiencia móvil

- Inputs a 16 px en pantallas chicas: iOS no hace zoom al enfocarlos.
- Escalas de 1 a 10 y vasos de agua en dos filas de cinco en teléfono: cada objetivo táctil pasa de ~25 px a
  ~53 px de ancho y 44 px de alto.
- Tocar un bloque en Hoy abre la sesión directamente en ese bloque.
- Al completar un ejercicio la sesión avanza sola al siguiente y arranca el descanso.
- El resumen bloquea el scroll del fondo; el temporizador queda fijo sin tapar los controles.
- Encabezado de sesión compacto, chips de bloque desplazables y respeto por el área segura del iPhone.
- `manifest.webmanifest` + metas de iOS: se puede agregar a la pantalla de inicio y abre a pantalla completa.

## Alcance de esta versión

- Sin backend ni base de datos: todo local.
- Las fotos de progreso son marcadores visuales, no hay carga de imágenes todavía.
- Las reglas de adaptación son determinísticas, no hay modelo de IA.
- La nutrición es una guía de entrenamiento, no una indicación médica.

## Archivo único para ver la app sin instalar

```bash
npm run build:preview
```

Genera `dist-preview/app.js` y `app.css`; el archivo `tide-preview.html` de esta entrega es exactamente eso
inlineado en un solo HTML (script clásico, sin módulos) para abrirlo desde el teléfono sin servidor.

## PROJECT ATLAS — personalización incluida

Esta versión incorpora el programa del usuario con estas reglas:

- Sesiones principales de 45–50 minutos como máximo.
- Una sola barra olímpica: cada sesión usa una única configuración de barra.
- Equipamiento real: rack, barra y discos, banco, TRX, kettlebells 8/12/20 kg, mancuernas 3/5 kg, medicine balls 5/10 kg, bandas, ab wheel, soga, cajón y espacio exterior.
- Sin Assault Bike, SkiErg, remo, trineo, poleas ni máquinas.
- Semana: BUILD (piernas/esquí), CONTROL (upper/surf), FLOW (running), ROTATE (golf), PERFORM (híbrido), PLAY (outdoor), RESTORE.
- Bloques de esquí con isometría, excéntricos, trabajo unilateral y plano frontal.
- Interfaz editorial clara inspirada en apps premium de training, sin copiar identidades de marca.
