# ACTUALIZAR SIN PERDER LO QUE YA ENTRENASTE

Este ZIP **no es el proyecto completo**. Son solo los archivos de rutina y lógica que cambiaron.

Todo lo demás de tu Repl queda intacto: `main.tsx`, `vite.config.ts`, `tsconfig.json`,
`postcss.config.js`, `package-lock.json`, `public/`, `src/lib/date.ts`, `src/lib/records.ts`
y `src/data/defaults.ts` **no se tocan**.

---

## Cómo aplicarlo

1. Abrí tu Repl.
2. Arrastrá el contenido de este ZIP sobre la raíz del proyecto, respetando las carpetas.
   Replit va a pedir confirmación para sobrescribir: aceptá.
3. `npm install` (solo si Replit avisa que faltan dependencias).
4. **Run**.

No borres `localStorage`. No uses "Restablecer datos" en Perfil.

---

## Por qué no se pierde nada

Tu entrenamiento del lunes vive en `localStorage`, no en los archivos. Reemplazar código
no lo borra. Pero había **dos bugs reales** que sí te lo hubieran arruinado, y están corregidos:

### 1. El programa se re-anclaba a "hoy" en cada carga

Antes, `PROGRAM_START` se calculaba con la fecha del momento en que abrías la app. Si hacías
Strong Legs el lunes y abrías el miércoles, el miércoles pasaba a ser el Día 1 y te mostraba
Strong Legs otra vez.

Ahora la fecha de arranque se guarda la primera vez y **no se recalcula nunca más**. Si arrancaste
un lunes, el lunes sigue siendo el Día 1.

### 2. Cambiar de versión borraba el estado entero

Antes, si la versión guardada no coincidía con la del código, se devolvía un estado vacío.
Cualquier actualización de lógica te borraba el historial.

Ahora hay una **migración** que conserva historial, sesiones, series registradas, métricas,
readiness y la fecha de arranque. Solo se descarta lo que dejó de existir en el modelo nuevo.

### 3. La app avanza con vos, no con el reloj

La pantalla Hoy detecta que Strong Legs ya está registrado y muestra la **siguiente sesión
pendiente** con un aviso: *"Ya registraste Strong Legs. Seguimos con la próxima sesión del plan."*

Los ids de sesión (`w1d1`, `w1d2`, `w2d1`…) dependen de la posición en el programa, no del
contenido. Por eso podés cambiar los ejercicios del lunes y tu registro del lunes sigue
apuntando al lunes.

---

## Qué cambió en la rutina

Estás en la **semana 1, con el lunes hecho**. Lo próximo que te toca es el martes.

El motor nuevo detectó y corrigió tres errores de programación que tenía la versión anterior:

| Problema | Corrección |
|---|---|
| Lunes: box squat → split squat → step down = tres sentadillas seguidas | El tercero pasó a soleus raise |
| Miércoles: skipping → sprint → lateral shuffle = tres locomociones | El último pasó a single-leg RDL |
| Viernes: empuje sin nada de tracción | TRX push-up pasó a TRX row |
| Circuito Atleta sin ningún salto ni sprint | Push-up explosivo pasó a lateral bound |

> **El lunes que ya hiciste cambió levemente**: donde hacías step-down, ahora va soleus raise.
> Tu registro queda igual — no se toca lo que guardaste. El cambio aplica de la semana que viene
> en adelante, cuando el lunes vuelva a aparecer.

Además, ahora **ningún ejercicio principal se repite dos semanas seguidas**:

| Día | S1 | S2 | S3 | S4 |
|---|---|---|---|---|
| Lunes | Box Squat | Front Squat | Back Squat | Box Squat |
| Martes (empuje) | Bench Press | Incline Bench | Bench Press | TRX Push-Up |
| Martes (tracción) | TRX Row | Inverted Row | Pull-Up | Power Pull |
| Jueves | Push Press | Overhead Press | Push Press | KB Press |
| Viernes | Hang Power Clean | KB Clean | Hang Power Clean | KB Swing |

---

## Verificar que quedó bien

```bash
npm run qa
```

Debería dar: **41/41** en el flujo, y todas las auditorías en verde, incluida
`qa/continuity.ts`, que comprueba exactamente esto:

- Con la misma fecha de inicio el calendario es idéntico
- El Día 1 sigue siendo el día de arranque, no hoy
- La migración conserva historial, series y métricas
- Cambiar los ejercicios no cambia el id de la sesión
- Con el lunes hecho, la próxima pendiente es el martes

Si algo salió mal, en Perfil está "Restablecer datos" — pero eso **sí** borra tu historial,
así que usalo solo como último recurso.

---

## Actualización de diversidad (segunda tanda)

Se detectó que dentro de una misma semana se repetían demasiados ejercicios.

**Antes**: 44 ejercicios distintos sobre 73 slots. La soga y los KB swings aparecían
4 veces por semana, y en la semana 3 el sprint aparecía **5 veces**.

**Ahora**: 51 distintos sobre 65 slots (75-78 % de variedad), con un máximo de 3 apariciones
por ejercicio y nunca más de 2 para los de alto costo neuromuscular.

### Qué cambió

1. **Pools más amplios**: 12 finishers (antes 8) y 9 circuitos Atleta (antes 8).
   Seis finishers no usan ni soga ni KB swing, seis circuitos no usan sprint.
2. **Selector consciente de la semana**: antes cada circuito se elegía de forma
   independiente, así que caiga el que caiga se repetían los mismos ejercicios.
   Ahora la semana se arma en orden llevando la cuenta de lo ya usado, y de cada pool
   se elige la variante que menos repite. El costo de repetir se pondera: repetir un
   sprint pesa 6, repetir saltos de soga pesa 1.
3. **Lastre entre semanas**: la semana arranca con un peso liviano de lo usado la anterior,
   así la siguiente se siente distinta sin expulsar lo que tiene que estar.
4. **Autocorrección**: si el validador encuentra un hueco (sin unilateral, sin rotación,
   sin componente atlético), la sustitución se aplica antes de que la sesión exista.
   Esto apareció en el lunes de la semana 3, que quedaba sin nada unilateral.

### Sobre la repetición entre semanas

Cambié el criterio del test. Dentro de un bloque de 4 semanas **querés** que los ejercicios
se repitan de una semana a la otra: sin eso no hay progresión de carga. La banda sana es
70-95 % de solapamiento, y el programa queda en 82-88 %.

Lo que sí cambia todas las semanas son los principales: los cinco rotan, cero repeticiones
consecutivas.

---

## Actualización de método (tercera tanda)

Paul pasó cuatro días de su plan de febrero 2024 con otro coach. Lo que se incorporó:

### El trío de contraste

Su bloque de fuerza no era "un principal + dos accesorios". Era **el mismo patrón en tres
cualidades**:

```
Press plano       4×8,8,6,6    pesado      → producir fuerza
Press plano ISO   4×5"         isométrico  → sostenerla
Lanzamiento       4×6          balístico   → expresarla rápido
```

Ese patrón se repetía en todos los días: peso muerto 1P → puente ISO → marcha triple cambio ·
sentadilla → split ISO → pogos · estocada lateral → split ISO catch → caída 1P.

El bloque 2 de ATLAS ahora se construye así. Se agregaron 22 ejercicios para completar los
tríos: ISO PUSH de press plano y militar, ISO HOLD de remo y dominada, lanzamientos acostado y
de rodillas, peso muerto 1P, buenos días 1P, split ISO catch, caída 1P lateral, y core dinámico
(roll out, plancha carrera, antiflexión lateral dinámica). La biblioteca pasó de 109 a **130**.

### El validador tuvo que aprender la diferencia

La regla de no duplicación marcaba como error `bench → ISO push → lanzamiento`, que es
exactamente el método. Ahora cada ejercicio tiene una **cualidad** (`pesado`, `isométrico`,
`balístico`, `dinámico`, `tejido`) y la regla distingue:

- **Método**: mismo patrón, cualidades distintas → válido
- **Volumen sin criterio**: `bench → push-up → TRX push-up`, tres veces pesado → error

Lo mismo con el balance empuje/tracción: un trío de contraste cuenta como **un** patrón de
empuje, no tres. Sin ese cambio, todos los días de press disparaban una falsa alarma.

### Rampa de repeticiones

Su plan no usaba series parejas sino rampas dentro del ejercicio: `8,8,6,6` · `8,6,6,4` ·
`6,6,4,4`. La carga sube mientras las repeticiones bajan. ATLAS ahora prescribe así, y la rampa
avanza por semana dentro del bloque de cuatro.

### Lo que NO se incorporó

Sus bloques 5 y 6 eran hipertrofia accesoria — bíceps, tríceps, trapecio, vuelos frontales,
remo al mentón. Paul pidió explícitamente dejarlos afuera.

Tampoco se copió su estructura de 5-6 bloques: ATLAS mantiene los cuatro (Zona Media, Fuerza,
Atleta, Finisher) y el finisher metabólico, que su plan anterior no tenía.
