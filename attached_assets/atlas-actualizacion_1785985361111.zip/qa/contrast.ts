/** Verifica el método de contraste: mismo patrón, cualidades distintas. */
import { buildProgram } from '../src/data/program';
import { qualityOf, isContrastSet } from '../src/data/qualities';
import { primaryPattern } from '../src/data/patterns';
import { getExercise } from '../src/data/exercises';
import { analyzeSession } from '../src/lib/intelligence';

let failed = 0;
const check = (name: string, ok: boolean, detail = '') => {
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failed += 1;
};

const prog = buildProgram('2026-01-05');
const strength = prog.filter((w) => w.blocks[1]?.kind === 'fuerza').map((w) => ({ w, b: w.blocks[1] }));

check('Todos los bloques de fuerza son tríos', strength.every(({ b }) => b.items.length === 3), `${strength.length} bloques`);

// El primero siempre pesado, nunca un balístico ni un isométrico
const badHeavy = strength.filter(({ b }) => !['pesado'].includes(qualityOf(b.items[0].exerciseId)));
check('El primer ejercicio siempre es el pesado', badHeavy.length === 0,
  badHeavy.map(({ w, b }) => `${w.name} S${w.week}: ${getExercise(b.items[0].exerciseId).name} (${qualityOf(b.items[0].exerciseId)})`).join(' · '));

// Las tres cualidades tienen que ser distintas entre sí
const noContrast = strength.filter(({ b }) => new Set(b.items.map((i) => qualityOf(i.exerciseId))).size < 3);
check('Las tres cualidades del trío son distintas', noContrast.length === 0,
  noContrast.map(({ w, b }) => `${w.name} S${w.week}: ${b.items.map((i) => qualityOf(i.exerciseId)).join('/')}`).join(' · '));

// Rampa de repeticiones en el pesado
const noRamp = strength.filter(({ b }) => !/,/.test(b.items[0].reps ?? ''));
check('El pesado usa rampa de repeticiones', noRamp.length === 0, `${noRamp.length} sin rampa`);

// El validador NO debe marcar los tríos como error
const flagged = prog
  .filter((w) => !w.externalActivity && w.name !== 'Recovery')
  .filter((w) => analyzeSession(w).issues.some((i) => i.id.includes('dup') && i.id.includes('fuerza')));
check('El validador acepta los tríos de contraste', flagged.length === 0,
  flagged.map((w) => `S${w.week} ${w.name}`).join(', '));

// Pero SÍ debe marcar tres ejercicios de la misma cualidad
check('bench → push-up → TRX push-up sigue siendo error',
  !isContrastSet(['bench-press', 'push-up', 'trx-push-up']));
check('bench → ISO push → lanzamiento es método válido',
  isContrastSet(['bench-press', 'bench-iso-push', 'supine-mb-throw']));

// Todas las sesiones siguen válidas
const invalid = prog.filter((w) => !w.externalActivity && w.name !== 'Recovery').filter((w) => !analyzeSession(w).valid);
check('Las sesiones siguen pasando la validación completa', invalid.length === 0,
  invalid.map((w) => `S${w.week} ${w.name}: ${analyzeSession(w).issues[0]?.message}`).join(' | '));

// Variedad de balísticos y de isométricos
const ballistics = new Set(strength.map(({ b }) => b.items[2].exerciseId));
const isos = new Set(strength.map(({ b }) => b.items[1].exerciseId));
check('Hay variedad de balísticos', ballistics.size >= 8, `${ballistics.size} distintos`);
check('Hay variedad de isométricos', isos.size >= 6, `${isos.size} distintos`);

console.log(`\nTríos analizados: ${strength.length}`);
if (failed) {
  console.error(`\n${failed} verificaciones fallaron`);
  process.exit(1);
}
