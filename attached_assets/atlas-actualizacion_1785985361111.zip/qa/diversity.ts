/** Verifica que dentro de una misma semana no se repita demasiado el mismo ejercicio. */
import { buildProgram, TOTAL_WEEKS } from '../src/data/program';
import { getExercise } from '../src/data/exercises';
import { primaryPattern } from '../src/data/patterns';

let failed = 0;
const check = (name: string, ok: boolean, detail = '') => {
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failed += 1;
};

const prog = buildProgram('2026-01-05');

/** Ejercicios de alto costo neuromuscular: repetirlos mucho en la semana es un error. */
const EXPENSIVE = ['sprint', 'hill-sprint', 'box-jump', 'drop-jump', 'broad-jump', 'hang-power-clean', 'shuttle-run', 'bench-press', 'box-squat', 'front-squat', 'back-squat', 'deadlift', 'push-press'];

const weekly = (week: number) => {
  const days = prog.filter((w) => w.week === week && !w.externalActivity && w.name !== 'Recovery');
  const count = new Map<string, number>();
  days.forEach((w) => w.blocks.forEach((b) => b.items.forEach((i) => count.set(i.exerciseId, (count.get(i.exerciseId) ?? 0) + 1))));
  const slots = [...count.values()].reduce((a, b) => a + b, 0);
  return { count, slots, distinct: count.size };
};

for (let week = 1; week <= TOTAL_WEEKS; week += 1) {
  const { count, slots, distinct } = weekly(week);
  const max = Math.max(...count.values());
  const worst = [...count.entries()].filter(([, n]) => n === max).map(([id]) => getExercise(id).name);

  check(`S${week}: ningún ejercicio aparece más de 3 veces`, max <= 3, `máx ${max}× (${worst.join(', ')})`);

  const overExpensive = [...count.entries()].filter(([id, n]) => EXPENSIVE.includes(id) && n > 2);
  check(
    `S${week}: los ejercicios de alto costo no pasan de 2 veces`,
    overExpensive.length === 0,
    overExpensive.map(([id, n]) => `${getExercise(id).name} ${n}×`).join(', '),
  );

  // Variedad general: al menos 2 de cada 3 slots debe ser un ejercicio distinto
  const ratio = distinct / slots;
  check(`S${week}: variedad por encima del 65 %`, ratio >= 0.65, `${distinct}/${slots} = ${(ratio * 100).toFixed(0)} %`);
}

// El finisher no puede terminar siempre igual
for (let week = 1; week <= TOTAL_WEEKS; week += 1) {
  const finishers = prog
    .filter((w) => w.week === week && !w.externalActivity && w.name !== 'Recovery')
    .map((w) => w.blocks.find((b) => b.kind === 'finisher')!.formatLabel);
  check(`S${week}: los finishers no son todos el mismo formato`, new Set(finishers).size >= 3, finishers.join(' · '));
}

// La soga y los swings son herramientas, no la columna vertebral
for (let week = 1; week <= TOTAL_WEEKS; week += 1) {
  const { count } = weekly(week);
  const rope = count.get('jump-rope') ?? 0;
  const swing = count.get('kb-swing') ?? 0;
  check(`S${week}: soga y KB swing no dominan la semana`, rope <= 3 && swing <= 3, `soga ${rope}× · swing ${swing}×`);
}

/**
 * Continuidad entre semanas.
 * Dentro de un bloque de 4 semanas la repetición es deseable: sin ella no hay
 * progresión de carga. Lo que no queremos es que la semana sea idéntica.
 * La banda sana está entre 70 % y 95 % de solapamiento.
 */
for (let week = 2; week <= TOTAL_WEEKS; week += 1) {
  const a = new Set(weekly(week - 1).count.keys());
  const b = new Set(weekly(week).count.keys());
  const overlap = [...b].filter((x) => a.has(x)).length / b.size;
  check(
    `S${week}: continuidad sana con S${week - 1} (70-95 % de solapamiento)`,
    overlap >= 0.7 && overlap <= 0.95,
    `${(overlap * 100).toFixed(0)} % compartido`,
  );
}

// Pero los principales sí tienen que cambiar: mismo patrón, distinto estímulo
for (let week = 2; week <= TOTAL_WEEKS; week += 1) {
  const mainsPrev = prog.filter((w) => w.week === week - 1 && w.blocks[1]?.kind === 'fuerza').map((w) => w.blocks[1].items[0].exerciseId);
  const mains = prog.filter((w) => w.week === week && w.blocks[1]?.kind === 'fuerza').map((w) => w.blocks[1].items[0].exerciseId);
  const same = mains.filter((m, i) => m === mainsPrev[i]).length;
  check(
    `S${week}: al menos la mitad de los principales cambia respecto de S${week - 1}`,
    same <= Math.floor(mains.length / 2),
    `${same} de ${mains.length} iguales`,
  );
}

// Todos los patrones aparecen cada semana
for (let week = 1; week <= TOTAL_WEEKS; week += 1) {
  const { count } = weekly(week);
  const patterns = new Set([...count.keys()].map(primaryPattern));
  const needed = ['upper-push', 'upper-pull', 'squat', 'hinge', 'rotation', 'anti-rotation', 'locomotion', 'plyometrics'];
  const missing = needed.filter((p) => !patterns.has(p as never));
  check(`S${week}: la semana cubre los 8 patrones clave`, missing.length === 0, missing.join(', '));
}

const totals = [1, 2, 3, 4].map((w) => weekly(w));
console.log(
  `\nPromedio: ${(totals.reduce((s, t) => s + t.distinct, 0) / 4).toFixed(0)} ejercicios distintos por semana sobre ${(totals.reduce((s, t) => s + t.slots, 0) / 4).toFixed(0)} slots`,
);

if (failed) {
  console.error(`\n${failed} verificaciones fallaron`);
  process.exit(1);
}
