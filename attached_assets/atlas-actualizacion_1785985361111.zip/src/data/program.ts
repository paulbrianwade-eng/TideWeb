import type { PrimaryCapability, SportActivity, SportModule, Workout, WorkoutBlock } from '../types';
import { addDays, todayISO } from '../lib/date';
import type { Station } from './equipment';
import { STATION_LABEL } from './equipment';
import { getExercise } from './exercises';
import { autoFix } from '../lib/intelligence';
import { ATLETA, FINISHERS, TABATA_FULL, ZONA_MEDIA, mk } from './session-blocks';
import type { BlockDraft } from './session-blocks';

/** Primera fase: cuatro semanas. */
export const TOTAL_WEEKS = 4;
/**
 * Fecha de arranque por defecto. Una vez que el estado guarda `programStart`,
 * NO se recalcula: si arrancaste un lunes, el lunes sigue siendo el Día 1 aunque
 * abras la app un jueves. Así lo que ya entrenaste no se corre de lugar.
 */
export const defaultStart = (): string => todayISO();

export const ACTIVITY_LABEL: Record<SportActivity, string> = {
  surf: 'Surf', golf: 'Golf', ski: 'Esquí', running: 'Running',
  rest: 'Descanso', gym: 'Gimnasio', home: 'Entrenamiento en casa',
};

export const BLOCK_LABEL: Record<WorkoutBlock['kind'], string> = {
  'zona-media': 'Zona media',
  fuerza: 'Fuerza',
  atleta: 'Atleta',
  finisher: 'Finisher',
  outdoor: 'Outdoor',
  recovery: 'Recuperación',
};

/**
 * SELECTOR CONSCIENTE DE LA SEMANA
 * ────────────────────────────────
 * Elegir cada circuito de forma independiente hacía que la soga y los KB swings
 * aparecieran cuatro veces por semana. Ahora la semana se arma en orden llevando
 * la cuenta de lo ya usado: de cada pool se elige la variante que menos repite.
 *
 * El desempate sigue la rotación semanal, así dos semanas distintas no eligen
 * siempre lo mismo.
 */
type Usage = Map<string, number>;

/** Cuánto castiga repetir. Correr y saltar a la soga toleran más frecuencia que un salto pesado. */
const REPEAT_COST = (exerciseId: string): number => {
  const cheap = ['jump-rope', 'mountain-climber', 'burpee', 'dead-bug', 'pallof-press', 'soleus-raise'];
  const expensive = ['sprint', 'hill-sprint', 'box-jump', 'drop-jump', 'broad-jump', 'hang-power-clean', 'shuttle-run'];
  if (expensive.includes(exerciseId)) return 6;
  if (cheap.includes(exerciseId)) return 1;
  return 3;
};

const costOf = <T extends { items: { exerciseId: string }[] }>(draft: T, usage: Usage): number =>
  draft.items.reduce((sum, i) => sum + (usage.get(i.exerciseId) ?? 0) * REPEAT_COST(i.exerciseId), 0);

const spend = (items: { exerciseId: string }[], usage: Usage): void => {
  items.forEach((i) => usage.set(i.exerciseId, (usage.get(i.exerciseId) ?? 0) + 1));
};

/** Elige del pool la variante con menor colisión; desempata por rotación semanal. */
const pickFresh = <T extends { items: { exerciseId: string }[] }>(
  pool: T[],
  usage: Usage,
  week: number,
  offset: number,
): T => {
  const start = (week - 1 + offset) % pool.length;
  const ordered = [...pool.slice(start), ...pool.slice(0, start)];
  let best = ordered[0];
  let bestCost = costOf(best, usage);
  ordered.forEach((d) => {
    const c = costOf(d, usage);
    if (c < bestCost) {
      best = d;
      bestCost = c;
    }
  });
  return best;
};

/**
 * DIVERSIDAD DE EJERCICIOS
 * ────────────────────────
 * El mismo patrón, distinto estímulo cada semana. Ningún ejercicio principal
 * se repite dos semanas seguidas; el ciclo de cuatro garantiza que entre una
 * aparición y la siguiente pasen al menos dos semanas.
 */
const VARIATIONS: Record<string, string[]> = {
  // Sentadilla pesada del lunes
  'monday-main': ['box-squat', 'front-squat', 'back-squat', 'box-squat'],
  // Tracción accesoria (martes y viernes)
  pull: ['trx-row', 'inverted-row', 'pull-up', 'trx-power-pull'],
  // Balísticos que cierran cada trío
  'monday-ballistic': ['box-jump', 'split-squat-iso-catch', 'lateral-drop-1p', 'broad-jump'],
  'tuesday-ballistic': ['supine-mb-throw', 'mb-slam', 'supine-mb-throw', 'kneeling-oh-throw'],
  // Empuje horizontal del martes
  'tuesday-main': ['bench-press', 'incline-bench-press', 'bench-press', 'trx-push-up'],
  // Empuje vertical del jueves: el pesado nunca puede ser un balístico
  'thursday-main': ['overhead-press', 'kb-shoulder-press', 'overhead-press', 'landmine-press'],
  'thursday-ballistic': ['kneeling-oh-throw', 'push-press', 'kneeling-oh-throw', 'kb-press-explosive-1m'],
  // Balístico de tracción del viernes: dorsal a máxima velocidad
  'friday-ballistic': ['mb-slam', 'hang-power-clean', 'mb-slam', 'kb-clean'],
  // Bisagra unipodal
  'single-hinge': ['single-leg-rdl', 'deadlift-1p', 'good-morning-1p', 'single-leg-rdl'],
  // Isométrico / excéntrico de esquí
  'ski-accessory': ['split-squat-hold', 'step-down', 'wall-sit', 'reverse-nordic'],
};

const vary = (key: keyof typeof VARIATIONS | string, week: number): string => {
  const pool = VARIATIONS[key] ?? [];
  return pool[(week - 1) % pool.length];
};

/**
 * BLOQUE 2 · FUERZA — 15-18 min.
 * 1 principal + 2 accesorios. Una sola configuración de barra por sesión:
 * después del principal se pasa a TRX, bandas, kettlebells o peso corporal.
 */
/**
 * BLOQUE 2 · FUERZA — trío de contraste.
 * Mismo patrón, tres cualidades: pesado → isométrico → balístico.
 * Es la estructura que mejor funcionó en su plan anterior: producir fuerza,
 * sostenerla y después expresarla rápido, todo sobre el mismo movimiento.
 */
interface ContrastDraft {
  /** Pesado: el que lleva la carga. Repeticiones en rampa (8,8,6,6). */
  heavy: { id: string; sets: number; reps: string; rpe?: string; rest: string; unilateral?: boolean; load?: string };
  /** Isométrico: sostener la posición donde el patrón se traba. */
  iso: { id: string; sets: number; duration: string; unilateral?: boolean };
  /** Balístico: expresar la fuerza en velocidad. */
  ballistic: { id: string; sets: number; reps: string; unilateral?: boolean; load?: string };
}

/** Rampa de repeticiones por fase: la carga sube mientras las reps bajan. */
const RAMP: Record<number, string> = { 1: '8,8,6,6', 2: '8,6,6,4', 3: '6,6,4,4', 4: '6,6,6' };

const fuerzaBlock = (id: string, d: ContrastDraft, minutes = 17): WorkoutBlock =>
  mk(id, {
    kind: 'fuerza', index: 2, title: 'Fuerza', minutes,
    format: 'sets', formatLabel: `Contraste · ${d.heavy.sets} rondas`,
    focus: 'Pesado → isométrico → balístico, mismo patrón',
    rest: d.heavy.rest,
    items: [
      {
        exerciseId: d.heavy.id, order: 'A', sets: d.heavy.sets, reps: d.heavy.reps,
        rpe: d.heavy.rpe, rest: d.heavy.rest, unilateral: d.heavy.unilateral, load: d.heavy.load,
        instructions: 'Rampa de carga: sube el peso mientras bajan las repeticiones.',
      },
      {
        exerciseId: d.iso.id, order: 'B', sets: d.iso.sets, duration: d.iso.duration,
        unilateral: d.iso.unilateral, instructions: 'Máxima intención. Va después del pesado, sin descanso largo.',
      },
      {
        exerciseId: d.ballistic.id, order: 'C', sets: d.ballistic.sets, reps: d.ballistic.reps,
        unilateral: d.ballistic.unilateral, load: d.ballistic.load,
        instructions: 'Velocidad máxima. Si baja, cortá la serie.',
      },
    ],
  });

interface DayPlan {
  name: string;
  tagline: string;
  objective: string;
  rpe: string;
  station: Station;
  capability: PrimaryCapability;
  transfersTo: SportModule[];
  next: SportActivity | null;
  external?: SportActivity;
  build: (id: string, week: number, usage: Usage) => WorkoutBlock[];
  note: (week: number) => string;
}

/** Progresión de carga a lo largo de las 4 semanas. La cuarta es de descarga. */
const wave = (week: number) => {
  const w = ((week - 1) % 4) + 1;
  if (w === 4) return { sets: 3, rpe: '6', deload: true };
  return { sets: 4 + (w > 1 ? 1 : 0), rpe: w === 1 ? '7' : w === 2 ? '7–8' : '8', deload: false };
};

const DAYS: DayPlan[] = [
  // ─────────── LUNES ───────────
  {
    name: 'Strong Legs',
    tagline: 'Ski Performance',
    objective:
      'Fuerza de piernas, resistencia excéntrica, estabilidad unilateral y capacidad para tolerar bajadas largas de esquí.',
    rpe: '8', station: 'barra', capability: 'Strength',
    transfersTo: ['ski', 'running'], next: 'gym',
    build: (id, week, usage) => {
      const w = wave(week);
      return [
        mk(id, pickFresh(ZONA_MEDIA, usage, week, 0)),
        fuerzaBlock(id, {
          heavy: { id: vary('monday-main', week), sets: w.sets, reps: RAMP[((week - 1) % 4) + 1], rpe: w.rpe, rest: '90 s' },
          iso: { id: vary('ski-accessory', week), sets: w.sets, duration: '10 s', unilateral: true },
          ballistic: { id: vary('monday-ballistic', week), sets: w.sets, reps: '4', unilateral: week % 2 === 0 },
        }),
        mk(id, pickFresh(ATLETA, usage, week, 0)),
        mk(id, pickFresh(FINISHERS, usage, week, 0)),
      ];
    },
    note: (week) =>
      wave(week).deload
        ? 'Semana de descarga: misma barra, una serie menos y RPE 6. El finisher se mantiene.'
        : 'La barra se monta una vez para el box squat y no se toca más. Los accesorios salen del cajón y del peso corporal.',
  },
  // ─────────── MARTES ───────────
  {
    name: 'Paddle Power',
    tagline: 'Upper Body + Surf',
    objective:
      'Fuerza de empuje, resistencia de tracción y estabilidad escapular para sostener horas de remada.',
    rpe: '7–8', station: 'barra', capability: 'Strength',
    transfersTo: ['surf'], next: 'gym',
    build: (id, week, usage) => {
      const w = wave(week);
      return [
        mk(id, pickFresh(ZONA_MEDIA, usage, week, 1)),
        fuerzaBlock(id, {
          heavy: { id: vary('tuesday-main', week), sets: w.sets, reps: RAMP[((week - 1) % 4) + 1], rpe: w.rpe, rest: '2 min' },
          iso: { id: 'bench-iso-push', sets: w.sets, duration: '5 s' },
          ballistic: { id: vary('tuesday-ballistic', week), sets: w.sets, reps: '6' },
        }),
        mk(id, pickFresh(ATLETA, usage, week, 1)),
        mk(id, pickFresh(FINISHERS, usage, week, 1)),
      ];
    },
    note: () =>
      'Banco y barra armados de principio a fin. Después del press no se toca un disco: TRX y kettlebell.',
  },
  // ─────────── MIÉRCOLES ───────────
  {
    name: 'Run Fast',
    tagline: 'Running Performance',
    objective:
      'Ordenar la mecánica de carrera, fortalecer pie y tobillo y sumar motor sin castigar las piernas.',
    rpe: '6–7', station: 'outdoor', capability: 'Engine',
    transfersTo: ['running'], next: 'gym',
    build: (id, week, usage) => [
      mk(id, pickFresh(ZONA_MEDIA, usage, week, 2)),
      fuerzaBlock(
        id,
        {
          heavy: { id: vary('single-hinge', week), sets: 4, reps: RAMP[((week - 1) % 4) + 1], unilateral: true, rest: '60 s', load: 'KB 20 kg' },
          iso: { id: 'hip-bridge-iso-1p', sets: 4, duration: '5 s', unilateral: true },
          ballistic: { id: 'triple-extension-march', sets: 4, reps: '3', unilateral: true },
        },
        15,
      ),
      mk(id, pickFresh(ATLETA, usage, week, 2)),
      mk(id, pickFresh(FINISHERS, usage, week, 2)),
    ],
    note: () =>
      'Sin barra hoy. Los drills van con las piernas frescas: skipping, pogo y aceleraciones ordenan la zancada antes del motor.',
  },
  // ─────────── JUEVES ───────────
  {
    name: 'Rotate',
    tagline: 'Golf Performance',
    objective:
      'Potencia rotacional, control de la desaceleración y transferencia directa a la velocidad de swing.',
    rpe: '7–8', station: 'barra', capability: 'Rotation',
    transfersTo: ['golf', 'surf'], next: 'gym',
    build: (id, week, usage) => {
      const w = wave(week);
      return [
        mk(id, pickFresh(ZONA_MEDIA, usage, week, 3)),
        fuerzaBlock(id, {
          heavy: { id: vary('thursday-main', week), sets: w.deload ? 4 : 5, reps: RAMP[((week - 1) % 4) + 1], rpe: w.deload ? '6' : '7', rest: '2 min' },
          iso: { id: 'overhead-iso-push', sets: 4, duration: '5 s' },
          ballistic: { id: vary('thursday-ballistic', week), sets: 4, reps: '6', unilateral: vary('thursday-ballistic', week).includes('1m') },
        }),
        mk(id, pickFresh(ATLETA, usage, week, 3)),
        mk(id, pickFresh(FINISHERS, usage, week, 3)),
      ];
    },
    note: () =>
      'La velocidad rotacional se entrena fresca. Si el lanzamiento pierde potencia, cortá la serie: no hay premio por completarla lenta.',
  },
  // ─────────── VIERNES ───────────
  {
    name: 'Full Send',
    tagline: 'Hybrid Athletic',
    objective:
      'Sesión híbrida: potencia con carga técnica, trabajo unilateral y un finisher que deja la semana cerrada.',
    rpe: '8', station: 'barra', capability: 'Athletic',
    transfersTo: ['ski', 'surf', 'running'], next: 'surf',
    build: (id, week, usage) => {
      const w = wave(week);
      return [
        mk(id, pickFresh(ZONA_MEDIA, usage, week, 4)),
        fuerzaBlock(id, {
          heavy: { id: vary('pull', week), sets: w.sets, reps: RAMP[((week - 1) % 4) + 1], rpe: w.rpe, rest: '90 s' },
          iso: { id: week % 2 === 0 ? 'pull-up-iso-hold' : 'row-iso-hold', sets: 4, duration: '10 s', unilateral: week % 2 !== 0 },
          ballistic: { id: vary('friday-ballistic', week), sets: 4, reps: '6', load: 'Carga técnica' },
        }),
        mk(id, pickFresh(ATLETA, usage, week, 4)),
        mk(id, pickFresh(FINISHERS, usage, week, 4)),
      ];
    },
    note: () =>
      'El hang power clean es técnico: seis series de tres con carga que se mueve rápido. Nunca al fallo y nunca dentro del finisher.',
  },
  // ─────────── SÁBADO ───────────
  {
    name: 'Outdoor',
    tagline: 'Surf · Golf · Trail · Esquí',
    objective: 'El día en que el entrenamiento se transforma en deporte. Estructura libre según lo que haya.',
    rpe: '6–8', station: 'outdoor', capability: 'Power',
    transfersTo: ['surf', 'golf', 'ski', 'running'], next: 'rest', external: 'surf',
    build: (id, week, usage) => [
      mk(id, {
        kind: 'outdoor', index: 1, title: 'Preparación', minutes: 10,
        format: 'rounds', formatLabel: '2 vueltas', rounds: 2,
        focus: 'Antes de salir',
        items: [
          { exerciseId: 'hip-9090', reps: '8 cambios' },
          { exerciseId: 'worlds-greatest-stretch', reps: '5', unilateral: true },
          { exerciseId: 'skipping', distance: '20 m' },
          { exerciseId: 'pogo-jump', reps: '15' },
        ],
      }),
      mk(id, {
        kind: 'outdoor', index: 2, title: 'Actividad', minutes: 60,
        format: 'sets', formatLabel: 'Libre',
        focus: 'Surf, golf, trail, esquí o cuestas',
        scoreType: 'time', scoreHint: 'Duración total',
        items: [
          { exerciseId: 'hill-sprint', sets: 8, duration: '12 s', rest: 'Vuelta caminando', instructions: 'Solo si no hay olas, cancha ni nieve.' },
        ],
      }),
      mk(id, pickFresh(RECOVERY_POOL, usage, week, 0)),
    ],
    note: () =>
      'Si hay olas, nieve o cancha, ese es el entrenamiento. Si no, ocho cuestas de doce segundos rinden más que cuarenta minutos trotando.',
  },
  // ─────────── DOMINGO ───────────
  {
    name: 'Recovery',
    tagline: 'Movilidad y respiración',
    objective: 'Bajar el sistema nervioso, devolverle rango a la cadera y llegar entero al lunes.',
    rpe: '2–3', station: 'suelo', capability: 'Recovery',
    transfersTo: [], next: 'gym',
    build: (id, week, usage) => [
      mk(id, {
        kind: 'recovery', index: 1, title: 'Movilidad', minutes: 15,
        format: 'rounds', formatLabel: '2 vueltas', rounds: 2,
        focus: 'Cadera y torácica',
        items: [
          { exerciseId: 'hip-flow', duration: '3 min' },
          { exerciseId: 'hip-9090', reps: '8 cambios' },
          { exerciseId: 'open-book', reps: '8', unilateral: true },
          { exerciseId: 'hip-flexor-stretch', duration: '40 s', unilateral: true, isometric: true },
        ],
      }),
      mk(id, pickFresh(RECOVERY_POOL, usage, week, 0)),
    ],
    note: () =>
      'Día de recuperación real. Si te levantás cansado, quedate con la movilidad y la respiración: la caminata es opcional.',
  },
];

const RECOVERY_POOL: BlockDraft[] = [
  {
    kind: 'recovery', index: 2, title: 'Down regulation', minutes: 8,
    format: 'sets', formatLabel: 'Continuo', focus: 'Bajar pulsaciones',
    items: [
      { exerciseId: 'foam-roller', duration: '4 min', instructions: 'Cuádriceps, glúteo y dorsal.' },
      { exerciseId: 'down-regulation', duration: '4 min' },
    ],
  },
  {
    kind: 'recovery', index: 2, title: 'Respiración', minutes: 6,
    format: 'sets', formatLabel: 'Continuo', focus: 'Sistema nervioso',
    items: [
      { exerciseId: 'nasal-breathing', duration: '3 min', instructions: 'Inhalar 4 s · exhalar 8 s.' },
      { exerciseId: 'easy-walk', duration: '20 min', instructions: 'Opcional.' },
    ],
  },
];

/** Sesión especial: no forma parte de la semana, se abre a demanda. */
export const TABATA_SESSION = TABATA_FULL;

export const WEEK_STRUCTURE = DAYS.map((d) => ({
  name: d.name, tagline: d.tagline, station: STATION_LABEL[d.station],
}));

/** Equipamiento a preparar: derivado de los ejercicios reales de la sesión. */
export const equipmentFor = (blocks: WorkoutBlock[]): string[] => {
  const set = new Set<string>();
  blocks.forEach((b) => b.items.forEach((it) => getExercise(it.exerciseId).equipment.forEach((e) => set.add(e))));
  set.delete('Peso corporal');
  set.delete('Colchoneta');
  return [...set].sort();
};

/** Minutos totales. Criterio de aceptación: nunca más de 50. */
export const totalMinutes = (blocks: WorkoutBlock[]): number =>
  blocks.reduce((sum, b) => sum + b.minutes, 0);

const buildWorkout = (week: number, dayIndex: number, date: string, usage: Usage): Workout => {
  const plan = DAYS[dayIndex];
  const id = `w${week}d${dayIndex + 1}`;
  const rawBlocks = plan.build(id, week, usage);
  const mins = totalMinutes(rawBlocks);

  const draft: Workout = {
    id, week, day: dayIndex + 1, date,
    name: plan.name,
    subtitle: plan.tagline,
    objective: plan.objective,
    duration: plan.external ? 'Jornada' : `${mins} min`,
    plannedRpe: wave(week).deload && !plan.external ? '6–7' : plan.rpe,
    coachNote: plan.note(week),
    nextDayActivity: plan.next,
    blocks: rawBlocks,
    adaptations: [],
    status: plan.external ? 'external' : 'pending',
    externalActivity: plan.external,
    phase: 1,
    modules: plan.transfersTo,
    station: plan.station,
    capability: plan.capability,
    equipment: equipmentFor(rawBlocks),
    transfersTo: plan.transfersTo,
  };

  /**
   * El generador se autocorrige: si el validador de patrones encuentra un hueco
   * (sin unilateral, sin rotación, sin componente atlético), se aplica la
   * sustitución sugerida antes de que la sesión exista.
   */
  const fixed = plan.external ? draft : autoFix(draft);

  // Recién ahora se contabiliza lo que realmente quedó programado.
  fixed.blocks.forEach((b) => spend(b.items, usage));

  return { ...fixed, equipment: equipmentFor(fixed.blocks) };
};

export const buildProgram = (start: string = defaultStart()): Workout[] => {
  const out: Workout[] = [];
  let previous: Usage = new Map();

  for (let w = 1; w <= TOTAL_WEEKS; w += 1) {
    /**
     * El registro arranca cada semana con un lastre liviano de lo usado la
     * semana anterior. Así la variedad no es solo dentro de la semana: la
     * semana siguiente también se siente distinta, sin expulsar los ejercicios
     * que tienen que estar sí o sí.
     */
    const usage: Usage = new Map();
    previous.forEach((_, id) => usage.set(id, 1));
    const weekStart = out.length;
    for (let d = 0; d < DAYS.length; d += 1) {
      out.push(buildWorkout(w, d, addDays(start, (w - 1) * 7 + d), usage));
    }

    // Lo realmente programado esta semana es el lastre de la próxima.
    previous = new Map();
    out.slice(weekStart).forEach((wk) =>
      wk.blocks.forEach((b) => b.items.forEach((i) => previous.set(i.exerciseId, 1))),
    );
  }
  return out;
};

export { STATION_LABEL } from './equipment';
