import type { ExercisePrescription, SportActivity, SportModule, Workout, WorkoutBlock } from '../types';
import { addDays, todayISO } from '../lib/date';
import { isDeload, phaseFor } from './phases';
import {
  ATHLETIC_CIRCUITS,
  ENGINE_SESSIONS,
  MODULE_POOL,
  MOVEMENT_FLOWS,
  POWER_MENUS,
  RECOVERY_PROTOCOLS,
  RESET_FLOWS,
  block,
  pick,
} from './blocks';

/** Total del macrociclo. */
export const TOTAL_WEEKS = 16;

/**
 * El programa se ancla al día actual: hoy es el Día 1 de la Semana 1.
 * Para anclarlo a un lunes fijo, poné una fecha 'YYYY-MM-DD' acá.
 */
export const PROGRAM_START = todayISO();

export const ACTIVITY_LABEL: Record<SportActivity, string> = {
  surf: 'Surf',
  golf: 'Golf',
  ski: 'Esquí',
  running: 'Running',
  rest: 'Descanso',
  gym: 'Gimnasio',
  home: 'Entrenamiento en casa',
};

const p = (exerciseId: string, extra: Partial<ExercisePrescription> = {}): ExercisePrescription => ({
  exerciseId,
  ...extra,
});

const resetBlock = (id: string, week: number): WorkoutBlock =>
  block(`${id}-reset`, 'reset', 'Reset', '5 min', pick(RESET_FLOWS, week), {
    focus: 'Entrar en modo entrenamiento',
  });

const movementBlock = (id: string, week: number): WorkoutBlock =>
  block(`${id}-movement`, 'movement', 'Movement', '8 min', pick(MOVEMENT_FLOWS, week), {
    focus: 'Calidad de movimiento',
  });

const powerBlock = (id: string, week: number): WorkoutBlock => {
  const phase = phaseFor(week);
  const menu = pick(POWER_MENUS, week);
  return block(
    `${id}-power`,
    'power',
    'Power',
    '10 min',
    menu.items.map((ex, i) =>
      p(ex, {
        order: `A${i + 1}`,
        sets: phase.power.sets,
        reps: phase.power.reps,
        rest: phase.power.rest,
        unilateral: ex.includes('rotational') || ex.includes('lateral') || ex.includes('skater'),
        instructions: i === 0 ? phase.power.intent : undefined,
      }),
    ),
    { focus: menu.focus },
  );
};

const athleticBlock = (id: string, week: number): WorkoutBlock => {
  const circuit = pick(ATHLETIC_CIRCUITS, week);
  return block(`${id}-athletic`, 'athletic', 'Athletic Block', '15 min', circuit.items, {
    focus: circuit.name,
    rounds: circuit.rounds,
    rest: circuit.rest,
  });
};

const engineBlock = (id: string, key: keyof typeof ENGINE_SESSIONS): WorkoutBlock => {
  const s = ENGINE_SESSIONS[key];
  return block(`${id}-engine`, 'engine', 'Engine', s.duration, s.items, { focus: s.focus });
};

const recoveryBlock = (id: string, week: number): WorkoutBlock => {
  const proto = pick(RECOVERY_PROTOCOLS, week);
  return block(`${id}-recovery`, 'recovery', 'Recovery', '8 min', proto.items, { focus: proto.name });
};

const moduleBlock = (id: string, week: number, mod: SportModule, title: string): WorkoutBlock =>
  block(`${id}-${mod}`, 'strength', title, '12 min', pick(MODULE_POOL[mod], week), {
    focus: 'Reemplaza el accesorio del día',
    module: mod,
  });

/** Bloque de fuerza principal, con el esquema de la fase. */
const strengthBlock = (
  id: string,
  week: number,
  main: { id: string; order: string }[],
  accessories: { id: string; order: string; unilateral?: boolean }[],
): WorkoutBlock => {
  const phase = phaseFor(week);
  const deload = isDeload(week);
  const sets = deload ? Math.max(2, phase.strength.sets - 2) : phase.strength.sets;
  return block(
    `${id}-strength`,
    'strength',
    'Strength',
    deload ? '20 min' : '28 min',
    [
      ...main.map((m) =>
        p(m.id, {
          order: m.order,
          sets,
          reps: phase.strength.reps,
          rpe: deload ? '6' : phase.strength.rpe,
          rest: phase.strength.rest,
        }),
      ),
      ...accessories.map((a) =>
        p(a.id, {
          order: a.order,
          sets: deload ? 2 : 3,
          reps: phase.accessoryReps,
          unilateral: a.unilateral,
          rpe: deload ? '6' : '8',
        }),
      ),
    ],
    { focus: `Fase ${phase.id} · ${phase.name}${deload ? ' · descarga' : ''}` },
  );
};

interface DayPlan {
  name: string;
  subtitle: string;
  objective: string;
  duration: string;
  rpe: string;
  next: SportActivity | null;
  modules: SportModule[];
  external?: SportActivity;
  build: (id: string, week: number) => WorkoutBlock[];
  note: (week: number) => string;
}

const DAYS: DayPlan[] = [
  // ── LUNES ──
  {
    name: 'Lower Strength + Ski',
    subtitle: 'Fuerza inferior · Isometría · Plano frontal',
    objective:
      'Construir fuerza de piernas y, en el mismo día, la resistencia local e isométrica que el esquí exige. El módulo Ski Performance reemplaza el accesorio tradicional.',
    duration: '70–75 min',
    rpe: '8',
    next: 'gym',
    modules: ['ski'],
    build: (id, week) => [
      resetBlock(id, week),
      movementBlock(id, week),
      powerBlock(id, week),
      strengthBlock(
        id,
        week,
        [
          { id: week % 2 === 0 ? 'front-squat' : 'back-squat', order: 'A' },
          { id: 'romanian-deadlift', order: 'B' },
        ],
        [{ id: 'bulgarian-split-squat', order: 'C', unilateral: true }],
      ),
      moduleBlock(id, week, 'ski', 'Ski Performance'),
      athleticBlock(id, week),
      engineBlock(id, 'assault'),
      recoveryBlock(id, week),
    ],
    note: (week) =>
      isDeload(week)
        ? 'Semana de descarga. Mismos patrones, dos series menos y RPE 6: el objetivo es llegar entero a la próxima fase.'
        : 'El limitante en la nieve no fue la fuerza sino la resistencia: por eso el módulo de esquí va con isometrías largas y excéntricos lentos. No los apures.',
  },
  // ── MARTES ──
  {
    name: 'Upper Strength + Surf',
    subtitle: 'Empuje · Tracción · Estabilidad escapular',
    objective:
      'Fuerza del tren superior con el módulo Surf Performance ocupando el accesorio: hombro resistente, escápula estable y rotación torácica.',
    duration: '65–70 min',
    rpe: '7–8',
    next: 'gym',
    modules: ['surf'],
    build: (id, week) => [
      resetBlock(id, week),
      movementBlock(id, week + 1),
      powerBlock(id, week + 2),
      strengthBlock(
        id,
        week,
        [
          { id: 'bench-press', order: 'A' },
          { id: 'pull-up', order: 'B' },
        ],
        [
          { id: 'landmine-press', order: 'C', unilateral: true },
          { id: 'chest-supported-row', order: 'D' },
        ],
      ),
      moduleBlock(id, week, 'surf', 'Surf Performance'),
      athleticBlock(id, week),
      engineBlock(id, week % 2 === 0 ? 'skierg' : 'row'),
      recoveryBlock(id, week + 1),
    ],
    note: () =>
      'El hombro se entrena con volumen inteligente, no con carga máxima. Si el YTWL o el bottom-up se sienten fáciles con el peso elegido, está bien: son ejercicios de calidad.',
  },
  // ── MIÉRCOLES ──
  {
    name: 'Zone 2 + Running Mechanics',
    subtitle: 'Base aeróbica · Mecánica · Pie y tobillo',
    objective:
      'Construir la base aeróbica que sostiene el resto de la semana y ordenar la mecánica de carrera antes de sumar volumen de kilómetros.',
    duration: '60 min',
    rpe: '5–6',
    next: 'gym',
    modules: ['running'],
    build: (id, week) => [
      resetBlock(id, week + 1),
      movementBlock(id, week + 2),
      moduleBlock(id, week, 'running', 'Running Mechanics'),
      powerBlock(id, week + 3),
      engineBlock(id, week % 4 === 0 ? 'tempo' : 'zone2'),
      athleticBlock(id, week),
      recoveryBlock(id, week + 2),
    ],
    note: () =>
      'Zona 2 significa poder hablar en frases completas. Si no podés, estás corriendo en zona 3 y comprometiendo el jueves. La mecánica va antes de correr, con las piernas frescas.',
  },
  // ── JUEVES ──
  {
    name: 'Athletic Performance + Golf',
    subtitle: 'Potencia rotacional · Desaceleración · Core',
    objective:
      'El día más atlético de la semana: potencia rotacional, control de la desaceleración y el módulo Golf Performance integrado al trabajo de core.',
    duration: '65 min',
    rpe: '7–8',
    next: 'gym',
    modules: ['golf'],
    build: (id, week) => [
      resetBlock(id, week + 2),
      movementBlock(id, week + 3),
      powerBlock(id, week + 1),
      strengthBlock(
        id,
        week,
        [
          { id: 'trap-bar-deadlift', order: 'A' },
          { id: 'db-shoulder-press', order: 'B' },
        ],
        [{ id: 'reverse-lunge', order: 'C', unilateral: true }],
      ),
      moduleBlock(id, week, 'golf', 'Golf Performance'),
      athleticBlock(id, week + 1),
      engineBlock(id, 'assault'),
      recoveryBlock(id, week),
    ],
    note: () =>
      'La velocidad de la cadena rotacional se entrena fresco. Si el lanzamiento pierde velocidad, cortá la serie: no hay premio por hacer las cinco repeticiones lentas.',
  },
  // ── VIERNES ──
  {
    name: 'Hybrid Performance',
    subtitle: 'Fuerza + motor · Fatiga mixta',
    objective:
      'Sostener calidad de movimiento con el pulso alto. Es el día que más se parece a un deporte real: fuerza y motor mezclados.',
    duration: '60 min',
    rpe: '8',
    next: 'surf',
    modules: [],
    build: (id, week) => [
      resetBlock(id, week + 2),
      movementBlock(id, week),
      powerBlock(id, week + 4),
      strengthBlock(
        id,
        week,
        [
          { id: 'push-press', order: 'A' },
          { id: 'hip-thrust', order: 'B' },
        ],
        [{ id: 'farmer-carry', order: 'C' }],
      ),
      athleticBlock(id, week + 2),
      engineBlock(id, week % 2 === 0 ? 'hyrox' : 'threshold'),
      recoveryBlock(id, week + 1),
    ],
    note: () =>
      'Acá se entrena la cabeza tanto como el cuerpo. Distribuí el esfuerzo: la última ronda tiene que poder ser la mejor.',
  },
  // ── SÁBADO ──
  {
    name: 'Outdoor',
    subtitle: 'Surf · Golf · Trail · Running · Esquí',
    objective:
      'El día en que el entrenamiento se transforma en deporte. Elegí la actividad según la temporada y el clima; el trabajo previo está hecho para esto.',
    duration: 'Jornada',
    rpe: '6–8',
    next: 'rest',
    modules: [],
    external: 'surf',
    build: (id, week) => [
      resetBlock(id, week),
      block(
        `${id}-prep`,
        'movement',
        'Preparación específica',
        '10 min',
        [
          p('hip-9090', { reps: '8 cambios' }),
          p('worlds-greatest-stretch', { reps: '5', unilateral: true }),
          p('monster-walk', { reps: '15 pasos', unilateral: true }),
          p('pogo-jump', { reps: '15 contactos' }),
        ],
        { focus: 'Antes de salir' },
      ),
      recoveryBlock(id, week + 2),
    ],
    note: () =>
      'Diez minutos de preparación antes de salir cambian por completo la primera hora de actividad. Hidratá y comé algo sólido si la jornada supera las dos horas.',
  },
  // ── DOMINGO ──
  {
    name: 'Recovery',
    subtitle: 'Movilidad · Tejido · Down regulation',
    objective:
      'Acelerar la recuperación con trabajo de baja intensidad y bajar el sistema nervioso antes de arrancar la semana.',
    duration: '35 min',
    rpe: '2–3',
    next: 'gym',
    modules: [],
    build: (id, week) => [
      resetBlock(id, week + 1),
      movementBlock(id, week + 3),
      engineBlock(id, 'zone2'),
      recoveryBlock(id, week),
    ],
    note: () =>
      'Día de recuperación real. Si te levantás cansado, quedate con la movilidad y la respiración: la caminata es opcional.',
  },
];

export const WEEK_STRUCTURE = DAYS.map((d) => ({ name: d.name, subtitle: d.subtitle }));

const buildWorkout = (week: number, dayIndex: number, date: string): Workout => {
  const plan = DAYS[dayIndex];
  const phase = phaseFor(week);
  const id = `w${week}d${dayIndex + 1}`;
  const blocks = plan.build(id, week);
  const modules = Array.from(
    new Set(blocks.map((b) => b.module).filter((m): m is SportModule => !!m)),
  );

  return {
    id,
    week,
    day: dayIndex + 1,
    date,
    name: plan.name,
    subtitle: plan.subtitle,
    objective: plan.objective,
    duration: plan.duration,
    plannedRpe: isDeload(week) ? '6' : plan.rpe,
    coachNote: plan.note(week),
    nextDayActivity: plan.next,
    blocks,
    adaptations: [],
    status: plan.external ? 'external' : 'pending',
    externalActivity: plan.external,
    phase: phase.id,
    modules: modules.length ? modules : plan.modules,
  };
};

export const buildProgram = (start: string = PROGRAM_START): Workout[] => {
  const out: Workout[] = [];
  for (let w = 1; w <= TOTAL_WEEKS; w += 1) {
    for (let d = 0; d < DAYS.length; d += 1) {
      const offset = (w - 1) * 7 + d;
      out.push(buildWorkout(w, d, addDays(start, offset)));
    }
  }
  return out;
};

export { phaseFor, weekInPhase, isDeload } from './phases';
export { PHASES } from './phases';
