import type { PrimaryCapability, SportActivity, SportModule, Workout, WorkoutBlock } from '../types';
import { addDays, todayISO } from '../lib/date';
import type { Station } from './equipment';
import { STATION_LABEL } from './equipment';
import { getExercise } from './exercises';
import {
  CORE_FRI, CORE_MON, CORE_WED, HYBRIDS, MOBILITY_CLOSE, RUN_SESSIONS,
  SATURDAY_COOLDOWN, SATURDAY_WARMUP, SATURDAY_WODS, SPINNING, SUNDAY,
  loadFor, schemeFor, vuelta,
} from './month';
import type { BlockSpec } from './month';

/** Un bloque de cuatro semanas. */
export const TOTAL_WEEKS = 4;
export const defaultStart = (): string => todayISO();

export const ACTIVITY_LABEL: Record<SportActivity, string> = {
  surf: 'Surf', golf: 'Golf', ski: 'Esquí', running: 'Running',
  rest: 'Descanso', gym: 'Gimnasio', home: 'Entrenamiento en casa',
};

export const BLOCK_LABEL: Record<WorkoutBlock['kind'], string> = {
  'zona-media': 'Core', fuerza: 'Fuerza', atleta: 'Atleta',
  finisher: 'Híbrido', outdoor: 'Cardio', recovery: 'Recuperación',
  transicion: 'Vuelta a la manzana',
};

let transitionSeq = 0;
const mk = (id: string, spec: BlockSpec): WorkoutBlock => {
  // Las transiciones no llevan número de bloque: se numeran aparte para tener id único.
  const suffix = spec.kind === 'transicion' ? `t${(transitionSeq += 1)}` : `b${spec.index}`;
  return { id: `${id}-${suffix}`, duration: `${spec.minutes} min`, ...spec };
};

/**
 * Bloque de fuerza: un principal cargado + tres complementos que NO tocan la
 * barra. El esquema y la carga salen de la semana; la carga se redondea a lo
 * que los discos reales permiten.
 */
const strength = (
  id: string,
  week: number,
  index: number,
  title: string,
  main: { id: string; base: number; unilateral?: boolean; loadLabel?: (kg: number) => string },
  rest: { id: string; sets?: number; reps?: string; duration?: string; unilateral?: boolean; load?: string }[],
  minutes = 15,
): WorkoutBlock => {
  const sch = schemeFor(week);
  const kg = loadFor(main.base, week);
  return mk(id, {
    kind: 'fuerza', index, title, minutes,
    format: 'sets',
    formatLabel: `${sch.sets}×${sch.reps}${sch.tempo ? ` · tempo ${sch.tempo}` : ''}`,
    focus: `Semana ${sch.week} · ${sch.name}`,
    rest: '2 min entre series del principal',
    items: [
      {
        exerciseId: main.id, order: 'A', sets: sch.sets, reps: sch.reps, rpe: sch.rpe,
        rest: '2 min', unilateral: main.unilateral,
        load: main.loadLabel ? main.loadLabel(kg) : `${kg} kg`,
        instructions: sch.tempo
          ? `Tempo ${sch.tempo}: bajás en 3 s, pausa de 1 s, subís normal.`
          : 'Rampa de repeticiones: sube la carga si el esquema lo permite.',
      },
      ...rest.map((r, n) => ({
        exerciseId: r.id, order: `B${n + 1}`, sets: r.sets ?? sch.sets,
        reps: r.reps, duration: r.duration, unilateral: r.unilateral, load: r.load,
        instructions: 'Entre series del principal: no se toca la barra.',
      })),
    ],
  });
};

interface DayPlan {
  name: string;
  tagline: string;
  objective: string;
  rpe: string;
  station: Station;
  capability: PrimaryCapability;
  transfersTo: SportModule[];
  next: SportActivity | null;
  build: (id: string, week: number) => WorkoutBlock[];
  note: (week: number) => string;
}

const DAYS: DayPlan[] = [
  // ─────────── LUNES ───────────
  {
    name: 'Rodilla + Tracción',
    tagline: 'Full Body A',
    objective: 'Sentadilla como patrón pesado, tracción en el bloque Atleta y un híbrido sin barra para cerrar.',
    rpe: '8', station: 'barra', capability: 'Strength',
    transfersTo: ['ski'], next: 'gym',
    build: (id, week) => [
      mk(id, CORE_MON),
      strength(id, week, 2, 'Fuerza · Sentadilla',
        { id: 'box-squat', base: 60 },
        [
          { id: 'wall-sit', duration: '30 s' },
          { id: 'pogo-jump', reps: '10', load: 'Asistido con banda' },
          { id: 'hip-flexor-stretch', duration: '5 s', unilateral: true, load: 'Psoas dinámico' },
        ],
      ),
      mk(id, vuelta('fuerte', 'Mantener pulsaciones elevadas antes del bloque Atleta.')),
      mk(id, {
        kind: 'atleta', index: 3, title: 'Atleta · Tracción', minutes: 12,
        format: 'sets', formatLabel: '3 series por ejercicio',
        focus: 'Tren superior: tirón y lanzamiento',
        rest: '90 s',
        items: [
          { exerciseId: 'pull-up', sets: 3, reps: '8' },
          { exerciseId: 'trx-row', sets: 3, reps: '12' },
          { exerciseId: 'kneeling-oh-throw', sets: 3, reps: '6', load: 'Balón 5 kg' },
        ],
      }),
      mk(id, vuelta('sostenido', 'Llegar al híbrido con el pulso alto, no en frío.')),
      mk(id, HYBRIDS[1][(week - 1) % 4]),
    ],
    note: (week) => schemeFor(week).note,
  },
  // ─────────── MARTES ───────────
  {
    name: 'Spinning',
    tagline: 'Motor sin impacto',
    objective:
      'Motor sin impacto. La bici suma acondicionamiento sin castigar las piernas para el miércoles, y en la semana 3 agrega resistencia específica de cuádriceps para esquí.',
    rpe: '6', station: 'bici', capability: 'Engine',
    transfersTo: ['ski'], next: 'gym',
    build: (id, week) => [mk(id, SPINNING[(week - 1) % 4]), mk(id, { ...MOBILITY_CLOSE, index: 2 })],
    note: () => 'Fuerte significa que podés decir frases cortas, no charlar. Si podés charlar, subí resistencia.',
  },
  // ─────────── MIÉRCOLES ───────────
  {
    name: 'Cadera + Empuje',
    tagline: 'Full Body B',
    objective: 'Peso muerto como patrón pesado y press banca en el Atleta, con su trío de contraste.',
    rpe: '8', station: 'barra', capability: 'Strength',
    transfersTo: ['running'], next: 'running',
    build: (id, week) => [
      mk(id, CORE_WED),
      strength(id, week, 2, 'Fuerza · Bisagra',
        { id: 'deadlift', base: 70 },
        [
          { id: 'hip-bridge-iso-1p', duration: '5 s', unilateral: true },
          { id: 'kb-swing', reps: '12', load: 'KB 20 kg' },
          { id: 'hip-9090', reps: '6', load: '90/90 + Shin Box' },
        ],
      ),
      mk(id, vuelta('fuerte', 'Mantener pulsaciones elevadas antes del bloque Atleta.')),
      (() => {
        const sch = schemeFor(week);
        const kg = loadFor(50, week);
        return mk(id, {
          kind: 'atleta', index: 3, title: 'Atleta · Empuje', minutes: 12,
          format: 'sets', formatLabel: `${sch.sets}×${sch.reps} + contraste`,
          focus: 'Pesado → isométrico → balístico',
          rest: '2 min',
          items: [
            { exerciseId: 'bench-press', sets: sch.sets, reps: sch.reps, rpe: sch.rpe, load: `${kg} kg`,
              instructions: sch.tempo ? `Tempo ${sch.tempo}.` : undefined },
            { exerciseId: 'bench-iso-push', sets: sch.sets, duration: '5 s', instructions: 'Máxima intención contra los pines.' },
            { exerciseId: 'supine-mb-throw', sets: sch.sets, reps: '6', load: 'Balón 5 kg' },
          ],
        });
      })(),
      mk(id, vuelta('sostenido', 'Llegar al híbrido con el pulso alto, no en frío.')),
      mk(id, HYBRIDS[3][(week - 1) % 4]),
    ],
    note: (week) =>
      week === 3
        ? 'Peso muerto a 80 kg. Si se siente liviano subí a 90, pero ahí tocaste el techo de los discos: de ahí en adelante se progresa con déficit o tempo.'
        : schemeFor(week).note,
  },
  // ─────────── JUEVES ───────────
  {
    name: 'Pasadas',
    tagline: 'Velocidad y mecánica',
    objective: 'Correr rápido en distancias cortas. Es calidad, no volumen: si perdés velocidad, se corta.',
    rpe: '8', station: 'outdoor', capability: 'Engine',
    transfersTo: ['running'], next: 'gym',
    build: (id, week) => [
      ...RUN_SESSIONS[(week - 1) % 4].map((b) => mk(id, b)),
      mk(id, MOBILITY_CLOSE),
    ],
    note: (week) =>
      week === 3
        ? 'Volumen reducido a propósito: venís del lunes pesado y las piernas están cargadas.'
        : 'Si en las 100 empezás a perder velocidad, cortá la serie y guardá para las 200. El jueves es calidad.',
  },
  // ─────────── VIERNES ───────────
  {
    name: 'Unipodal + Mixto',
    tagline: 'Full Body C',
    objective: 'Trabajo unipodal cargado y tren superior mixto. Cierra la semana de fuerza.',
    rpe: '8', station: 'kettlebell', capability: 'Athletic',
    transfersTo: ['ski', 'surf'], next: 'rest',
    build: (id, week) => [
      mk(id, CORE_FRI),
      strength(id, week, 2, 'Fuerza · Unipodal',
        { id: 'bulgarian-split-squat', base: 20, unilateral: true, loadLabel: () => 'KB 20 kg en goblet' },
        [
          { id: 'split-squat-hold', duration: '20 s', unilateral: true },
          { id: 'skater-jump', duration: '20 s' },
          { id: 'cossack-squat', reps: '6', unilateral: true },
        ],
      ),
      mk(id, vuelta('fuerte', 'Mantener pulsaciones elevadas antes del bloque Atleta.')),
      mk(id, {
        kind: 'atleta', index: 3, title: 'Atleta · Mixto', minutes: 12,
        format: 'sets', formatLabel: '3 series por ejercicio',
        focus: 'Empuje vertical y tracción unilateral',
        rest: '90 s',
        items: [
          { exerciseId: 'kb-shoulder-press', sets: 3, reps: '8', unilateral: true, load: 'KB 20 kg' },
          { exerciseId: 'horizontal-pull-alt', sets: 3, reps: '8', unilateral: true },
          { exerciseId: 'trx-power-pull', sets: 3, reps: '6', unilateral: true },
        ],
      }),
      mk(id, HYBRIDS[5][(week - 1) % 4]),
    ],
    note: (week) =>
      week === 4
        ? 'Sin híbrido: cerrás con movilidad. Mañana es el test del mes y querés llegar entero.'
        : 'Mañana es el día duro. Dejá algo en el tanque.',
  },
  // ─────────── SÁBADO ───────────
  {
    name: 'Competencia',
    tagline: 'Hyrox / WOD largo',
    objective: 'El día más demandante. Score medible: es la marca contra la que vas a comparar el mes que viene.',
    rpe: '9', station: 'kettlebell', capability: 'Engine',
    transfersTo: ['running'], next: 'rest',
    build: (id, week) => [
      mk(id, SATURDAY_WARMUP),
      mk(id, SATURDAY_WODS[(week - 1) % 4]),
      mk(id, SATURDAY_COOLDOWN),
    ],
    note: (week) =>
      week === 4
        ? 'TEST DEL MES. Este formato se repite igual todos los meses: mismas distancias, mismas estaciones, mismas cargas. Anotá el tiempo.'
        : 'Salí más lento de lo que querés en el primer tramo de carrera. La distribución que falla es empezar fuerte y terminar caminando.',
  },
  // ─────────── DOMINGO ───────────
  {
    name: 'Descanso',
    tagline: 'Recuperación',
    objective: 'Día libre. Es donde se consolida lo que entrenaste.',
    rpe: '1–2', station: 'suelo', capability: 'Recovery',
    transfersTo: [], next: 'gym',
    build: (id) => [mk(id, SUNDAY)],
    note: () => 'Descanso de verdad. Seis días de trabajo necesitan uno sin nada.',
  },
];

export const WEEK_STRUCTURE = DAYS.map((d) => ({ name: d.name, tagline: d.tagline, station: STATION_LABEL[d.station] }));

export const equipmentFor = (blocks: WorkoutBlock[]): string[] => {
  const set = new Set<string>();
  blocks.forEach((b) => b.items.forEach((it) => getExercise(it.exerciseId).equipment.forEach((e) => set.add(e))));
  set.delete('Peso corporal');
  set.delete('Colchoneta');
  return [...set].sort();
};

export const totalMinutes = (blocks: WorkoutBlock[]): number => blocks.reduce((s, b) => s + b.minutes, 0);

const buildWorkout = (week: number, dayIndex: number, date: string): Workout => {
  const plan = DAYS[dayIndex];
  const id = `w${week}d${dayIndex + 1}`;
  transitionSeq = 0;
  const blocks = plan.build(id, week);
  return {
    id, week, day: dayIndex + 1, date,
    name: plan.name,
    subtitle: plan.tagline,
    objective: plan.objective,
    duration: `${totalMinutes(blocks)} min`,
    plannedRpe: schemeFor(week).week === 4 && plan.capability !== 'Engine' ? '6' : plan.rpe,
    coachNote: plan.note(week),
    nextDayActivity: plan.next,
    blocks,
    adaptations: [],
    status: 'pending',
    phase: 1,
    modules: plan.transfersTo,
    station: plan.station,
    capability: plan.capability,
    equipment: equipmentFor(blocks),
    transfersTo: plan.transfersTo,
  };
};

export const buildProgram = (start: string = defaultStart()): Workout[] => {
  const out: Workout[] = [];
  for (let w = 1; w <= TOTAL_WEEKS; w += 1) {
    for (let d = 0; d < DAYS.length; d += 1) {
      out.push(buildWorkout(w, d, addDays(start, (w - 1) * 7 + d)));
    }
  }
  return out;
};

export { STATION_LABEL } from './equipment';
export { schemeFor, loadFor, SCHEMES } from './month';
