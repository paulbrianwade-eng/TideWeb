import { useState } from 'react';
import { ArrowLeft, Check, LayoutList, Rows3, Timer } from 'lucide-react';
import { useApp } from '../state/AppContext';
import type { CompletedSet, Workout, WorkoutBlock } from '../types';
import { getExercise, videoUrl } from '../data/exercises';
import { setKey, plannedSets, doneKeys, sessionProgress } from '../lib/prescription';
import { CollapsibleBlock, ExerciseRow, volumeText } from '../components/workout-parts2';
import { BlockTimer, RestTimer, needsTimer } from '../components/timers';
import { Thumb } from '../components/media';
import { BLOCK_META } from '../components/blockMeta';
import { ScoreInput } from '../components/ScoreInput';
import { TransitionCard } from '../components/TransitionCard';
import { WorkoutTimeline } from '../components/WorkoutTimeline';

type View = 'block' | 'exercise';

export const SessionScreen = ({
  workoutId,
  /** Sesión ya transformada por las reglas de adaptación. */
  workout: adapted,
  initialBlockIndex = 0,
  onExit,
  onFinish,
}: {
  workoutId: string;
  workout?: Workout;
  initialBlockIndex?: number;
  onExit: () => void;
  onFinish: () => void;
}) => {
  const app = useApp();
  const workout = adapted ?? app.workoutById(workoutId);
  const session = app.sessionFor(workoutId);
  const [blockIndex, setBlockIndex] = useState(initialBlockIndex);
  const [view, setView] = useState<View>('block');
  const [exIndex, setExIndex] = useState(0);
  const [timerBlock, setTimerBlock] = useState<WorkoutBlock | null>(null);
  const [rest, setRest] = useState<{ seconds: number; next?: string } | null>(null);
  const [showTimeline, setShowTimeline] = useState(false);

  if (!workout) return null;
  const block = workout.blocks[blockIndex];
  const done = doneKeys(session);
  const progress = sessionProgress(workout, session);

  const item = block.items[Math.min(exIndex, block.items.length - 1)];
  const ex = getExercise(item.exerciseId);
  const target = plannedSets(item, block);
  const key = setKey(block.id, exIndex);
  const sets = session?.sets[key] ?? [];

  const completeSet = (i: number, load: string, reps: string) => {
    app.recordSet(workoutId, key, i, { done: true, load, reps });
    const restSeconds = parseInt(block.rest ?? '', 10) || 60;
    if (i + 1 < target) {
      setRest({ seconds: restSeconds, next: `${ex.name} · serie ${i + 2}` });
    } else if (exIndex + 1 < block.items.length) {
      const nextEx = getExercise(block.items[exIndex + 1].exerciseId);
      setRest({ seconds: restSeconds, next: nextEx.name });
      setExIndex((n) => n + 1);
    }
  };

  const nextBlock = () => {
    if (blockIndex + 1 < workout.blocks.length) {
      setBlockIndex((n) => n + 1);
      setExIndex(0);
      setView('block');
    } else {
      onFinish();
    }
  };

  const meta = BLOCK_META[block.kind];

  return (
    <div className="min-h-screen bg-canvas pb-32">
      <header className="sticky top-0 z-20 border-b border-line bg-canvas/95 pt-[env(safe-area-inset-top)] backdrop-blur">
        <div className="flex items-center gap-3 px-4 py-3">
          <button type="button" onClick={onExit} aria-label="Salir del modo sesión" className="btn-quiet">
            <ArrowLeft className="h-5 w-5" aria-hidden="true" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="label">
              Bloque {block.index} de {workout.blocks.length}
            </p>
            <p className="truncate font-display text-lg uppercase">{workout.name}</p>
          </div>
          <button
            type="button"
            onClick={() => setView(view === 'block' ? 'exercise' : 'block')}
            aria-label={view === 'block' ? 'Ver ejercicio por ejercicio' : 'Ver el bloque completo'}
            className="btn-ghost px-3 py-2"
          >
            {view === 'block' ? <Rows3 className="h-4 w-4" aria-hidden="true" /> : <LayoutList className="h-4 w-4" aria-hidden="true" />}
          </button>
        </div>
        <div className="h-1 w-full bg-line">
          <div className="h-full bg-brand transition-all" style={{ width: `${progress * 100}%` }} />
        </div>
      </header>

      <div className="mx-auto max-w-2xl space-y-4 px-4 pt-4">
        {workout.adaptations.length > 0 && (
          <p className="rounded-xl border border-brand/30 bg-lime-soft px-3 py-2 text-xs text-brand-dark">
            Sesión adaptada: {workout.adaptations.join(' · ')}
          </p>
        )}

        <button
          type="button"
          onClick={() => setShowTimeline((v) => !v)}
          aria-expanded={showTimeline}
          className="btn-ghost w-full"
        >
          {showTimeline ? 'Ocultar recorrido' : 'Ver dónde estoy'}
        </button>
        {showTimeline && (
          <div className="card animate-rise-in p-4">
            <WorkoutTimeline
              workout={workout}
              currentIndex={blockIndex}
              doneIndexes={workout.blocks.map((_, i) => i).filter((i) => i < blockIndex)}
              onJump={(i) => {
                setBlockIndex(i);
                setExIndex(0);
                setShowTimeline(false);
              }}
            />
          </div>
        )}

        {/* Selector de bloque */}
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {workout.blocks.map((b, i) => (
            <button
              key={b.id}
              type="button"
              onClick={() => {
                setBlockIndex(i);
                setExIndex(0);
              }}
              className={`shrink-0 rounded-full px-3 py-1.5 text-[11px] font-semibold uppercase tracking-[0.08em] transition-colors duration-200 ${
                i === blockIndex
                  ? 'bg-brand text-white'
                  : b.kind === 'transicion'
                    ? 'border border-brand/30 bg-lime-soft text-brand'
                    : 'border border-line bg-surface text-muted'
              }`}
            >
              {b.kind === 'transicion' ? '↗ Vuelta' : `${b.index}. ${b.title}`}
            </button>
          ))}
        </div>

        {block.kind === 'transicion' ? (
          <TransitionCard
            block={block}
            result={session?.transitions?.[block.id]}
            onComplete={(r) => app.recordTransition(workoutId, { ...r, blockId: block.id, completedAt: Date.now() })}
          />
        ) : view === 'block' ? (
          <CollapsibleBlock
            block={block}
            defaultOpen
            doneIds={done}
            onOpenExercise={(i) => {
              setExIndex(i);
              setView('exercise');
            }}
            onTimer={() => setTimerBlock(block)}
          />
        ) : (
          <section className="card overflow-hidden">
            <div className={`px-4 py-3 ${meta.head} ${meta.text}`}>
              <p className="text-[11px] font-semibold uppercase tracking-[0.12em] opacity-80">
                Bloque {block.index} · {block.formatLabel}
              </p>
              <p className="font-display text-xl uppercase">{block.title}</p>
            </div>

            <div className="p-4">
              <Thumb exerciseId={ex.id} kind={block.kind} className="h-44 w-full rounded-xl" />
              <p className="label mt-4">
                Ejercicio {exIndex + 1} de {block.items.length}
              </p>
              <h2 className="mt-1 text-3xl">{ex.name}</h2>
              <p className="mt-2 font-mono text-lg text-brand">{volumeText(item)}</p>
              {item.rpe && <p className="label mt-1">RPE {item.rpe}</p>}
              {item.load && <p className="meta mt-1">{item.load}</p>}

              <div className="mt-4 space-y-2">
                {Array.from({ length: target }, (_, i) => (
                  <SetRow
                    key={i}
                    index={i}
                    entry={sets[i]}
                    onComplete={(load, reps) => completeSet(i, load, reps)}
                  />
                ))}
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2">
                <a href={videoUrl(ex)} target="_blank" rel="noreferrer" className="btn-ghost">
                  Ver técnica
                </a>
                <button
                  type="button"
                  onClick={() => setRest({ seconds: 60, next: ex.name })}
                  className="btn-ghost"
                >
                  <Timer className="h-4 w-4" aria-hidden="true" /> Descanso
                </button>
              </div>

              <details className="mt-4 rounded-xl border border-line p-3">
                <summary className="label cursor-pointer">Técnica y errores</summary>
                <ul className="mt-2 space-y-1 text-sm text-muted">
                  {ex.cues.map((c) => (
                    <li key={c}>· {c}</li>
                  ))}
                </ul>
                <p className="label mt-3">Errores frecuentes</p>
                <ul className="mt-1 space-y-1 text-sm text-muted">
                  {ex.mistakes.map((m) => (
                    <li key={m}>· {m}</li>
                  ))}
                </ul>
                <p className="mt-3 text-sm text-muted">
                  <span className="label">Regresión</span> {ex.regression}
                </p>
                <p className="mt-1 text-sm text-muted">
                  <span className="label">Progresión</span> {ex.progression}
                </p>
              </details>

              <div className="mt-4 flex gap-2">
                <button
                  type="button"
                  disabled={exIndex === 0}
                  onClick={() => setExIndex((n) => Math.max(0, n - 1))}
                  className="btn-ghost flex-1"
                >
                  Anterior
                </button>
                <button
                  type="button"
                  disabled={exIndex + 1 >= block.items.length}
                  onClick={() => setExIndex((n) => n + 1)}
                  className="btn-ghost flex-1"
                >
                  Siguiente
                </button>
              </div>
            </div>
          </section>
        )}

        {/* Score del finisher */}
        {block.kind === 'finisher' && block.scoreType && (
          <ScoreInput
            block={block}
            value={session?.finisherScore}
            onChange={(score) => app.setFinisherScore(workoutId, score)}
          />
        )}

        {block.kind !== 'transicion' && needsTimer(block) && view === 'block' && (
          <button
            type="button"
            onClick={() => setTimerBlock(block)}
            aria-label={`Abrir temporizador: ${block.formatLabel}`}
            className="btn-lime w-full"
          >
            <Timer className="h-5 w-5" aria-hidden="true" /> {block.formatLabel}
          </button>
        )}

        <button type="button" onClick={nextBlock} className="btn-primary w-full">
          <Check className="h-5 w-5" aria-hidden="true" />
          {blockIndex + 1 < workout.blocks.length
            ? block.kind === 'transicion'
              ? 'Vuelta completa'
              : 'Bloque completo'
            : 'Finalizar sesión'}
        </button>
      </div>

      {timerBlock && <BlockTimer block={timerBlock} onClose={() => setTimerBlock(null)} />}
      {rest && <RestTimer seconds={rest.seconds} nextLabel={rest.next} onClose={() => setRest(null)} />}
    </div>
  );
};

/** Fila de registro: carga, repeticiones y confirmación. */
const SetRow = ({
  index,
  entry,
  onComplete,
}: {
  index: number;
  entry?: CompletedSet;
  onComplete: (load: string, reps: string) => void;
}) => {
  const [load, setLoad] = useState(entry?.load ?? '');
  const [reps, setReps] = useState(entry?.reps ?? '');
  const done = entry?.done;

  return (
    <div
      className={`flex items-center gap-2 rounded-xl border px-3 py-2 ${
        done ? 'border-brand bg-lime-soft' : 'border-line bg-surface'
      }`}
    >
      <span className="label w-12 shrink-0">Serie {index + 1}</span>
      <input
        aria-label={`Carga de la serie ${index + 1}`}
        inputMode="decimal"
        value={load}
        onChange={(e) => setLoad(e.target.value)}
        placeholder="kg"
        className="field flex-1 py-2"
      />
      <input
        aria-label={`Repeticiones de la serie ${index + 1}`}
        inputMode="numeric"
        value={reps}
        onChange={(e) => setReps(e.target.value)}
        placeholder="reps"
        className="field flex-1 py-2"
      />
      <button
        type="button"
        onClick={() => onComplete(load, reps)}
        aria-label={`Completar serie ${index + 1}`}
        className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${
          done ? 'bg-brand text-white' : 'border border-line text-muted'
        }`}
      >
        <Check className="h-4 w-4" aria-hidden="true" />
      </button>
    </div>
  );
};

export { ExerciseRow };
