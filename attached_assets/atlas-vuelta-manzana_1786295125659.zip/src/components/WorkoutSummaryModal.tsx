import { useState } from 'react';
import { Check } from 'lucide-react';
import { useApp } from '../state/AppContext';
import type { SessionSummary } from '../types';
import { completedSets } from '../lib/prescription';
import { formatClock } from '../lib/timers';
import type { BlockKind } from '../types';
import { ScaleSelector, Stat } from './ui';

/** Resumen de cierre: duración, score, sensaciones y feedback automático. */
export const WorkoutSummaryModal = ({
  workoutId,
  onClose,
}: {
  workoutId: string;
  onClose: () => void;
}) => {
  const app = useApp();
  const workout = app.workoutById(workoutId);
  const session = app.sessionFor(workoutId);
  const [rpe, setRpe] = useState<number | null>(null);
  const [energy, setEnergy] = useState<number | null>(null);
  const [pain, setPain] = useState<number | null>(null);
  const [comment, setComment] = useState('');
  const [calories, setCalories] = useState('');
  const [avgHr, setAvgHr] = useState('');
  const [maxHr, setMaxHr] = useState('');

  if (!workout) return null;

  const sets = completedSets(session);

  /**
   * DESGLOSE DE TIEMPOS
   * El cardio no vive solo en el finisher: aparece como vuelta a la manzana,
   * dentro del Atleta, como sprint, shuttle, bici o running. Se suma todo.
   */
  const transitions = Object.values(session?.transitions ?? {});
  const transitionSec = transitions.reduce((s, t) => s + t.seconds, 0);
  const bestTransition = transitions.length ? Math.min(...transitions.map((t) => t.seconds)) : undefined;

  const timeByBlock = workout.blocks.reduce<Partial<Record<BlockKind, number>>>((acc, b) => {
    const secs = b.kind === 'transicion'
      ? (session?.transitions?.[b.id]?.seconds ?? 0)
      : b.minutes * 60;
    acc[b.kind] = (acc[b.kind] ?? 0) + secs;
    return acc;
  }, {});

  // Cardio total = transiciones + híbrido + todo bloque de motor
  const cardioSec = transitionSec + (timeByBlock.finisher ?? 0) + (timeByBlock.outdoor ?? 0);
  const durationMin = session ? Math.max(1, Math.round((Date.now() - session.startedAt) / 60000)) : workout.blocks.reduce((s, b) => s + b.minutes, 0);
  const score = session?.finisherScore;
  const finisher = workout.blocks.find((b) => b.kind === 'finisher');

  /** Feedback automático: se calcula del RPE declarado contra el planificado. */
  const coachFeedback = (): string => {
    if (rpe === null) return 'Cargá el RPE para recibir la lectura del día.';
    const planned = parseInt(workout.plannedRpe, 10) || 7;
    if (rpe >= planned + 2) return 'Te fuiste bastante por encima de lo planificado. Si se repite, revisá el descanso entre series antes de subir carga.';
    if (rpe <= planned - 2) return 'Quedó corto respecto de lo planificado: la próxima podés subir carga o sumar una vuelta al bloque Atleta.';
    if (pain !== null && pain >= 5) return 'El dolor está alto. Mañana priorizá movilidad y bajá el volumen de piernas.';
    const hr = Number(avgHr);
    if (hr && rpe && hr < 120 && rpe >= 8)
      return 'La frecuencia media quedó baja para el RPE que declaraste: probablemente los descansos se estiraron. Cronometralos la próxima.';
    if (hr && hr > 165)
      return 'Frecuencia media muy alta: la sesión se fue a metabólico. Si buscabas fuerza, alargá el descanso entre series del principal.';
    return 'Sesión en el rango planificado. Repetí esta carga la semana que viene y sumá desde ahí.';
  };

  const save = () => {
    const summary: SessionSummary = {
      workoutId,
      workoutName: workout.name,
      date: workout.date,
      durationMin,
      blocksCompleted: workout.blocks.length,
      blocksTotal: workout.blocks.length,
      volumeKg: 0,
      setsCompleted: sets,
      finisherScore: score,
      timeByBlock,
      transitionsDone: transitions.length,
      bestTransitionSec: bestTransition,
      cardioSeconds: cardioSec,
      calories: calories ? Number(calories) : undefined,
      avgHr: avgHr ? Number(avgHr) : undefined,
      maxHr: maxHr ? Number(maxHr) : undefined,
      rpe: rpe ?? 0,
      energy: energy ?? 0,
      pain: pain ?? 0,
      feeling: null,
      comment,
      highlight: null,
      personalRecord: null,
      coachNote: coachFeedback(),
    };
    app.saveSummary(summary);
    onClose();
  };

  return (
    <div className="min-h-screen bg-canvas pb-24">
      <div className="mx-auto max-w-2xl space-y-5 px-5 pb-8 pt-[calc(env(safe-area-inset-top)+1.5rem)]">
        <header>
          <p className="label text-brand">Sesión completa</p>
          <h1 className="mt-1 text-3xl">{workout.name}</h1>
        </header>

        <div className="grid grid-cols-3 gap-3">
          <Stat label="Total" value={`${durationMin}′`} />
          <Stat label="Bloques" value={`${workout.blocks.filter((b) => b.kind !== 'transicion').length}`} />
          <Stat label="Series" value={`${sets}`} />
        </div>

        {/* Desglose por bloque */}
        <section className="card p-4">
          <p className="label-brand label">Desglose</p>
          <dl className="mt-2 space-y-1.5 text-sm">
            {[
              ['Zona media', timeByBlock['zona-media']],
              ['Fuerza', timeByBlock.fuerza],
              ['Atleta', timeByBlock.atleta],
              ['Finisher', timeByBlock.finisher],
            ]
              .filter(([, v]) => !!v)
              .map(([label, v]) => (
                <div key={label as string} className="flex justify-between">
                  <dt className="text-muted">{label}</dt>
                  <dd className="font-mono text-ink">{formatClock(v as number)}</dd>
                </div>
              ))}
            <div className="flex justify-between border-t border-line pt-1.5">
              <dt className="font-semibold text-brand">Cardio total</dt>
              <dd className="font-mono font-semibold text-brand">{formatClock(cardioSec)}</dd>
            </div>
          </dl>
        </section>

        {/* Vueltas a la manzana */}
        {transitions.length > 0 && (
          <section className="rounded-2xl border border-brand/25 bg-lime-soft p-4">
            <p className="label text-brand">Vueltas a la manzana</p>
            <div className="mt-2 flex items-baseline gap-4">
              <span className="figure text-4xl text-ink">{transitions.length}</span>
              {bestTransition !== undefined && (
                <span className="text-sm text-muted">
                  Mejor vuelta <strong className="font-mono text-ink">{formatClock(bestTransition)}</strong>
                </span>
              )}
            </div>
            <ul className="mt-2 space-y-1 text-sm">
              {transitions.map((t, i) => (
                <li key={t.blockId} className="flex justify-between text-muted">
                  <span>Vuelta {i + 1}</span>
                  <span className="font-mono text-ink">
                    {formatClock(t.seconds)}
                    {t.rpe ? ` · RPE ${t.rpe}` : ''}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        )}

        {finisher && score && (
          <section className="card p-4">
            <p className="label">Score del finisher</p>
            <p className="figure mt-1 text-3xl">
              {score.rounds ? `${score.rounds} + ${score.reps ?? 0}` : score.time ?? score.reps ?? score.distance ?? '—'}
            </p>
            <p className="meta mt-1">{finisher.formatLabel}</p>
          </section>
        )}

        {/* Datos del reloj */}
        <section className="card p-4">
          <p className="label-brand label">Del reloj</p>
          <p className="mt-0.5 text-sm text-muted">Opcional: si no lo tenés, dejalo vacío.</p>
          <div className="mt-3 grid grid-cols-3 gap-2">
            <label className="block">
              <span className="label">Calorías</span>
              <input
                inputMode="numeric"
                value={calories}
                onChange={(e) => setCalories(e.target.value)}
                placeholder="480"
                className="field mt-1"
              />
            </label>
            <label className="block">
              <span className="label">FC media</span>
              <input
                inputMode="numeric"
                value={avgHr}
                onChange={(e) => setAvgHr(e.target.value)}
                placeholder="142"
                className="field mt-1"
              />
            </label>
            <label className="block">
              <span className="label">FC máx</span>
              <input
                inputMode="numeric"
                value={maxHr}
                onChange={(e) => setMaxHr(e.target.value)}
                placeholder="176"
                className="field mt-1"
              />
            </label>
          </div>
        </section>

        <section className="card space-y-5 p-4">
          <ScaleSelector label="RPE final" value={rpe} onChange={setRpe} />
          <ScaleSelector label="Energía" value={energy} onChange={setEnergy} />
          <ScaleSelector label="Dolor" value={pain} onChange={setPain} min={0} hint="0 = sin molestias" />
          <label className="block">
            <span className="label">Comentario</span>
            <input
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Cómo se sintió la sesión"
              className="field mt-1"
            />
          </label>
        </section>

        <section className="rounded-2xl border-l-4 border-brand bg-lime-soft px-4 py-3">
          <p className="label text-brand-dark">Coach feedback</p>
          <p className="mt-1 text-sm leading-relaxed">{coachFeedback()}</p>
        </section>

        <button type="button" onClick={save} className="btn-primary w-full">
          <Check className="h-5 w-5" aria-hidden="true" /> Guardar y salir
        </button>
      </div>
    </div>
  );
};
