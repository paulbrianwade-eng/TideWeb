import type { AppState } from '../types';
import { DEFAULT_PROFILE } from '../data/defaults';

export const STORAGE_KEY = 'tide.state.v1';
export const STATE_VERSION = 2;

export const emptyState = (): AppState => ({
  version: STATE_VERSION,
  profile: { ...DEFAULT_PROFILE },
  readiness: {},
  adjustments: {},
  sessions: {},
  history: [],
  calendarOverrides: {},
  metrics: {},
  nutrition: {},
  extras: {},
  lastScreen: 'today',
});

/**
 * MIGRACIÓN
 * ─────────
 * Cambiar la rutina o la lógica NUNCA borra lo que ya entrenaste.
 * Se conserva historial, sesiones, métricas, perfil y la fecha de inicio del
 * programa; se descarta solo lo que dejó de tener sentido con el modelo nuevo.
 */
const migrate = (parsed: Partial<AppState>): AppState => {
  const base = emptyState();
  return {
    ...base,
    ...parsed,
    version: STATE_VERSION,
    profile: { ...DEFAULT_PROFILE, ...parsed.profile },
    // Lo que se conserva sí o sí entre versiones:
    history: parsed.history ?? [],
    sessions: parsed.sessions ?? {},
    metrics: parsed.metrics ?? {},
    readiness: parsed.readiness ?? {},
    calendarOverrides: parsed.calendarOverrides ?? {},
    programStart: parsed.programStart,
  };
};

export const loadState = (): AppState => {
  if (typeof window === 'undefined') return emptyState();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyState();
    const parsed = JSON.parse(raw) as Partial<AppState>;
    // Versión distinta: migramos en vez de borrar.
    return migrate(parsed);
  } catch {
    return emptyState();
  }
};

export const saveState = (state: AppState): void => {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* almacenamiento no disponible: la app sigue funcionando en memoria */
  }
};

export const clearState = (): void => {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* noop */
  }
};
