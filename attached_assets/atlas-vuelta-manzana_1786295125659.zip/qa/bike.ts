/** Audita la bici: que complemente y no reemplace, y que el impacto se mida bien. */
import { buildProgram } from '../src/data/program';
import { EXERCISES, getExercise } from '../src/data/exercises';
import {
  BIKE_CANNOT_REPLACE, WEEKLY_IMPACT_CAP, canBikeReplace, impactOf,
  sessionImpact, shouldPreferBike, weekImpact,
} from '../src/data/impact';
import { applyAdaptations, emptyAnswers } from '../src/lib/adaptations';
import { analyzeSession } from '../src/lib/intelligence';
import { INVENTORY } from '../src/data/equipment';

let failed = 0;
const check = (name: string, ok: boolean, detail = '') => {
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failed += 1;
};

const prog = buildProgram('2026-01-05');

// ── La bici existe como equipamiento ──
check('La bicicleta está en el inventario', (INVENTORY as readonly string[]).includes('Bicicleta'));

const bikeEx = EXERCISES.filter((e) => e.equipment.includes('Bicicleta'));
check('Hay protocolos de bici para cada uso', bikeEx.length >= 5, `${bikeEx.length}: ${bikeEx.map((e) => e.name).join(', ')}`);
check('Cubre sprint, potencia, esquí, zona 2 y recuperación',
  ['bike-sprint', 'bike-power', 'bike-ski-legs', 'bike-zone2', 'bike-recovery'].every((id) => bikeEx.some((e) => e.id === id)));

// ── NO reemplaza lo que no debe ──
check('La bici no reemplaza sprints ni pliometría',
  BIKE_CANNOT_REPLACE.every((id) => !canBikeReplace(id)),
  `protegidos: ${BIKE_CANNOT_REPLACE.length}`);
check('Sí puede reemplazar burpees y motor genérico',
  canBikeReplace('burpee') && canBikeReplace('mountain-climber'));

// El jueves de pasadas nunca puede convertirse en bici
const thursday = prog.filter((w) => w.name === 'Pasadas');
check('El jueves sigue siendo carrera real, no bici',
  thursday.every((w) => !w.blocks.some((b) => b.items.some((i) => i.exerciseId.startsWith('bike')))),
  'sprints intactos');
check('El jueves conserva las pasadas',
  thursday.every((w) => w.blocks.some((b) => b.items.some((i) => i.exerciseId === 'sprint'))));

// ── El martes usa protocolos reales ──
const tuesday = prog.filter((w) => w.name === 'Spinning');
check('El martes es día de bici', tuesday.every((w) => w.station === 'bici'));
check('El martes usa protocolos específicos, no genéricos',
  tuesday.every((w) => w.blocks[0].items.every((i) => i.exerciseId.startsWith('bike'))),
  tuesday.map((w) => w.blocks[0].formatLabel).join(' · '));
check('La semana 3 incluye Ski Legs',
  tuesday[2].blocks[0].items.some((i) => i.exerciseId === 'bike-ski-legs'));

// ── Modelo de impacto ──
check('Correr y saltar suman impacto', impactOf('sprint') === 'alto' && impactOf('box-jump') === 'alto');
check('La bici no suma impacto', ['bike-sprint', 'bike-power', 'bike-zone2'].every((id) => impactOf(id) === 'nulo'));
check('El día de bici tiene impacto casi nulo', sessionImpact(tuesday[0]) <= 2, `${sessionImpact(tuesday[0])}`);

const loads = [1, 2, 3, 4].map((w) => weekImpact(prog, w));
check('El impacto baja hacia la descarga', loads[3] < loads[0], loads.join(' → '));
check('La semana 1 es la de mayor impacto', loads[0] === Math.max(...loads));

// ── Recomendación contextual ──
check('Tras esquiar recomienda la bici',
  !!shouldPreferBike(prog, 1, { recentSki: true }));
check('Con molestia en piernas recomienda la bici',
  !!shouldPreferBike(prog, 1, { painLegs: true }));
check('Con impacto alto lo advierte',
  !!shouldPreferBike(prog, 1), `S1 = ${loads[0]} sobre ${WEEKLY_IMPACT_CAP}`);
check('En la semana de descarga no insiste', shouldPreferBike(prog, 4) === null, `S4 = ${loads[3]}`);

// ── Adaptaciones ──
const monday = prog[0];
/**
 * La bici es una OPCIÓN de equipamiento, no un reemplazo automático.
 * Las adaptaciones la sugieren por texto pero nunca cambian la sesión sola.
 */
const knee = applyAdaptations(monday, { ...emptyAnswers, pain: 6, painArea: 'rodilla' });
check('Molestia de rodilla NO sustituye por bici automáticamente',
  !knee.blocks.some((b) => b.items.some((i) => i.exerciseId.startsWith('bike'))));
check('Pero sí la sugiere', knee.rules.some((r) => r.effect.toLowerCase().includes('bici')),
  knee.rules.map((r) => r.id).join(', '));

const ski = applyAdaptations(monday, { ...emptyAnswers, tomorrow: 'ski' });
check('Esquí mañana tampoco sustituye solo',
  !ski.blocks.some((b) => b.items.some((i) => i.exerciseId.startsWith('bike'))));
check('Y también lo sugiere', ski.rules.some((r) => r.effect.toLowerCase().includes('bici')));

// Pero la adaptación NO toca el jueves de pasadas
const runDay = applyAdaptations(thursday[0], { ...emptyAnswers, pain: 6, painArea: 'rodilla' });
check('La adaptación no convierte las pasadas en bici',
  runDay.blocks.some((b) => b.items.some((i) => i.exerciseId === 'sprint')));

// ── El motor lo reporta ──
const sat = prog.find((w) => w.name === 'Competencia')!;
check('El validador advierte el impacto alto del sábado',
  analyzeSession(sat).issues.some((i) => i.id === 'impact-high'),
  `${sessionImpact(sat)} puntos`);
check('No lo trata como error, solo advertencia',
  analyzeSession(sat).issues.filter((i) => i.id === 'impact-high').every((i) => i.severity === 'warning'));

console.log(`\nImpacto por semana: ${loads.join(' · ')} (techo ${WEEKLY_IMPACT_CAP})`);
console.log(`Sesión más dura: ${prog.reduce((a, b) => (sessionImpact(b) > sessionImpact(a) ? b : a)).name} — ${Math.max(...prog.map(sessionImpact))} puntos`);
console.log(`Protocolos de bici: ${bikeEx.map((e) => getExercise(e.id).name).join(' · ')}`);

if (failed) {
  console.error(`\n${failed} verificaciones fallaron`);
  process.exit(1);
}
