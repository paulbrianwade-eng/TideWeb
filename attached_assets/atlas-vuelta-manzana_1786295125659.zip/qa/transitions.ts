/** Verifica la vuelta a la manzana, el orden fijo y que nada se modifique solo. */
import { buildProgram } from '../src/data/program';
import { TRANSITION_INTENSITY } from '../src/types';
import { groupByLetter } from '../src/components/workout-parts2';
import { analyzeSession } from '../src/lib/intelligence';
import { applyAdaptations, emptyAnswers } from '../src/lib/adaptations';

let failed = 0;
const check = (name: string, ok: boolean, detail = '') => {
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failed += 1;
};

const prog = buildProgram('2026-01-05');
const monday = prog[0];
const fullBody = prog.filter((w) => w.blocks.some((b) => b.kind === 'transicion'));

// ── La vuelta existe como elemento propio ──
check('La vuelta es un tipo de bloque propio, no un ejercicio',
  monday.blocks.some((b) => b.kind === 'transicion' && b.items.length === 0));
check('Tiene intensidad declarada',
  monday.blocks.filter((b) => b.kind === 'transicion').every((b) => !!b.intensity));
check('Las tres intensidades están definidas',
  Object.keys(TRANSITION_INTENSITY).join(',') === 'suave,sostenido,fuerte');
check('Tiene objetivo en texto',
  monday.blocks.filter((b) => b.kind === 'transicion').every((b) => !!b.goal));
check('No impone distancia fija',
  monday.blocks.filter((b) => b.kind === 'transicion').every((b) => b.items.length === 0));

// ── Orden exacto ──
const order = monday.blocks.map((b) => (b.kind === 'transicion' ? '↗' : b.kind));
check('El orden es Core → Fuerza → ↗ → Atleta → ↗ → Finisher',
  order.join('|') === 'zona-media|fuerza|↗|atleta|↗|finisher', order.join(' → '));
check('Las transiciones no se mueven al final',
  monday.blocks[monday.blocks.length - 1].kind !== 'transicion');
// La rutina define 2 vueltas los lunes y miércoles, y 1 los viernes.
// El spec lo permite: "En otros días puede haber solo una vuelta."
const monWed = prog.filter((w) => ['Rodilla + Tracción', 'Cadera + Empuje'].includes(w.name));
const fri = prog.filter((w) => w.name === 'Unipodal + Mixto');
check('Lunes y miércoles llevan 2 vueltas',
  monWed.every((w) => w.blocks.filter((b) => b.kind === 'transicion').length === 2),
  `${monWed.length} días`);
check('El viernes lleva 1 vuelta',
  fri.every((w) => w.blocks.filter((b) => b.kind === 'transicion').length === 1));
check('Solo los días de fuerza tienen vueltas', fullBody.length === 12, `${fullBody.length} días`);
check('El martes y el sábado no llevan vueltas inventadas',
  !prog.find((w) => w.name === 'Spinning')!.blocks.some((b) => b.kind === 'transicion')
  && !prog.find((w) => w.name === 'Competencia')!.blocks.some((b) => b.kind === 'transicion'));

// ── Ids únicos ──
const ids = monday.blocks.map((b) => b.id);
check('Cada transición tiene id propio', new Set(ids).size === ids.length, ids.join(' · '));

// ── La rutina NO cambió ──
const strengthBlock = monday.blocks.find((b) => b.kind === 'fuerza')!;
check('El bloque de fuerza conserva sus 4 ejercicios', strengthBlock.items.length === 4);
check('Conserva la carga programada', strengthBlock.items[0].load === '60 kg', strengthBlock.items[0].load);
check('Conserva el esquema de series', strengthBlock.items[0].reps === '8,6,6', strengthBlock.items[0].reps);
check('El primer ejercicio sigue siendo el mismo', strengthBlock.items[0].exerciseId === 'box-squat');

// ── El validador reporta pero no toca nada ──
const before = JSON.stringify(monday.blocks);
analyzeSession(monday);
check('Analizar la sesión no la modifica', JSON.stringify(monday.blocks) === before);
const issues = analyzeSession(monday).issues;
check('El análisis sigue produciendo alertas', Array.isArray(issues));

// ── Las adaptaciones no cambian ejercicios por bici ──
const knee = applyAdaptations(monday, { ...emptyAnswers, pain: 6, painArea: 'rodilla' });
check('Molestia de rodilla no mete bici automáticamente',
  !knee.blocks.some((b) => b.items.some((i) => i.exerciseId.startsWith('bike'))),
  knee.rules.map((r) => r.id).join(', '));
check('Pero sí lo sugiere por texto',
  knee.rules.some((r) => r.effect.toLowerCase().includes('bici')));
const ski = applyAdaptations(monday, { ...emptyAnswers, tomorrow: 'ski' });
check('Esquí mañana tampoco sustituye por bici',
  !ski.blocks.some((b) => b.items.some((i) => i.exerciseId.startsWith('bike'))));

// ── A/B y superserie ──
const groups = groupByLetter(strengthBlock.items);
check('El principal queda solo en su grupo A',
  groups[0].letter === 'A' && groups[0].items.length === 1 && !groups[0].superset);
check('Los complementos B1/B2/B3 son superserie',
  groups[1].letter === 'B' && groups[1].superset && groups[1].items.length === 3);

const atleta = monday.blocks.find((b) => b.kind === 'atleta')!;
check('Un bloque sin letras no inventa agrupación',
  groupByLetter(atleta.items).every((g) => g.letter === ''));

console.log(`\nOrden del lunes: ${order.join(' → ')}`);
console.log(`Vueltas programadas: ${prog.reduce((n, w) => n + w.blocks.filter((b) => b.kind === 'transicion').length, 0)} en el mes`);

if (failed) {
  console.error(`\n${failed} verificaciones fallaron`);
  process.exit(1);
}
