# ACTUALIZACIÓN — VUELTA A LA MANZANA Y TIMELINE

Arrastrá el contenido sobre la raíz del Repl, aceptá sobrescribir, **Run**.
Tu historial se conserva.

---

## La rutina no se tocó

Verificado por `qa/transitions.ts`:

- El bloque de fuerza del lunes conserva sus **4 ejercicios**
- Box Squat sigue en **8,6,6 a 60 kg**
- El orden de los bloques es el mismo
- Ningún ejercicio fue sustituido

## Lo nuevo

### Vuelta a la manzana

Tipo de bloque propio (`transicion`), no un ejercicio. Tarjeta más simple, fondo verde muy
claro, ícono de running y flecha ↗.

Muestra ritmo, intensidad, objetivo, cronómetro libre y botón de completar. **Sin distancia
fija**: la rutina no la especifica, así que la app no la impone.

Tres intensidades: **Suave** (RPE 4–5) · **Sostenido** (RPE 6–7) · **Fuerte controlado** (RPE 7–8).

Al completar guarda tiempo, RPE y sensación. Va al historial y al resumen.

**Dónde aparecen** (20 vueltas en el mes):

| Día | Flujo |
|---|---|
| Lunes y miércoles | Core → Fuerza → **↗** → Atleta → **↗** → Híbrido |
| Viernes | Core → Fuerza → **↗** → Atleta → Híbrido |
| Martes, jueves, sábado, domingo | sin vueltas |

### Timeline vertical

Botón "Ver dónde estoy" en el modo sesión: lista vertical con completado / en curso /
pendiente, minutos por bloque, y las transiciones diferenciadas. Se puede saltar a cualquier
punto.

### Lógica A/B

`A` sola → *"Completar todas las series antes de continuar"*.
`B1 · B2 · B3` → *"Superserie · 3 ejercicios alternados"*.

La letra se muestra en un cuadrado negro y agrupa los ejercicios visualmente.

### Cardio total en el resumen

El cardio ya no se asume igual a finisher. El resumen desglosa:

```
Zona media   08:00
Fuerza       15:00
Atleta       12:00
Finisher     12:00
─────────────────
Cardio total 20:14
```

Más una tarjeta de **Vueltas a la manzana** con cantidad, tiempo de cada una, su RPE y la
mejor vuelta.

## Lo que se desactivó

Según los puntos 6 y 7:

- **El generador ya no autocorrige.** `autoFix()` sigue existiendo pero no lo llama nadie:
  el validador detecta duplicaciones, muestra alertas y análisis, y conserva la sesión original.
  El modo coach ahora dice explícitamente *"El análisis informa, no modifica"*.
- **La bici ya no reemplaza automáticamente.** Con molestia de rodilla o esquí al día
  siguiente, la app lo **sugiere por texto** pero no cambia un solo ejercicio.

## Verificación

```bash
npm run qa
```

**164 verificaciones.** `npm run build` sin errores.

---

## Comentario aparte (no implementado)

Dos observaciones sobre la rutina, que **no toqué** porque no corresponde:

1. Con las vueltas, los días de lunes y miércoles pasan de 47 a **55 minutos** reales.
   Si el techo de 50 importa, se resuelve acortando el híbrido, no sacando la vuelta.
2. El viernes tiene una sola vuelta mientras lunes y miércoles tienen dos. Si fue
   intencional, perfecto; si no, avisame y agrego la segunda.
