import { Clock, Dumbbell, Activity, Moon, CheckCircle2 } from 'lucide-react'

const typeConfig = {
  bigg: { tag: 'BIGG', icon: Dumbbell, dotColor: '#C8FF00' },
  run:  { tag: 'RUN',  icon: Activity, dotColor: '#FFB800' },
  rest: { tag: 'REST', icon: Moon, dotColor: '#8B92A0' },
}

export default function DayCard({ day, onClick, isCompleted, isToday }) {
  const cfg = typeConfig[day.type] || typeConfig.bigg
  const Icon = cfg.icon

  return (
    <button
      onClick={onClick}
      className="relative w-full text-left rounded-2xl overflow-hidden h-44 active:scale-[0.99] transition-transform"
    >
      <img
        src={day.image}
        alt={day.title}
        className="absolute inset-0 w-full h-full object-cover"
        style={{ opacity: 0.55 }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/40 to-black/90" />

      {isCompleted && (
        <div className="absolute top-3 right-3 z-10 bg-tide-lime text-tide-bg w-7 h-7 rounded-full flex items-center justify-center"
             style={{ boxShadow: '0 0 16px rgba(200,255,0,0.6)' }}>
          <CheckCircle2 className="w-4 h-4" strokeWidth={3} />
        </div>
      )}

      {isToday && !isCompleted && (
        <div className="absolute top-3 right-3 z-10 bg-tide-lime text-tide-bg text-[10px] font-extrabold px-2.5 py-1 rounded-full tracking-wider"
             style={{ boxShadow: '0 0 16px rgba(200,255,0,0.6)' }}>
          HOY
        </div>
      )}

      <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 bg-black/60 backdrop-blur-sm border border-white/10 px-2.5 py-1 rounded-full">
        <span className="w-1.5 h-1.5 rounded-full" style={{ background: cfg.dotColor }} />
        <span className="text-[10px] font-extrabold tracking-widest text-white">{cfg.tag}</span>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-4 z-10">
        <div className="text-[10px] font-bold tracking-widest text-white/60 mb-1">
          {day.name.toUpperCase()}
        </div>
        <h3 className="font-display text-white text-xl leading-tight mb-2">{day.title}</h3>
        <div className="flex items-center gap-3 text-[11px] text-white/80 font-medium">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" /> {day.duration} min
          </span>
          <span className="flex items-center gap-1">
            <Icon className="w-3 h-3" /> {day.subtitle}
          </span>
        </div>
      </div>
    </button>
  )
}
