import { week } from '../data/routine'

const typeShort = {
  bigg: 'BIGG',
  run: 'RUN',
  rest: 'REST',
}

export default function StreakCard({ completedDays, todayId, onDayClick }) {
  return (
    <div className="mx-5 bg-tide-surface border border-tide-border rounded-2xl p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="text-[15px] font-bold text-tide-text tracking-tight">Tu semana</div>
        <div className="text-xs text-tide-dim font-medium">
          <span className="text-tide-lime font-bold">{completedDays.length}</span>
          <span className="text-tide-dim"> / {week.filter(d => d.type !== 'rest').length} entrenos</span>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1.5 mb-3">
        {week.map(d => {
          const isCompleted = completedDays.includes(d.id)
          const isToday = d.id === todayId
          return (
            <button
              key={d.id}
              onClick={() => onDayClick && onDayClick(d.id)}
              className={`flex flex-col items-center gap-1.5 py-2 rounded-xl transition-all ${
                isToday ? 'bg-tide-surface-3' : ''
              }`}
            >
              <div className={`text-[11px] font-bold tracking-wider ${
                isToday ? 'text-tide-lime' : 'text-tide-muted'
              }`}>{d.day}</div>

              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-[9px] font-extrabold transition-all ${
                isCompleted
                  ? 'bg-tide-lime text-tide-bg pulse-glow'
                  : isToday
                    ? 'border-2 border-tide-lime text-tide-lime bg-transparent pulse-glow'
                    : 'border-2 border-tide-surface-3 text-tide-muted bg-transparent'
              }`}>
                {isCompleted ? '✓' : (
                  <span className="leading-none">
                    {d.type === 'bigg' ? 'B' : d.type === 'run' ? 'R' : '·'}
                  </span>
                )}
              </div>

              <div className={`text-[9px] font-bold tracking-wider ${
                isToday ? 'text-tide-lime' : isCompleted ? 'text-tide-dim' : 'text-tide-muted'
              }`}>
                {isToday ? 'HOY' : typeShort[d.type]}
              </div>
            </button>
          )
        })}
      </div>

      <div className="flex items-center justify-center gap-4 text-[11px] text-tide-dim font-medium pt-3 border-t border-tide-surface-3">
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-tide-lime" style={{ boxShadow: '0 0 8px #C8FF00' }} />
          <span>Completado</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full border border-tide-surface-3 bg-transparent" />
          <span>Programado</span>
        </div>
      </div>
    </div>
  )
}
