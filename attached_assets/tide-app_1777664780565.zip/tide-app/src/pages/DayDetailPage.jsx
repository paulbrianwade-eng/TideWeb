import { useState, useMemo } from 'react'
import { ArrowLeft, Clock, Target, CheckCircle2, Play, Pause, Zap } from 'lucide-react'
import BlockCard from '../components/BlockCard'
import FinishWorkoutModal from '../components/FinishWorkoutModal'
import RestTimer, { parseRest } from '../components/RestTimer'
import WeightLogModal from '../components/WeightLogModal'
import { useElapsedTimer, formatTime } from '../components/timerHooks'
import { isWeightedExercise } from '../data/loads'

const typeConfig = {
  bigg: { tag: 'BIGG', dot: '#C8FF00' },
  run:  { tag: 'RUN',  dot: '#FFB800' },
  rest: { tag: 'REST', dot: '#8B92A0' },
}

function getRequiredGear(day) {
  const text = JSON.stringify(day).toLowerCase()
  const gear = []
  if (/barbell|barra|squat|deadlift|bench press|hip thrust/.test(text)) gear.push('Barra olímpica + discos')
  if (/banco|bench/.test(text)) gear.push('Banco reclinable')
  if (/kb 20|kb 12|kb 8/.test(text)) gear.push('KBs (8/12/20)')
  if (/ddb |db /.test(text)) gear.push('Mancuernas')
  if (/box jump|cajón/.test(text)) gear.push('Cajón')
  if (/trx/.test(text)) gear.push('TRX')
  if (/soga|jump rope/.test(text)) gear.push('Soga')
  if (/elást|banded/.test(text)) gear.push('Elásticos')
  if (/rueda abdominal/.test(text)) gear.push('Rueda abd.')
  return gear
}

export default function DayDetailPage({ day, checks, onToggle, onBack, onFinish }) {
  const [showFinish, setShowFinish] = useState(false)
  const [restTarget, setRestTarget] = useState(null)
  const [weightLogTarget, setWeightLogTarget] = useState(null)
  const [skippedBlocks, setSkippedBlocks] = useState({})
  const [sessionStarted, setSessionStarted] = useState(false)
  const [paused, setPaused] = useState(false)

  const cfg = typeConfig[day.type] || typeConfig.bigg
  const sessionTimer = useElapsedTimer(sessionStarted && !paused)

  // Stats progreso
  const realBlocks = day.blocks.filter((b, idx) =>
    b.type !== 'warmup' && b.type !== 'quality' && !skippedBlocks[idx]
  )
  const totalExercises = realBlocks.reduce((acc, b) => acc + b.exercises.length, 0)
  const checkedCount = realBlocks.reduce(
    (acc, b) => acc + b.exercises.filter(e => checks[e.id]).length,
    0
  )
  const progress = totalExercises > 0 ? (checkedCount / totalExercises) * 100 : 0
  const canFinish = day.type !== 'rest' && checkedCount > 0

  const requiredGear = useMemo(() => getRequiredGear(day), [day])

  // Encuentra el próximo ejercicio sin marcar
  const nextExerciseId = useMemo(() => {
    for (const block of day.blocks) {
      for (const ex of block.exercises) {
        if (!checks[ex.id]) return ex.id
      }
    }
    return null
  }, [day, checks])

  function handleToggleExercise(id) {
    const exercise = day.blocks.flatMap(b => b.exercises).find(e => e.id === id)
    const wasChecked = !!checks[id]
    onToggle(id)

    if (!wasChecked && sessionStarted) {
      if (isWeightedExercise(exercise)) {
        setWeightLogTarget(exercise)
      } else {
        const restSeconds = parseRest(exercise.rest)
        if (restSeconds > 0) {
          setRestTarget({ seconds: restSeconds, exerciseName: 'Próximo set' })
        }
      }

      setTimeout(() => {
        const nextEl = document.querySelector('[data-exercise-id]:not([data-checked="true"])')
        if (nextEl) nextEl.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }, 300)
    }
  }

  function handleWeightSaved() {
    const ex = weightLogTarget
    setWeightLogTarget(null)
    if (ex) {
      const restSeconds = parseRest(ex.rest)
      if (restSeconds > 0) {
        setRestTarget({ seconds: restSeconds, exerciseName: 'Próximo set' })
      }
    }
  }

  function handleStartSession() {
    setSessionStarted(true)
    sessionTimer.reset()
  }

  function handleSaveSession(sessionData) {
    onFinish({
      ...sessionData,
      elapsedSeconds: sessionTimer.seconds,
    })
    setShowFinish(false)
    onBack()
  }

  function handleSkipBlock(idx) {
    setSkippedBlocks(prev => ({ ...prev, [idx]: true }))
  }

  return (
    <div className="min-h-screen bg-tide-bg pb-32">
      {/* Hero */}
      <div className="relative h-72 overflow-hidden">
        <img src={day.image} alt={day.title} className="absolute inset-0 w-full h-full object-cover" style={{ opacity: 0.65 }} />
        <div className="absolute inset-0 bg-gradient-to-b from-tide-bg/40 via-tide-bg/40 to-tide-bg" />

        <div className="relative p-5 pt-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-tide-bg/70 backdrop-blur-md border border-white/10 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-tide-text" strokeWidth={2.5} />
          </button>
          <div className="flex items-center gap-1.5 bg-tide-bg/70 backdrop-blur-md border border-white/10 px-3 py-1.5 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: cfg.dot }} />
            <span className="text-[10px] font-extrabold tracking-widest text-tide-text">{cfg.tag}</span>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-5">
          <p className="text-tide-dim text-[11px] font-bold tracking-widest mb-1 uppercase">{day.name}</p>
          <h1 className="font-display text-3xl text-tide-text leading-tight mb-2">{day.title}</h1>
          <div className="flex items-center gap-4 text-tide-dim text-sm font-medium">
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-tide-lime" /> {day.duration} min
            </span>
            <span className="flex items-center gap-1.5">
              <Target className="w-4 h-4 text-tide-lime" /> {day.subtitle}
            </span>
          </div>
        </div>
      </div>

      {/* Iniciador / cronómetro sticky */}
      {day.type !== 'rest' && (
        <div className="bg-tide-bg px-5 py-3 sticky top-0 z-20 border-b border-tide-border">
          {!sessionStarted ? (
            <button
              onClick={handleStartSession}
              className="w-full bg-tide-lime text-tide-bg font-extrabold py-4 rounded-2xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform uppercase text-sm tracking-wide"
              style={{ boxShadow: '0 8px 24px rgba(200,255,0,0.3)' }}
            >
              <Zap className="w-4 h-4" strokeWidth={3} fill="currentColor" />
              Empezar entrenamiento
            </button>
          ) : (
            <div>
              <div className="bg-gradient-to-br from-tide-surface to-tide-surface-2 border border-tide-border rounded-2xl p-3 flex items-center gap-3">
                <button
                  onClick={() => setPaused(p => !p)}
                  className="w-11 h-11 rounded-full bg-tide-lime flex items-center justify-center flex-shrink-0 active:scale-90 transition-transform"
                  style={{ boxShadow: '0 0 20px rgba(200,255,0,0.4)' }}
                >
                  {paused
                    ? <Play className="w-4 h-4 text-tide-bg" strokeWidth={2.5} fill="currentColor" />
                    : <Pause className="w-4 h-4 text-tide-bg" strokeWidth={2.5} fill="currentColor" />
                  }
                </button>
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] font-bold tracking-wider text-tide-muted uppercase">
                    {paused ? 'En pausa' : 'En curso'}
                  </div>
                  <div className="font-mono text-2xl font-bold text-tide-text leading-none">
                    {formatTime(sessionTimer.seconds)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] font-bold tracking-wider text-tide-muted uppercase">Progreso</div>
                  <div className="font-mono text-base font-bold text-tide-text">{checkedCount}/{totalExercises}</div>
                </div>
              </div>
              <div className="h-1 bg-tide-surface-2 rounded-full overflow-hidden mt-2">
                <div
                  className="h-full bg-tide-lime transition-all duration-300 rounded-full"
                  style={{ width: `${progress}%`, boxShadow: '0 0 8px #C8FF00' }}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Resumen pre-entreno */}
      {!sessionStarted && day.type !== 'rest' && (
        <div className="mx-5 mt-4 bg-tide-surface border border-tide-border rounded-2xl p-4">
          <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-3">Antes de empezar</div>
          <div className="grid grid-cols-2 gap-2.5 mb-3">
            <div className="bg-tide-bg border border-tide-border rounded-xl p-3">
              <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-1">Bloques</div>
              <div className="font-display text-xl text-tide-text">{day.blocks.length}</div>
            </div>
            <div className="bg-tide-bg border border-tide-border rounded-xl p-3">
              <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-1">Tiempo</div>
              <div className="font-display text-xl text-tide-text">{day.duration}'</div>
            </div>
          </div>
          {requiredGear.length > 0 && (
            <div>
              <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-1.5">Necesitás</div>
              <div className="flex flex-wrap gap-1.5">
                {requiredGear.map(g => (
                  <span key={g} className="bg-tide-surface-3 text-tide-text text-[11px] px-2.5 py-1 rounded-lg font-medium">
                    {g}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="px-5 py-4">
        <p className="text-[13px] text-tide-dim leading-relaxed">{day.intro}</p>
      </div>

      <div className="space-y-0 animate-slide-up">
        {day.blocks.map((block, idx) => (
          <BlockCard
            key={idx}
            block={block}
            checks={checks}
            onToggle={handleToggleExercise}
            onSkipBlock={() => handleSkipBlock(idx)}
            isSkipped={!!skippedBlocks[idx]}
            sessionStarted={sessionStarted}
            nextExerciseId={nextExerciseId}
          />
        ))}
      </div>

      {canFinish && sessionStarted && (
        <div className="px-5 mt-4">
          <button
            onClick={() => setShowFinish(true)}
            className="w-full bg-tide-text text-tide-bg font-extrabold py-4 rounded-2xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform uppercase text-sm tracking-wide"
          >
            <CheckCircle2 className="w-4 h-4" strokeWidth={3} />
            Finalizar entrenamiento
          </button>
          <p className="text-[11px] text-tide-muted text-center mt-2 font-medium">
            Te vamos a pedir tu FC promedio y calorías quemadas
          </p>
        </div>
      )}

      {showFinish && (
        <FinishWorkoutModal
          day={day}
          elapsedSeconds={sessionTimer.seconds}
          onClose={() => setShowFinish(false)}
          onSave={handleSaveSession}
        />
      )}

      {restTarget && (
        <RestTimer
          seconds={restTarget.seconds}
          exerciseName={restTarget.exerciseName}
          onClose={() => setRestTarget(null)}
        />
      )}

      {weightLogTarget && (
        <WeightLogModal
          exercise={weightLogTarget}
          onClose={() => setWeightLogTarget(null)}
          onSaved={handleWeightSaved}
        />
      )}
    </div>
  )
}
