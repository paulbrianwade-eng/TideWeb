// Tracking de cargas con localStorage
const STORAGE_KEY = 'tide_loads_v1'

export function getAllLoads() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}')
  } catch {
    return {}
  }
}

export function getLastLoad(exerciseId) {
  const all = getAllLoads()
  const history = all[exerciseId] || []
  return history.length > 0 ? history[history.length - 1] : null
}

export function getLoadHistory(exerciseId) {
  const all = getAllLoads()
  return all[exerciseId] || []
}

export function saveLoad(exerciseId, weight, reps, notes = '') {
  const all = getAllLoads()
  if (!all[exerciseId]) all[exerciseId] = []
  all[exerciseId].push({
    weight: parseFloat(weight),
    reps: parseInt(reps),
    notes,
    date: new Date().toISOString(),
  })
  // Solo últimos 50 por ejercicio
  if (all[exerciseId].length > 50) {
    all[exerciseId] = all[exerciseId].slice(-50)
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all))
}

// Identifica ejercicios con peso (para abrir modal automático)
export function isWeightedExercise(exercise) {
  if (!exercise) return false
  const name = exercise.name.toLowerCase()
  const weightedKeywords = [
    'barbell', 'back squat', 'front squat', 'bench press', 'deadlift',
    'hip thrust', 'overhead press', 'thruster',
    'kb 20', 'kb 12', 'kb heavy',
    'press (kb 20', 'clean (kb 20', 'swing (kb 20',
    'hexbar', 'romanian',
  ]
  return weightedKeywords.some(kw => name.includes(kw)) ||
         (exercise.target && exercise.target.includes('kg'))
}

export function computeDiff(prevWeight, prevReps, newWeight, newReps) {
  if (!prevWeight || !newWeight) return null
  const diff = newWeight - prevWeight
  const pct = (diff / prevWeight) * 100
  let direction = 'same'
  if (diff > 0.1) direction = 'up'
  else if (diff < -0.1) direction = 'down'
  return {
    diff: diff.toFixed(1),
    pct: pct.toFixed(1),
    direction,
    repsChange: newReps - prevReps,
  }
}
