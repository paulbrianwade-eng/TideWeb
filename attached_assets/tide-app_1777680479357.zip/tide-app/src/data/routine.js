// TIDE — Rutina semanal adaptada a equipamiento de Patricio
// Equipo: Rack + barra olímpica + 60kg discos | Banco reclinable
// KB 8/12/20 | DDB 1/3/5 (ligeras) | Cajón salto | TRX | Soga | Rueda abdominal | Elásticos

export const week = [
  {
    id: 'lun', day: 'L', name: 'Lunes', type: 'bigg',
    title: 'Full Hybrid', subtitle: 'Squat + metcon largo',
    duration: 55,
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&q=80',
    intro: 'Sesión completa con squat pesado + metcon medio + finisher. Abrís la semana fresco.',
    blocks: [
      {
        type: 'warmup', title: 'Calentamiento', duration: 8,
        format: 'Activación general + específica',
        exercises: [
          { id: 'l-w-1', name: 'Movilidad cadera + tobillo', reps: '5 min', detail: "Gato/camello, world's greatest, ankle rocks" },
          { id: 'l-w-2', name: 'Activación general', reps: '2 rondas', detail: '10 air squats + 10 push ups + 10 jumping jacks + 5 inchworm' },
          { id: 'l-w-3', name: 'Específico al squat', reps: '2 sets', rest: '30"', detail: 'Back squat barra vacía 5 reps + 60% 1RM × 5' },
        ]
      },
      {
        type: 'quality', title: 'Calidad de movimiento', duration: 7,
        format: 'AMRAP 7\' for quality',
        exercises: [
          { id: 'l-1-1', name: 'Runner Step Ups', reps: '6/6 reps', detail: 'En tu cajón. Sin peso o KB 8 kg en goblet. Movimiento controlado.' },
          { id: 'l-1-2', name: 'Heiden a Single-Leg Box Jump', reps: '2/2 reps', detail: 'Salto lateral, caés a una pierna sobre cajón bajo.' },
          { id: 'l-1-3', name: 'Reverse Lunge', reps: '6/6 reps', detail: 'Tronco vertical, rodilla atrás cae suave.' },
          { id: 'l-1-4', name: 'Asymmetric Halo (KB 8 o 12)', reps: '6/6 reps', detail: 'Círculo lento alrededor de la cabeza.' },
        ]
      },
      {
        type: 'strength', title: 'Hybrid Strength', duration: 13,
        format: 'AMRAP 13\' · Objetivo 3-4 rondas',
        exercises: [
          { id: 'l-2-1', name: 'Barbell Back Squat', reps: '6 reps', detail: 'Carga ~72.5% 1RM. RPE 7-8.', target: '~45-50 kg' },
          { id: 'l-2-2', name: 'Box Jumps', reps: '8 reps', detail: 'Tu cajón. Rebote suave o step down.' },
          { id: 'l-2-3', name: 'Soga (jump rope)', reps: '90"', detail: '⚠️ Sustituye al Machine 40%. Ritmo conversacional.' },
        ]
      },
      {
        type: 'metcon', title: 'KB Complex', duration: 12,
        format: 'Every 90" · 8 rondas',
        exercises: [
          { id: 'l-3-1', name: 'KB Front Squat (2× KB 12)', reps: '6 reps', detail: 'Una en cada hombro, codos altos. ⚠️ Reemplaza DDB pesadas.' },
          { id: 'l-3-2', name: 'KB Hang Clean (KB 20)', reps: '4/4 reps', detail: 'Una sola KB, alterna.' },
          { id: 'l-3-3', name: 'KB Push Press (KB 20)', reps: '4/4 reps', detail: 'Asistencia de piernas, bloqueo arriba.' },
          { id: 'l-3-4', name: 'Burpees', reps: '4 reps', detail: 'Pecho al suelo, salto con palmada arriba.' },
        ]
      },
      {
        type: 'finisher', title: 'Complete 3 a 10', duration: 8,
        format: 'Sube reps cada ronda',
        exercises: [
          { id: 'l-4-1', name: 'KB Swing (KB 20)', reps: '3-4-5...10', detail: '⚠️ Reemplaza Wall Ball. Bisagra de cadera, KB hasta los ojos.' },
          { id: 'l-4-2', name: 'Burpees', reps: '3-4-5...10', detail: 'Pecho al suelo + salto.' },
          { id: 'l-4-3', name: 'Box Jumps', reps: '3-4-5...10', detail: 'Cajón medio.' },
        ]
      },
    ]
  },

  {
    id: 'mar', day: 'M', name: 'Martes', type: 'run',
    title: 'Run Z2', subtitle: 'Base aeróbica · Recuperación',
    duration: 50,
    image: 'https://images.unsplash.com/photo-1486218119243-13883505764c?w=800&q=80',
    intro: 'Carrera continua a ritmo conversacional. Recuperación entre lunes y miércoles.',
    blocks: [
      {
        type: 'run', title: 'Carrera continua Z2', duration: 50,
        format: 'Pulso 60-70% FCM',
        exercises: [
          { id: 'm-1-1', name: 'Calentamiento', reps: '5-8 min', detail: 'Trote muy suave. Movilidad antes de empezar.' },
          { id: 'm-1-2', name: 'Bloque principal Z2', reps: '35-45 min', detail: 'Pulso ~130-145 ppm. Ritmo: 30-60s/km más lento que tu pace habitual.' },
          { id: 'm-1-3', name: 'Vuelta a la calma', reps: '5 min', detail: 'Caminata. Pulso bajo 110 ppm.' },
        ]
      },
      {
        type: 'quality', title: 'Cómo saber si estás en Z2', duration: 0,
        exercises: [
          { id: 'm-2-1', name: 'Test de conversación', detail: 'Podés hablar 4-5 frases sin jadear.' },
          { id: 'm-2-2', name: 'Sensación', detail: 'Sostendrías el ritmo 2 horas si hiciera falta.' },
          { id: 'm-2-3', name: 'Si necesitás caminar', detail: 'Caminá. La constancia del pulso es lo que importa.' },
        ]
      },
    ]
  },

  {
    id: 'mie', day: 'M', name: 'Miércoles', type: 'bigg',
    title: 'Bench + intervalos', subtitle: 'Empuje + 50/10',
    duration: 50,
    image: 'https://images.unsplash.com/photo-1532029837206-abbe2b7620e3?w=800&q=80',
    intro: 'Sesión más metabólica. Bench dentro de un AMRAP, luego intervalo intenso 50/10.',
    blocks: [
      {
        type: 'warmup', title: 'Calentamiento', duration: 8,
        exercises: [
          { id: 'mi-w-1', name: 'Movilidad torácica + hombro', reps: '4 min', detail: 'Cat-cow, banded dislocates con elástico.' },
          { id: 'mi-w-2', name: 'Activación', reps: '2 rondas', detail: '10 push ups + 10 KB swing ligero (KB 8) + 10 air squats.' },
          { id: 'mi-w-3', name: 'Aprox. al bench', reps: '2 sets', rest: '45"', detail: 'Barra vacía × 8 + 60% 1RM × 5.' },
        ]
      },
      {
        type: 'strength', title: 'Hybrid Strength · Bench', duration: 12,
        format: 'AMRAP 12\' · Objetivo 3-4 rondas',
        exercises: [
          { id: 'mi-1-1', name: 'Barbell Bench Press', reps: '5 reps', detail: 'Carga ~75% 1RM. RPE 7-8. Spotter recomendado.', target: '~50-55 kg' },
          { id: 'mi-1-2', name: 'Push Up Hold', reps: '10"', detail: 'Posición media del push up por 10 segundos.' },
          { id: 'mi-1-3', name: 'Soga (jump rope)', reps: '90"', detail: '⚠️ Reemplaza Machine 40%.' },
        ]
      },
      {
        type: 'metcon', title: '50" ON / 10" OFF', duration: 8,
        format: '8 minutos · 2 rondas',
        exercises: [
          { id: 'mi-2-1', name: 'KB Floor Press (2× KB 12)', reps: '50"', detail: '⚠️ Reemplaza DDB Chest Press. Una KB en cada mano.' },
          { id: 'mi-2-2', name: 'KB Push Press (KB 20)', reps: '50"', detail: 'Una mano. Cambia en la siguiente ronda.' },
          { id: 'mi-2-3', name: 'Soga alta intensidad', reps: '50"', detail: '⚠️ Reemplaza Machine. Doble salto si podés.' },
          { id: 'mi-2-4', name: 'KB Russian Swing (KB 20)', reps: '50"', detail: 'KB hasta altura del pecho.' },
        ]
      },
      {
        type: 'finisher', title: 'Core finisher', duration: 8,
        exercises: [
          { id: 'mi-3-1', name: 'Russian Twist (disco 5-10 kg)', reps: '3 × 20', rest: '30"', detail: 'Talones arriba si controlás.' },
          { id: 'mi-3-2', name: 'Plank Twist Lateral (DDB 3-5)', reps: '3 × 10/lado', rest: '30"', detail: 'Desde plank alto, gira y toca DDB.' },
          { id: 'mi-3-3', name: 'Palof Press (elástico)', reps: '3 × 12/lado', rest: '30"', detail: '⚠️ Con elástico anclado al rack.' },
        ]
      },
    ]
  },

  {
    id: 'jue', day: 'J', name: 'Jueves', type: 'run',
    title: 'Intervalos VO2max', subtitle: 'Cardio intenso · EPOC alto',
    duration: 38,
    image: 'https://images.unsplash.com/photo-1571008887538-b36bb32f4571?w=800&q=80',
    intro: 'Intervalos de alta intensidad. Sube tu VO2max y dispara EPOC sin cansar piernas.',
    blocks: [
      {
        type: 'warmup', title: 'Estructura', duration: 38,
        exercises: [
          { id: 'j-1-1', name: 'Calentamiento', reps: '10 min', detail: 'Caminata 2\' → trote suave subiendo gradual.' },
          { id: 'j-1-2', name: 'Drills (opcional)', reps: '3 min', detail: 'Skipping, talones glúteos, zancadas largas.' },
          { id: 'j-1-3', name: 'Bloque principal', reps: '16 min', detail: 'Elegí una de las dos opciones.' },
          { id: 'j-1-4', name: 'Vuelta a la calma', reps: '8 min', detail: 'Trote suave Z1.' },
        ]
      },
      {
        type: 'metcon', title: 'Opción A · 4×4', duration: 16,
        format: 'Clásico VO2max',
        exercises: [
          { id: 'j-2-1', name: 'Trabajo: 4 min × 4', reps: '85-90% FCM', detail: 'Ritmo exigente sin reventar.' },
          { id: 'j-2-2', name: 'Recuperación: 2 min × 4', reps: 'Trote suave', detail: 'Pulso debe bajar a Z2.' },
        ]
      },
      {
        type: 'metcon', title: 'Opción B · 30/30', duration: 16,
        format: 'Más explosivo',
        exercises: [
          { id: 'j-3-1', name: 'Trabajo: 30" × 16', reps: '~90% FCM', detail: 'Casi sprint controlado.' },
          { id: 'j-3-2', name: 'Recuperación: 30" × 16', reps: 'Trote', detail: 'Recuperación activa, no caminando.' },
        ]
      },
      {
        type: 'quality', title: 'Cuándo usar cada opción', duration: 0,
        exercises: [
          { id: 'j-4-1', name: 'Si mañana hay deadlift', detail: 'Usá Opción B (30/30). Menos exigente para piernas.' },
          { id: 'j-4-2', name: 'Si te sentís con energía', detail: 'Usá Opción A (4×4).' },
          { id: 'j-4-3', name: 'Si llegás cansado', detail: 'Reducí a 3×4 o 12×30/30.' },
        ]
      },
    ]
  },

  {
    id: 'vie', day: 'V', name: 'Viernes', type: 'bigg',
    title: 'Posterior + KB Heavy', subtitle: 'Deadlift + cadena posterior',
    duration: 55,
    image: 'https://images.unsplash.com/photo-1517344884509-a0c97ec11bcc?w=800&q=80',
    intro: 'Cadena posterior + KB pesadas. Venís con piernas trabajadas del jueves: metcon medio.',
    blocks: [
      {
        type: 'warmup', title: 'Calentamiento', duration: 8,
        exercises: [
          { id: 'v-w-1', name: 'Movilidad cadera + isquios', reps: '4 min', detail: '90/90, world\'s greatest, jefferson curls.' },
          { id: 'v-w-2', name: 'Activación posterior', reps: '2 sets', rest: '30"', detail: '10 glute bridge + 10 banded good morning + 10 KB swing.' },
          { id: 'v-w-3', name: 'Aprox. al deadlift', reps: '2 sets', rest: '60"', detail: 'Barra vacía × 8 + 50% 1RM × 5.' },
        ]
      },
      {
        type: 'strength', title: 'Hybrid Strength · Deadlift', duration: 13,
        format: 'AMRAP 13\' · NO buscar PR',
        exercises: [
          { id: 'v-1-1', name: 'Barbell Deadlift', reps: '5 reps', detail: 'Carga ~70% 1RM. RPE 7. Técnica primero.', target: '~50 kg' },
          { id: 'v-1-2', name: 'Push Up Hold', reps: '10"', detail: 'Activación tren superior entre rondas.' },
          { id: 'v-1-3', name: 'Soga', reps: '90"', detail: 'Recuperación activa.' },
        ]
      },
      {
        type: 'metcon', title: 'Every 90" · KB Heavy', duration: 12,
        format: '8 rondas · Cargas más altas',
        exercises: [
          { id: 'v-2-1', name: 'KB Front Squat (2× KB 12)', reps: '6 reps', detail: 'Cuidar técnica con la fatiga del DL.' },
          { id: 'v-2-2', name: 'KB Hang Clean (KB 20)', reps: '4/4', detail: 'Sin soltar entre ejercicios.' },
          { id: 'v-2-3', name: 'KB Push Press (KB 20)', reps: '4/4', detail: 'Empuje con piernas.' },
          { id: 'v-2-4', name: 'Burpees', reps: '4', detail: 'Pecho al suelo + salto.' },
        ]
      },
      {
        type: 'strength', title: 'Glúteo / Posterior', duration: 12,
        format: 'Accesorio',
        exercises: [
          { id: 'v-3-1', name: 'Hip Thrust (BB en banco)', reps: '4 × 10', rest: '60"', detail: 'Espalda alta en banco. Pausa 1" arriba.', target: '~40-50 kg' },
          { id: 'v-3-2', name: 'Hamstring Bridge (talones en banco)', reps: '3 × 12', rest: '45"', detail: 'Pies arriba en banco, sube cadera.' },
        ]
      },
      {
        type: 'finisher', title: 'Core breve', duration: 5,
        exercises: [
          { id: 'v-4-1', name: 'Hollow Hold', reps: '3 × 30"', rest: '30"', detail: 'Lumbar pegada al suelo.' },
          { id: 'v-4-2', name: 'Side Plank', reps: '3 × 30"/lado', rest: '30"', detail: 'Cadera arriba, alineación recta.' },
        ]
      },
    ]
  },

  {
    id: 'sab', day: 'S', name: 'Sábado', type: 'bigg',
    title: 'Hyrox-style', subtitle: 'Híbrido completo · Día estrella',
    duration: 55,
    image: 'https://images.unsplash.com/photo-1599058917212-d750089bc07e?w=800&q=80',
    intro: 'La sesión más completa. Cierra los días fuertes. Venís con descanso del jueves.',
    blocks: [
      {
        type: 'warmup', title: 'Calentamiento', duration: 8,
        exercises: [
          { id: 's-w-1', name: 'Movilidad general', reps: '4 min', detail: 'Cadera, hombro, columna torácica.' },
          { id: 's-w-2', name: 'Activación', reps: '2 rondas', detail: '10 air squats + 10 push ups + 10 KB swing + 5 burpees.' },
          { id: 's-w-3', name: 'Específico', reps: '2 sets', rest: '30"', detail: 'Front squat barra vacía + 5 TRX rows.' },
        ]
      },
      {
        type: 'strength', title: 'Hybrid Strength · Front Squat', duration: 12,
        format: 'AMRAP 12\'',
        exercises: [
          { id: 's-1-1', name: 'Barbell Front Squat', reps: '6 reps', detail: 'Codos altos, tronco vertical. RPE 7.', target: '~40-45 kg' },
          { id: 's-1-2', name: 'TRX Row (estricto)', reps: '8 reps', detail: '⚠️ Reemplaza Pull Ups. Más vertical = más difícil.' },
          { id: 's-1-3', name: 'Soga', reps: '90"', detail: 'Recuperación activa.' },
        ]
      },
      {
        type: 'metcon', title: 'Long Metcon · Hyrox', duration: 13,
        format: 'AMRAP 13\' · Objetivo: 1 ronda completa',
        exercises: [
          { id: 's-2-1', name: 'KB Swing (KB 20)', reps: '30 reps', detail: '⚠️ Reemplaza Wall/Air Ball. Reps en partidas.' },
          { id: 's-2-2', name: 'TRX Row', reps: '5 reps', detail: 'Estricto, ritmo controlado.' },
          { id: 's-2-3', name: 'KB Front Rack Lunges (2× KB 12)', reps: '30 reps', detail: 'KB en posición rack, alterna piernas.' },
          { id: 's-2-4', name: 'Man-Maker (DDB 5 o KB 8)', reps: '5 reps', detail: 'Push up + row D + row I + clean + push press.' },
          { id: 's-2-5', name: 'KB Floor Press (2× KB 12)', reps: '30 reps', detail: 'En suelo, ritmo constante.' },
          { id: 's-2-6', name: 'KB Thruster (2× KB 12)', reps: '5 reps', detail: 'Squat + push press encadenado.' },
          { id: 's-2-7', name: 'Burpee + KB Clean (KB 20)', reps: '20 reps', detail: '⚠️ Reemplaza Devil Clean.' },
        ]
      },
      {
        type: 'finisher', title: 'Core finisher', duration: 7,
        exercises: [
          { id: 's-3-1', name: 'KB Halo (KB 12)', reps: '3 × 8/dirección', rest: '30"', detail: 'Lento, controlado.' },
          { id: 's-3-2', name: 'Hollow Hold (KB 8 extendida)', reps: '3 × 30"', rest: '30"', detail: 'KB sobre la cabeza.' },
          { id: 's-3-3', name: 'Rueda abdominal', reps: '3 × 8-10', rest: '45"', detail: '⚠️ Reemplaza Sprawls. Desde rodillas.' },
        ]
      },
    ]
  },

  {
    id: 'dom', day: 'D', name: 'Domingo', type: 'rest',
    title: 'Descanso', subtitle: 'Recuperación total',
    duration: 30,
    image: 'https://images.unsplash.com/photo-1545389336-cf090694435e?w=800&q=80',
    intro: 'Sin entrenamiento estructurado. La recuperación ES entrenamiento.',
    blocks: [
      {
        type: 'quality', title: 'Recuperación activa (opcional)', duration: 30,
        format: '30-45 min',
        exercises: [
          { id: 'd-1-1', name: 'Caminata al aire libre', reps: '30-45 min', detail: 'Ritmo cómodo. Sol si es posible.' },
          { id: 'd-1-2', name: 'Movilidad / yoga suave', reps: '15-20 min', detail: 'Cadera, columna, hombros.' },
          { id: 'd-1-3', name: 'Sauna o baño caliente', detail: 'Si tenés acceso.' },
        ]
      },
    ]
  },
]
