import { useState, useEffect, useRef } from 'react'

export function formatTime(totalSeconds) {
  const m = Math.floor(totalSeconds / 60)
  const s = Math.floor(totalSeconds % 60)
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

export function formatTimeLong(totalSeconds) {
  const h = Math.floor(totalSeconds / 3600)
  const m = Math.floor((totalSeconds % 3600) / 60)
  const s = Math.floor(totalSeconds % 60)
  if (h > 0) {
    return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
  }
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

// Cronómetro ascendente
export function useElapsedTimer(running) {
  const [seconds, setSeconds] = useState(0)
  const startRef = useRef(null)
  const baseRef = useRef(0)

  useEffect(() => {
    if (!running) {
      if (startRef.current) {
        baseRef.current = baseRef.current + (Date.now() - startRef.current) / 1000
        startRef.current = null
      }
      return
    }
    startRef.current = Date.now()
    const id = setInterval(() => {
      const elapsed = baseRef.current + (Date.now() - startRef.current) / 1000
      setSeconds(elapsed)
    }, 250)
    return () => clearInterval(id)
  }, [running])

  function reset() {
    baseRef.current = 0
    startRef.current = running ? Date.now() : null
    setSeconds(0)
  }

  return { seconds, reset }
}

// Countdown
export function useCountdown(initial, running) {
  const [seconds, setSeconds] = useState(initial)
  const targetRef = useRef(null)
  const remainingRef = useRef(initial)
  const initialRef = useRef(initial)

  useEffect(() => {
    initialRef.current = initial
    remainingRef.current = initial
    setSeconds(initial)
  }, [initial])

  useEffect(() => {
    if (!running || seconds <= 0) {
      if (targetRef.current && running === false) {
        remainingRef.current = Math.max(0, (targetRef.current - Date.now()) / 1000)
        targetRef.current = null
      }
      return
    }
    targetRef.current = Date.now() + remainingRef.current * 1000
    const id = setInterval(() => {
      const r = (targetRef.current - Date.now()) / 1000
      if (r <= 0) {
        setSeconds(0)
        clearInterval(id)
      } else {
        setSeconds(r)
      }
    }, 200)
    return () => clearInterval(id)
  }, [running, initial])

  function addSeconds(n) {
    if (targetRef.current) {
      targetRef.current += n * 1000
      setSeconds((targetRef.current - Date.now()) / 1000)
    } else {
      remainingRef.current = Math.max(0, remainingRef.current + n)
      setSeconds(remainingRef.current)
    }
  }

  function resetTo(n) {
    remainingRef.current = n
    initialRef.current = n
    if (running) targetRef.current = Date.now() + n * 1000
    setSeconds(n)
  }

  return { seconds, addSeconds, resetTo, initial: initialRef.current }
}

// Beep + vibración
export function beep(duration = 200, frequency = 880) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)()
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    osc.connect(gain)
    gain.connect(ctx.destination)
    osc.frequency.value = frequency
    osc.type = 'sine'
    gain.gain.setValueAtTime(0.3, ctx.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration / 1000)
    osc.start()
    osc.stop(ctx.currentTime + duration / 1000)
  } catch (e) {
    // sin audio
  }
  if (navigator.vibrate) navigator.vibrate([200, 100, 200])
}
