import { useState, useEffect, useRef } from 'react'
import { X, Plus, Pause, Play, SkipForward } from 'lucide-react'
import { useCountdown, formatTime, beep } from './timerHooks'

export function parseRest(restStr) {
  if (!restStr) return 0
  const s = String(restStr).trim()
  const secMatch = s.match(/(\d+)\s*"/)
  if (secMatch) return parseInt(secMatch[1])
  const minMatch = s.match(/(\d+)\s*'/)
  if (minMatch) return parseInt(minMatch[1]) * 60
  const num = s.match(/^\d+$/)
  if (num) return parseInt(s)
  return 0
}

export default function RestTimer({ seconds: initial, exerciseName, onClose }) {
  const [running, setRunning] = useState(true)
  const { seconds, addSeconds } = useCountdown(initial, running)
  const beepedRef = useRef(false)

  useEffect(() => {
    if (seconds <= 0 && !beepedRef.current) {
      beep()
      beepedRef.current = true
      setTimeout(onClose, 800)
    }
  }, [seconds, onClose])

  const progress = Math.max(0, Math.min(1, seconds / initial))
  const radius = 110
  const circumference = 2 * Math.PI * radius
  const offset = circumference * (1 - progress)

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-tide-bg/95 backdrop-blur-sm p-5">
      <div className="bg-tide-surface border border-tide-border w-full max-w-[400px] rounded-3xl p-6 animate-slide-up">
        <div className="flex items-center justify-between mb-4">
          <span className="text-[10px] font-bold text-tide-muted tracking-wider uppercase">Descanso</span>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-tide-surface-3 flex items-center justify-center">
            <X className="w-4 h-4 text-tide-dim" />
          </button>
        </div>

        <div className="relative flex items-center justify-center my-4">
          <svg width="260" height="260" className="-rotate-90">
            <circle cx="130" cy="130" r={radius} fill="none" stroke="#232A34" strokeWidth="8" />
            <circle
              cx="130" cy="130" r={radius}
              fill="none"
              stroke="#C8FF00"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              style={{ transition: 'stroke-dashoffset 0.3s linear', filter: 'drop-shadow(0 0 8px #C8FF00)' }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="font-mono text-5xl font-bold text-tide-text">
              {formatTime(Math.max(0, Math.ceil(seconds)))}
            </div>
            <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase mt-2">
              {exerciseName || 'Próximo set'}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-5">
          <button
            onClick={() => addSeconds(15)}
            className="bg-tide-surface-3 text-tide-text font-bold py-3 rounded-xl flex items-center justify-center gap-1 active:scale-95 transition-transform"
          >
            <Plus className="w-4 h-4" strokeWidth={2.5} />
            <span className="text-sm">15s</span>
          </button>
          <button
            onClick={() => setRunning(r => !r)}
            className="bg-tide-lime text-tide-bg font-bold py-3 rounded-xl flex items-center justify-center active:scale-95 transition-transform"
            style={{ boxShadow: '0 0 16px rgba(200,255,0,0.4)' }}
          >
            {running
              ? <Pause className="w-5 h-5" strokeWidth={2.5} fill="currentColor" />
              : <Play className="w-5 h-5" strokeWidth={2.5} fill="currentColor" />
            }
          </button>
          <button
            onClick={onClose}
            className="bg-tide-surface-3 text-tide-text font-bold py-3 rounded-xl flex items-center justify-center gap-1 active:scale-95 transition-transform"
          >
            <SkipForward className="w-4 h-4" strokeWidth={2.5} />
            <span className="text-sm">Skip</span>
          </button>
        </div>
      </div>
    </div>
  )
}
