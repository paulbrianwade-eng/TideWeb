import { Home, BarChart3 } from 'lucide-react'

export default function BottomNav({ active, onChange }) {
  const items = [
    { id: 'home', label: 'Home', Icon: Home },
    { id: 'activity', label: 'Actividad', Icon: BarChart3 },
  ]

  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-tide-surface border-t border-tide-border z-50 backdrop-blur-xl"
         style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
      <div className="flex items-center justify-around px-3 py-2.5">
        {items.map(item => {
          const isActive = active === item.id
          return (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              className={`flex-1 flex flex-col items-center gap-1 py-1.5 transition-colors ${
                isActive ? 'text-tide-lime' : 'text-tide-muted'
              }`}
            >
              <item.Icon className="w-5 h-5" strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[10px] font-bold tracking-wider">{item.label}</span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
