export default function TideLogo({ size = 'md' }) {
  const sizes = {
    sm: { font: 'text-xl', dot: 'w-1.5 h-1.5' },
    md: { font: 'text-2xl', dot: 'w-2 h-2' },
    lg: { font: 'text-3xl', dot: 'w-2.5 h-2.5' },
  }
  const s = sizes[size] || sizes.md

  return (
    <div className="flex items-center gap-1.5">
      <span className={`font-display ${s.font} text-tide-text tracking-wide`}>TIDE</span>
      <span
        className={`${s.dot} rounded-full bg-tide-lime mb-1.5`}
        style={{ boxShadow: '0 0 12px #C8FF00' }}
      />
    </div>
  )
}
