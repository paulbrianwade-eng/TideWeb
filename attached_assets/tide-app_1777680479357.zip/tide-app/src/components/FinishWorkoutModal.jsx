import { useState } from 'react'
import { X, Heart, Flame, Clock } from 'lucide-react'
import { formatTime } from './timerHooks'

export default function FinishWorkoutModal({ day, elapsedSeconds, onClose, onSave }) {
  const [avgHR, setAvgHR] = useState('')
  const [calories, setCalories] = useState('')
  const [feel, setFeel] = useState(null)
  const [notes, setNotes] = useState('')

  const feelOptions = [
    { value: 'easy',     label: '😎', text: 'Fácil',     color: 'bg-tide-green/15 text-tide-green border-tide-green' },
    { value: 'moderate', label: '😅', text: 'Moderado',  color: 'bg-tide-amber/15 text-tide-amber border-tide-amber' },
    { value: 'hard',     label: '🥵', text: 'Duro',      color: 'bg-orange-500/15 text-orange-300 border-orange-400' },
    { value: 'brutal',   label: '💀', text: 'Brutal',    color: 'bg-tide-red/15 text-[#FF8080] border-tide-red' },
  ]

  function handleSave() {
    onSave({
      dayId: day.id,
      dayName: day.name,
      dayTitle: day.title,
      duration: elapsedSeconds ? Math.round(elapsedSeconds / 60) : day.duration,
      type: day.type,
      date: new Date().toISOString(),
      avgHR: avgHR ? parseInt(avgHR) : null,
      calories: calories ? parseInt(calories) : null,
      feel,
      notes: notes.trim() || null,
    })
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-tide-bg/90 backdrop-blur-sm">
      <div className="bg-tide-surface border-t border-tide-border sm:border w-full max-w-[480px] rounded-t-3xl sm:rounded-3xl p-6 max-h-[92vh] overflow-y-auto animate-slide-up">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] font-bold text-tide-muted tracking-wider uppercase">Finalizar entrenamiento</span>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-tide-surface-3 flex items-center justify-center">
            <X className="w-4 h-4 text-tide-dim" />
          </button>
        </div>
        <h2 className="font-display text-2xl mb-1 leading-tight text-tide-text">{day.title}</h2>
        <p className="text-xs text-tide-dim mb-3 font-medium">{day.name} · {day.subtitle}</p>

        {elapsedSeconds > 0 && (
          <div className="bg-tide-bg border border-tide-border rounded-xl p-3 mb-5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-tide-lime flex items-center justify-center flex-shrink-0"
                 style={{ boxShadow: '0 0 14px rgba(200,255,0,0.4)' }}>
              <Clock className="w-5 h-5 text-tide-bg" strokeWidth={2.5} />
            </div>
            <div>
              <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase">Tiempo entrenado</div>
              <div className="font-mono text-2xl font-bold leading-none text-tide-text">{formatTime(elapsedSeconds)}</div>
            </div>
          </div>
        )}

        <div className="mb-4">
          <label className="flex items-center gap-2 text-xs font-bold text-tide-text mb-2">
            <Heart className="w-3.5 h-3.5 text-tide-red fill-tide-red" />
            Frecuencia cardíaca promedio
          </label>
          <div className="relative">
            <input
              type="number"
              inputMode="numeric"
              value={avgHR}
              onChange={(e) => setAvgHR(e.target.value)}
              placeholder="ej: 145"
              className="w-full px-4 py-3 bg-tide-surface-2 border border-tide-border rounded-xl text-base font-mono font-bold text-tide-text focus:outline-none focus:border-tide-lime transition-colors"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-tide-muted font-bold">ppm</span>
          </div>
        </div>

        <div className="mb-4">
          <label className="flex items-center gap-2 text-xs font-bold text-tide-text mb-2">
            <Flame className="w-3.5 h-3.5 text-tide-amber fill-tide-amber" />
            Calorías quemadas
          </label>
          <div className="relative">
            <input
              type="number"
              inputMode="numeric"
              value={calories}
              onChange={(e) => setCalories(e.target.value)}
              placeholder="ej: 480"
              className="w-full px-4 py-3 bg-tide-surface-2 border border-tide-border rounded-xl text-base font-mono font-bold text-tide-text focus:outline-none focus:border-tide-lime transition-colors"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-tide-muted font-bold">kcal</span>
          </div>
        </div>

        <div className="mb-4">
          <label className="block text-xs font-bold text-tide-text mb-2">¿Cómo lo sentiste?</label>
          <div className="grid grid-cols-4 gap-2">
            {feelOptions.map(opt => (
              <button
                key={opt.value}
                onClick={() => setFeel(opt.value)}
                className={`py-2.5 rounded-xl text-center transition-all border-2 ${
                  feel === opt.value
                    ? opt.color
                    : 'bg-tide-surface-2 border-transparent text-tide-dim'
                }`}
              >
                <div className="text-xl mb-0.5">{opt.label}</div>
                <div className="text-[9px] font-bold uppercase tracking-wider">{opt.text}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="mb-5">
          <label className="block text-xs font-bold text-tide-text mb-2">Notas <span className="text-tide-muted font-normal">(opcional)</span></label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="ej: subí 2.5kg en bench, llegué a 4 rondas..."
            rows={3}
            className="w-full px-4 py-3 bg-tide-surface-2 border border-tide-border rounded-xl text-sm text-tide-text focus:outline-none focus:border-tide-lime transition-colors resize-none"
          />
        </div>

        <div className="flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 py-3 bg-tide-surface-3 text-tide-dim font-bold rounded-xl active:scale-[0.98] transition-transform"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-3 bg-tide-lime text-tide-bg font-bold rounded-xl active:scale-[0.98] transition-transform"
            style={{ boxShadow: '0 0 16px rgba(200,255,0,0.4)' }}
          >
            Guardar
          </button>
        </div>
      </div>
    </div>
  )
}
