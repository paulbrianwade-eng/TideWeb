import { useState, useEffect } from 'react'
import { X, TrendingUp, TrendingDown, Minus, Repeat } from 'lucide-react'
import { getLastLoad, saveLoad, computeDiff } from '../data/loads'

export default function WeightLogModal({ exercise, onClose, onSaved }) {
  const lastLoad = getLastLoad(exercise.id)
  const [weight, setWeight] = useState('')
  const [reps, setReps] = useState(lastLoad ? String(lastLoad.reps) : '')
  const [diff, setDiff] = useState(null)

  useEffect(() => {
    if (weight && lastLoad) {
      setDiff(computeDiff(lastLoad.weight, lastLoad.reps, parseFloat(weight), parseInt(reps) || 0))
    } else {
      setDiff(null)
    }
  }, [weight, reps, lastLoad])

  function handleUseLast() {
    if (lastLoad) {
      setWeight(String(lastLoad.weight))
      setReps(String(lastLoad.reps))
    }
  }

  function handleSave() {
    if (!weight) return
    saveLoad(exercise.id, weight, reps || 0)
    onSaved()
  }

  function handleSkip() {
    onSaved()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-tide-bg/90 backdrop-blur-sm">
      <div className="bg-tide-surface border-t border-tide-border sm:border w-full max-w-[440px] rounded-t-3xl sm:rounded-3xl p-6 max-h-[92vh] overflow-y-auto animate-slide-up">
        <div className="flex items-center justify-between mb-3">
          <span className="text-[10px] font-bold text-tide-muted tracking-wider uppercase">Registrar carga</span>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-tide-surface-3 flex items-center justify-center">
            <X className="w-4 h-4 text-tide-dim" />
          </button>
        </div>

        <h3 className="font-display text-xl mb-1 text-tide-text leading-tight">{exercise.name}</h3>
        {exercise.reps && (
          <p className="text-xs text-tide-dim mb-5 font-medium">Objetivo: {exercise.reps}</p>
        )}

        {lastLoad && (
          <div className="bg-tide-bg border border-tide-border rounded-xl p-3 mb-5 flex items-center justify-between">
            <div>
              <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-0.5">Última vez</div>
              <div className="font-mono text-sm font-bold text-tide-text">
                {lastLoad.weight} kg × {lastLoad.reps}
              </div>
              <div className="text-[10px] text-tide-muted mt-0.5">
                {new Date(lastLoad.date).toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })}
              </div>
            </div>
            <button
              onClick={handleUseLast}
              className="flex items-center gap-1.5 bg-tide-lime/15 text-tide-lime text-xs font-bold px-3 py-2 rounded-lg active:scale-95 transition-transform"
            >
              <Repeat className="w-3.5 h-3.5" strokeWidth={2.5} />
              Usar
            </button>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="block text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-1.5">Peso (kg)</label>
            <input
              type="number"
              inputMode="decimal"
              step="0.5"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              placeholder="0"
              autoFocus
              className="w-full px-4 py-3 bg-tide-surface-2 border border-tide-border rounded-xl text-lg font-mono font-bold text-tide-text focus:outline-none focus:border-tide-lime transition-colors"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-1.5">Reps</label>
            <input
              type="number"
              inputMode="numeric"
              value={reps}
              onChange={(e) => setReps(e.target.value)}
              placeholder="0"
              className="w-full px-4 py-3 bg-tide-surface-2 border border-tide-border rounded-xl text-lg font-mono font-bold text-tide-text focus:outline-none focus:border-tide-lime transition-colors"
            />
          </div>
        </div>

        {diff && (
          <div className={`mb-5 p-3 rounded-xl flex items-center gap-2 ${
            diff.direction === 'up'
              ? 'bg-tide-green/12 text-tide-green'
              : diff.direction === 'down'
                ? 'bg-tide-amber/12 text-tide-amber'
                : 'bg-tide-surface-3 text-tide-dim'
          }`}>
            {diff.direction === 'up' && <TrendingUp className="w-4 h-4" strokeWidth={2.5} />}
            {diff.direction === 'down' && <TrendingDown className="w-4 h-4" strokeWidth={2.5} />}
            {diff.direction === 'same' && <Minus className="w-4 h-4" strokeWidth={2.5} />}
            <span className="text-xs font-bold">
              {diff.direction === 'up' ? '+' : ''}{diff.diff} kg ({diff.direction === 'up' ? '+' : ''}{diff.pct}%) vs última vez
            </span>
          </div>
        )}

        <div className="flex gap-2">
          <button
            onClick={handleSkip}
            className="flex-1 py-3 bg-tide-surface-3 text-tide-dim font-bold rounded-xl active:scale-[0.98] transition-transform"
          >
            Saltar
          </button>
          <button
            onClick={handleSave}
            disabled={!weight}
            className="flex-1 py-3 bg-tide-lime text-tide-bg font-bold rounded-xl active:scale-[0.98] transition-transform disabled:opacity-40 disabled:cursor-not-allowed"
            style={{ boxShadow: weight ? '0 0 16px rgba(200,255,0,0.4)' : 'none' }}
          >
            Guardar
          </button>
        </div>
      </div>
    </div>
  )
}
