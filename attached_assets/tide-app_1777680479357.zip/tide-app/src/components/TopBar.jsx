import TideLogo from './TideLogo'
import { Flame } from 'lucide-react'

export default function TopBar({ streak = 0 }) {
  return (
    <div className="px-5 pt-4 pb-3 flex items-center justify-between bg-tide-bg sticky top-0 z-30">
      <TideLogo size="md" />
      {streak > 0 && (
        <div className="flex items-center gap-1.5 bg-tide-surface border border-tide-border px-3 py-1.5 rounded-full">
          <Flame className="w-3.5 h-3.5 text-tide-amber fill-tide-amber" />
          <span className="text-xs font-bold text-tide-text">{streak} días</span>
        </div>
      )}
    </div>
  )
}
