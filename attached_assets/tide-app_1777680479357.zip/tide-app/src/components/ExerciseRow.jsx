import { Check, TrendingUp } from 'lucide-react'
import { getLastLoad, isWeightedExercise } from '../data/loads'
import { useState, useEffect } from 'react'

export default function ExerciseRow({ exercise, isChecked, isNext, onToggle }) {
  const [lastLoad, setLastLoad] = useState(null)
  const isWeighted = isWeightedExercise(exercise)

  useEffect(() => {
    if (isWeighted) {
      setLastLoad(getLastLoad(exercise.id))
    }
  }, [exercise.id, isWeighted, isChecked])

  return (
    <div
      data-exercise-id={exercise.id}
      data-checked={isChecked}
      onClick={onToggle}
      className={`px-5 py-3 flex gap-3 border-b border-tide-surface-3 last:border-b-0 cursor-pointer transition-all ${
        isNext ? 'bg-tide-lime/5 border-l-2 border-l-tide-lime' : ''
      }`}
    >
      <div className={`w-[22px] h-[22px] mt-0.5 rounded-md flex-shrink-0 flex items-center justify-center transition-all ${
        isChecked
          ? 'bg-tide-lime border-2 border-tide-lime'
          : 'bg-transparent border-2 border-tide-surface-3'
      }`}>
        {isChecked && <Check className="w-3.5 h-3.5 text-tide-bg" strokeWidth={3.5} />}
      </div>

      <div className="flex-1 min-w-0">
        <div className={`font-semibold text-sm mb-1 leading-tight ${
          isChecked ? 'text-tide-muted line-through' : 'text-tide-text'
        }`}>
          {exercise.name}
        </div>

        <div className="flex flex-wrap gap-1.5 mb-1.5">
          {exercise.reps && (
            <span className="bg-tide-lime/15 text-tide-lime text-[10px] font-bold font-mono px-2 py-0.5 rounded">
              {exercise.reps}
            </span>
          )}
          {exercise.rest && (
            <span className="bg-tide-surface-3 text-tide-dim text-[10px] font-bold font-mono px-2 py-0.5 rounded">
              ⏸ {exercise.rest}
            </span>
          )}
          {exercise.target && (
            <span className="bg-tide-amber/15 text-tide-amber text-[10px] font-bold font-mono px-2 py-0.5 rounded">
              {exercise.target}
            </span>
          )}
          {lastLoad && (
            <span className="bg-tide-green/12 text-tide-green text-[10px] font-bold font-mono px-2 py-0.5 rounded flex items-center gap-1">
              <TrendingUp className="w-2.5 h-2.5" strokeWidth={2.5} />
              {lastLoad.weight} kg × {lastLoad.reps}
            </span>
          )}
        </div>

        {exercise.detail && (
          <div className="text-[11px] text-tide-muted leading-relaxed">{exercise.detail}</div>
        )}
      </div>
    </div>
  )
}
