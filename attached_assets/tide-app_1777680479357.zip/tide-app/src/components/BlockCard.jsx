import { useState } from 'react'
import { Timer, Play, Pause, RotateCcw, SkipForward, ChevronRight } from 'lucide-react'
import ExerciseRow from './ExerciseRow'
import { useCountdown, formatTime, beep } from './timerHooks'
import { useEffect, useRef } from 'react'

const blockTagConfig = {
  warmup:   { tag: 'CALENT.', color: 'bg-tide-dim/15 text-tide-dim' },
  strength: { tag: 'FUERZA',  color: 'bg-tide-red/15 text-[#FF7A7A]' },
  metcon:   { tag: 'METCON',  color: 'bg-tide-amber/15 text-tide-amber' },
  finisher: { tag: 'FINISH.', color: 'bg-[#A050DC]/15 text-[#C794FF]' },
  quality:  { tag: 'CALIDAD', color: 'bg-tide-lime/15 text-tide-lime' },
  run:      { tag: 'RUN',     color: 'bg-tide-amber/15 text-tide-amber' },
}

function parseDurationToSeconds(duration) {
  if (typeof duration === 'number') return duration * 60
  return 0
}

export default function BlockCard({
  block, checks, onToggle, onSkipBlock, isSkipped, sessionStarted, nextExerciseId
}) {
  const cfg = blockTagConfig[block.type] || blockTagConfig.metcon
  const hasTimer = block.type === 'metcon' || block.type === 'strength' || block.type === 'finisher'
  const totalSeconds = parseDurationToSeconds(block.duration)

  const [timerRunning, setTimerRunning] = useState(false)
  const [timerStarted, setTimerStarted] = useState(false)
  const { seconds, addSeconds, resetTo } = useCountdown(totalSeconds, timerRunning)
  const beepedRef = useRef(false)

  useEffect(() => {
    if (timerStarted && seconds <= 0 && !beepedRef.current) {
      beep()
      beepedRef.current = true
      setTimerRunning(false)
    }
    if (seconds > 1) beepedRef.current = false
  }, [seconds, timerStarted])

  function startTimer() {
    if (!timerStarted) {
      resetTo(totalSeconds)
      setTimerStarted(true)
    }
    setTimerRunning(true)
  }

  function resetTimer() {
    resetTo(totalSeconds)
    setTimerRunning(false)
    setTimerStarted(false)
    beepedRef.current = false
  }

  if (isSkipped) {
    return (
      <div className="mx-5 mb-3 bg-tide-surface/50 border border-tide-surface-3 border-dashed rounded-2xl px-4 py-3 flex items-center justify-between">
        <div>
          <span className={`inline-block ${cfg.color} text-[9px] font-extrabold tracking-wider px-2 py-0.5 rounded mb-1`}>
            {cfg.tag}
          </span>
          <div className="text-sm text-tide-muted line-through">{block.title}</div>
        </div>
        <span className="text-[10px] text-tide-muted font-bold tracking-wider">SALTADO</span>
      </div>
    )
  }

  return (
    <div className="mx-5 mb-3 bg-tide-surface border border-tide-border rounded-2xl overflow-hidden">
      <div className="px-5 pt-4 pb-3 border-b border-tide-border flex items-start gap-3">
        <div className="flex-1 min-w-0">
          <span className={`inline-block ${cfg.color} text-[9px] font-extrabold tracking-wider px-2 py-0.5 rounded mb-1.5`}>
            {cfg.tag}
          </span>
          <div className="font-display text-base text-tide-text leading-tight mb-0.5">{block.title}</div>
          {block.format && (
            <div className="text-[11px] text-tide-dim italic font-medium">{block.format}</div>
          )}
        </div>
        {block.duration > 0 && (
          <div className="bg-tide-bg rounded-lg px-2.5 py-1 flex-shrink-0">
            <span className="font-display text-sm text-tide-lime">{block.duration}'</span>
          </div>
        )}
      </div>

      {hasTimer && sessionStarted && totalSeconds > 0 && (
        <div className="mx-4 mt-3 bg-tide-bg rounded-xl px-3 py-2.5 flex items-center gap-3">
          <button
            onClick={timerRunning ? () => setTimerRunning(false) : startTimer}
            className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 active:scale-95 transition-transform ${
              timerRunning ? 'bg-tide-amber' : 'bg-tide-lime'
            }`}
            style={{ boxShadow: timerRunning ? '0 0 14px rgba(255,184,0,0.4)' : '0 0 14px rgba(200,255,0,0.4)' }}
          >
            {timerRunning
              ? <Pause className="w-4 h-4 text-tide-bg" strokeWidth={2.5} fill="currentColor" />
              : <Play className="w-4 h-4 text-tide-bg" strokeWidth={2.5} fill="currentColor" />
            }
          </button>
          <div className="flex-1 min-w-0">
            <div className="text-[9px] font-bold tracking-wider text-tide-muted uppercase">
              {timerRunning ? 'En curso' : timerStarted ? 'En pausa' : 'Bloque'}
            </div>
            <div className="font-mono text-xl font-bold text-tide-text leading-none">
              {formatTime(Math.max(0, seconds))}
            </div>
          </div>
          {timerStarted && (
            <button
              onClick={resetTimer}
              className="w-8 h-8 rounded-full bg-tide-surface-3 flex items-center justify-center flex-shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5 text-tide-dim" strokeWidth={2.5} />
            </button>
          )}
        </div>
      )}

      <div className="mt-2">
        {block.exercises.map(ex => (
          <ExerciseRow
            key={ex.id}
            exercise={ex}
            isChecked={!!checks[ex.id]}
            isNext={ex.id === nextExerciseId}
            onToggle={() => onToggle(ex.id)}
          />
        ))}
      </div>

      {sessionStarted && block.type !== 'warmup' && block.type !== 'quality' && (
        <button
          onClick={onSkipBlock}
          className="w-full text-[11px] text-tide-muted font-medium py-2.5 border-t border-tide-surface-3 flex items-center justify-center gap-1 hover:text-tide-dim transition-colors"
        >
          <SkipForward className="w-3 h-3" />
          Saltar este bloque
        </button>
      )}
    </div>
  )
}
