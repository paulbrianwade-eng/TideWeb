import { useMemo } from 'react'
import TopBar from '../components/TopBar'
import StreakCard from '../components/StreakCard'
import DayCard from '../components/DayCard'
import { week } from '../data/routine'
import { Clock, Target, Zap } from 'lucide-react'

export default function HomePage({ onSelectDay, completedDays, history, currentDayId }) {
  const todayDay = week.find(d => d.id === currentDayId) || week[0]

  const orderedWeek = useMemo(() => {
    const idx = week.findIndex(d => d.id === currentDayId)
    if (idx <= 0) return week
    return [...week.slice(idx), ...week.slice(0, idx)]
  }, [currentDayId])

  // Stats últimos 7 días
  const last7d = history.filter(h => {
    const diff = (Date.now() - new Date(h.date).getTime()) / (1000 * 60 * 60 * 24)
    return diff < 7
  })
  const totalKcal7d = last7d.reduce((sum, h) => sum + (h.calories || 0), 0)
  const validHR = last7d.filter(h => h.avgHR)
  const avgHR7d = validHR.length > 0
    ? Math.round(validHR.reduce((sum, h) => sum + h.avgHR, 0) / validHR.length)
    : null

  const weekTrainings = week.filter(d => d.type !== 'rest').length
  const completedThisWeek = completedDays.length

  return (
    <div className="min-h-screen bg-tide-bg pb-32">
      <TopBar streak={completedDays.length} />

      {/* Hero objetivo activo */}
      <div className="mx-5 mb-5 relative rounded-3xl overflow-hidden gradient-hero border border-tide-border p-6">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: 'radial-gradient(circle at top right, rgba(200,255,0,0.18), transparent 60%)' }}
        />
        <div className="relative">
          <div className="text-[11px] font-bold tracking-widest text-tide-dim mb-2 uppercase">
            Objetivo activo
          </div>
          <div className="flex items-baseline gap-2.5 mb-4">
            <span
              className="font-display text-6xl leading-none"
              style={{
                background: 'linear-gradient(180deg, #C8FF00 0%, #94C100 100%)',
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              {completedThisWeek}
            </span>
            <span className="text-sm font-semibold text-tide-dim">
              / {weekTrainings} entrenos esta sem.
            </span>
          </div>
          <div className="text-[13px] text-tide-dim font-medium">
            Definición · Mantener fuerza · Bajar grasa
          </div>

          <div className="flex gap-4 mt-4 pt-4 border-t border-white/5">
            <div className="flex-1">
              <div className="text-[10px] font-bold tracking-wider text-tide-muted uppercase mb-0.5">Cal · 7d</div>
              <div className="font-mono text-base font-bold text-tide-text">
                {totalKcal7d > 0 ? totalKcal7d.toLocaleString('es-AR') : '—'}
              </div>
            </div>
            <div className="flex-1">
              <div className="text-[10px] font-bold tracking-wider text-tide-muted uppercase mb-0.5">FC prom</div>
              <div className="font-mono text-base font-bold text-tide-text">
                {avgHR7d || '—'}
              </div>
            </div>
            <div className="flex-1">
              <div className="text-[10px] font-bold tracking-wider text-tide-muted uppercase mb-0.5">Sesiones</div>
              <div className="font-mono text-base font-bold text-tide-text">
                {last7d.length}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Strike */}
      <div className="mb-5">
        <StreakCard
          completedDays={completedDays}
          todayId={currentDayId}
          onDayClick={onSelectDay}
        />
      </div>

      {/* Slider de días */}
      <div className="px-5 mb-2 flex items-center justify-between">
        <h2 className="font-display text-lg text-tide-text">Esta semana</h2>
        <span className="text-[11px] text-tide-muted font-medium">Deslizá →</span>
      </div>
      <div className="snap-cards no-scrollbar overflow-x-auto flex gap-3 px-5 pb-5">
        {orderedWeek.map(day => (
          <div key={day.id} className="flex-shrink-0 w-[78%]">
            <DayCard
              day={day}
              onClick={() => onSelectDay(day.id)}
              isCompleted={completedDays.includes(day.id)}
              isToday={day.id === currentDayId}
            />
          </div>
        ))}
      </div>

      {/* Today CTA */}
      {todayDay && (
        <div className="mx-5 bg-gradient-to-br from-tide-surface to-tide-surface-2 border border-tide-border rounded-3xl overflow-hidden relative">
          <div
            className="absolute top-0 left-0 right-0 h-[3px]"
            style={{ background: 'linear-gradient(90deg, #C8FF00 0%, #FFB800 100%)' }}
          />
          <div className="p-5 pt-6">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-tide-lime" style={{ boxShadow: '0 0 8px #C8FF00' }} />
                <span className="text-xs font-bold text-tide-text tracking-wider uppercase">Hoy · {todayDay.name}</span>
              </div>
              {todayDay.type === 'bigg' && (
                <span className="text-[10px] font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-tide-green/12 text-tide-green border border-tide-green/25 uppercase">
                  Hybrid
                </span>
              )}
              {todayDay.type === 'run' && (
                <span className="text-[10px] font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-tide-amber/12 text-tide-amber border border-tide-amber/25 uppercase">
                  Cardio
                </span>
              )}
              {todayDay.type === 'rest' && (
                <span className="text-[10px] font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-tide-dim/12 text-tide-dim border border-tide-dim/25 uppercase">
                  Recovery
                </span>
              )}
            </div>
            <h3 className="font-display text-2xl text-tide-text leading-tight mb-1.5">{todayDay.title}</h3>
            <div className="flex items-center gap-3 text-[13px] text-tide-dim font-medium mb-4">
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-tide-lime" /> {todayDay.duration} min
              </span>
              <span className="flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-tide-lime" /> {todayDay.subtitle}
              </span>
            </div>

            <button
              onClick={() => onSelectDay(todayDay.id)}
              className="w-full bg-tide-lime text-tide-bg font-extrabold py-4 rounded-2xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform tracking-wide uppercase text-sm"
              style={{ boxShadow: '0 8px 24px rgba(200,255,0,0.3)' }}
            >
              <Zap className="w-4 h-4" strokeWidth={3} fill="currentColor" />
              {completedDays.includes(todayDay.id) ? 'Ver entrenamiento' : 'Ver detalles'}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
