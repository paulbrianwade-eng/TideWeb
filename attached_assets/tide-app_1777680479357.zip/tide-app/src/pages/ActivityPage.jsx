import { Clock, Heart, Flame, Activity, Trash2 } from 'lucide-react'

const feelEmojis = {
  easy: { emoji: '😎', text: 'Fácil', color: 'bg-tide-green/12 text-tide-green' },
  moderate: { emoji: '😅', text: 'Moderado', color: 'bg-tide-amber/12 text-tide-amber' },
  hard: { emoji: '🥵', text: 'Duro', color: 'bg-orange-500/15 text-orange-300' },
  brutal: { emoji: '💀', text: 'Brutal', color: 'bg-tide-red/12 text-[#FF8080]' },
}

function formatDate(iso) {
  const d = new Date(iso)
  const now = new Date()
  const diffMs = now - d
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))

  if (diffDays === 0) return `Hoy · ${d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}`
  if (diffDays === 1) return `Ayer · ${d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}`
  if (diffDays < 7) {
    const days = ['DOM', 'LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB']
    return `${days[d.getDay()]} · ${d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}`
  }
  return d.toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })
}

function groupByPeriod(history) {
  const now = Date.now()
  const groups = { 'Esta semana': [], 'Anteriores': [] }
  history.forEach(h => {
    const diffDays = (now - new Date(h.date).getTime()) / (1000 * 60 * 60 * 24)
    if (diffDays < 7) groups['Esta semana'].push(h)
    else groups['Anteriores'].push(h)
  })
  return groups
}

export default function ActivityPage({ history, onDelete }) {
  const sorted = [...history].sort((a, b) => new Date(b.date) - new Date(a.date))
  const grouped = groupByPeriod(sorted)

  // Stats últimos 7 días
  const last7d = sorted.filter(h => (Date.now() - new Date(h.date).getTime()) / (1000 * 60 * 60 * 24) < 7)
  const totalMin = last7d.reduce((s, h) => s + (h.duration || 0), 0)
  const totalKcal = last7d.reduce((s, h) => s + (h.calories || 0), 0)
  const validHR = last7d.filter(h => h.avgHR)
  const avgHR = validHR.length ? Math.round(validHR.reduce((s, h) => s + h.avgHR, 0) / validHR.length) : null

  return (
    <div className="min-h-screen bg-tide-bg pb-32">
      <div className="px-5 pt-6 pb-4">
        <h1 className="font-display text-3xl text-tide-text mb-1">Actividad</h1>
        <p className="text-xs text-tide-dim font-medium">Tu historial completo</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-2.5 px-5 mb-5">
        <div className="bg-tide-surface border border-tide-border rounded-2xl p-4">
          <div className="w-7 h-7 rounded-lg bg-tide-bg flex items-center justify-center mb-2">
            <Activity className="w-4 h-4 text-tide-lime" strokeWidth={2.2} />
          </div>
          <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-1">Esta semana</div>
          <div className="font-display text-2xl text-tide-text flex items-baseline gap-1.5">
            {last7d.length}
            <span className="text-[11px] font-semibold text-tide-dim">entrenos</span>
          </div>
        </div>
        <div className="bg-tide-surface border border-tide-border rounded-2xl p-4">
          <div className="w-7 h-7 rounded-lg bg-tide-bg flex items-center justify-center mb-2">
            <Clock className="w-4 h-4 text-tide-lime" strokeWidth={2.2} />
          </div>
          <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-1">Tiempo total</div>
          <div className="font-display text-2xl text-tide-text flex items-baseline gap-1.5">
            {totalMin}
            <span className="text-[11px] font-semibold text-tide-dim">min</span>
          </div>
        </div>
        <div className="bg-tide-surface border border-tide-border rounded-2xl p-4">
          <div className="w-7 h-7 rounded-lg bg-tide-bg flex items-center justify-center mb-2">
            <Flame className="w-4 h-4 text-tide-amber" fill="currentColor" />
          </div>
          <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-1">Calorías</div>
          <div className="font-display text-2xl text-tide-text flex items-baseline gap-1.5">
            {totalKcal > 0 ? totalKcal.toLocaleString('es-AR') : '0'}
            <span className="text-[11px] font-semibold text-tide-dim">kcal</span>
          </div>
        </div>
        <div className="bg-tide-surface border border-tide-border rounded-2xl p-4">
          <div className="w-7 h-7 rounded-lg bg-tide-bg flex items-center justify-center mb-2">
            <Heart className="w-4 h-4 text-tide-red" fill="currentColor" />
          </div>
          <div className="text-[10px] font-bold text-tide-muted tracking-wider uppercase mb-1">FC promedio</div>
          <div className="font-display text-2xl text-tide-text flex items-baseline gap-1.5">
            {avgHR || '—'}
            <span className="text-[11px] font-semibold text-tide-dim">{avgHR ? 'ppm' : ''}</span>
          </div>
        </div>
      </div>

      {/* Historial */}
      {sorted.length === 0 ? (
        <div className="mx-5 bg-tide-surface border border-tide-border rounded-2xl p-8 text-center">
          <p className="text-tide-dim text-sm">Todavía no entrenaste.</p>
          <p className="text-tide-muted text-xs mt-1">Tu primer entreno va a aparecer acá.</p>
        </div>
      ) : (
        Object.entries(grouped).map(([period, items]) => items.length > 0 && (
          <div key={period} className="mb-4">
            <div className="px-5 mb-2.5 text-[10px] font-bold text-tide-muted tracking-wider uppercase">{period}</div>
            <div className="px-5 space-y-2.5">
              {items.map(h => (
                <div key={h.date} className="bg-tide-surface border border-tide-border rounded-2xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-[9px] font-extrabold tracking-wider px-2 py-1 rounded uppercase ${
                      h.type === 'bigg' ? 'bg-tide-lime text-tide-bg' :
                      h.type === 'run' ? 'bg-tide-amber text-tide-bg' :
                      'bg-tide-dim text-tide-bg'
                    }`}>
                      {h.type === 'bigg' ? 'HYBRID' : h.type === 'run' ? 'RUN' : 'REST'}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] text-tide-muted font-bold">{formatDate(h.date)}</span>
                      <button
                        onClick={() => {
                          if (confirm('¿Eliminar este registro?')) onDelete(h.date)
                        }}
                        className="text-tide-muted hover:text-tide-red transition-colors p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="font-bold text-sm text-tide-text mb-2.5">{h.dayTitle || h.dayName}</div>
                  <div className="flex flex-wrap gap-1.5">
                    <span className="bg-tide-bg border border-tide-border px-2 py-1 rounded-md text-[11px] font-mono font-bold text-tide-text flex items-center gap-1">
                      <Clock className="w-3 h-3 text-tide-lime" />
                      {h.duration} min
                    </span>
                    {h.avgHR && (
                      <span className="bg-tide-bg border border-tide-border px-2 py-1 rounded-md text-[11px] font-mono font-bold text-tide-text flex items-center gap-1">
                        <Heart className="w-3 h-3 text-tide-red" fill="currentColor" />
                        {h.avgHR} ppm
                      </span>
                    )}
                    {h.calories && (
                      <span className="bg-tide-bg border border-tide-border px-2 py-1 rounded-md text-[11px] font-mono font-bold text-tide-text flex items-center gap-1">
                        <Flame className="w-3 h-3 text-tide-amber" fill="currentColor" />
                        {h.calories} kcal
                      </span>
                    )}
                    {h.feel && feelEmojis[h.feel] && (
                      <span className={`px-2 py-1 rounded-md text-[11px] font-bold flex items-center gap-1 ${feelEmojis[h.feel].color}`}>
                        {feelEmojis[h.feel].emoji} {feelEmojis[h.feel].text}
                      </span>
                    )}
                  </div>
                  {h.notes && (
                    <div className="mt-3 pt-3 border-t border-tide-surface-3 text-[12px] text-tide-dim italic leading-relaxed">
                      "{h.notes}"
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  )
}
