# TIDE — Hybrid Training App

App mobile-first para entrenamiento híbrido (fuerza + cardio + KB) adaptada a equipo de gimnasio en casa.

## Cómo correr en Replit

1. Crear un Repl nuevo (Node.js)
2. Pegar todos estos archivos manteniendo la estructura
3. Click en **Run** (instala deps y levanta el dev server)
4. Abrir la URL del webview

## Cómo correr local

```bash
npm install
npm run dev
```

## Stack

- React 18 + Vite
- Tailwind CSS
- lucide-react

## Features

- **Home**: objetivo activo, strike semanal, slider de días, CTA del día
- **Day Detail**: hero con foto, resumen pre-entreno, cronómetro de sesión, bloques con timer regresivo, skip block
- **Tracking de cargas**: registra peso/reps por ejercicio, compara vs última vez
- **Timer de descanso**: countdown circular con beep + vibración
- **Actividad**: stats semanales, historial completo con FC/cal/feel/notas
- **Persistencia**: todo en localStorage (no hay backend)

## Storage

- `tide_checks_v1` — ejercicios marcados (se limpian al finalizar)
- `tide_history_v1` — historial de entrenamientos
- `tide_loads_v1` — historial de cargas por ejercicio
