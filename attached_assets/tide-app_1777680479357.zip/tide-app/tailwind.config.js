/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        tide: {
          bg: '#07090C',
          surface: '#11151B',
          'surface-2': '#1A1F27',
          'surface-3': '#232A34',
          border: '#252B36',
          text: '#F1F5F9',
          dim: '#8B92A0',
          muted: '#4F5663',
          lime: '#C8FF00',
          'lime-dim': '#94C100',
          amber: '#FFB800',
          red: '#FF4D4D',
          green: '#21D07A',
        }
      },
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'system-ui', 'sans-serif'],
        display: ['"Archivo Black"', 'Impact', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
    },
  },
  plugins: [],
}
