/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: '#0B0D0F',
        night: '#0B0D0F',
        surface: '#15191D',
        surface2: '#20252A',
        line: '#2C3238',
        ink: '#F5F7F8',
        muted: '#A5ADB4',
        accent: '#C7F000',
        warn: '#FFB547',
        danger: '#FF6464',
        success: '#56D68A',
        foam: '#58E0C8',
        deep: '#0E2A33',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'Inter', 'system-ui', 'sans-serif'],
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      boxShadow: {
        card: '0 1px 0 0 rgba(255,255,255,0.03) inset, 0 12px 30px -18px rgba(0,0,0,0.9)',
      },
      borderRadius: { xl2: '1.25rem' },
    },
  },
  plugins: [],
};
