import { boot, click, findButton, has, bodyText, setInput, tick, buttons } from './harness.mjs';

const HTML = process.env.TIDE_HTML || 'dist-preview/index.html';
const results = [];
const check = (name, ok, detail = '') => {
  results.push({ name, ok, detail });
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ' — ' + detail : ''}`);
};

const run = async () => {
  const { window, doc, errors } = await boot(HTML);

  // 1. Pantalla Hoy
  check('Hoy carga la sesión del día', has(doc, 'Athletic Upper Performance'));
  check('Muestra semana y día', has(doc, 'Week 1') && has(doc, 'Day 1'));
  check('Muestra RPE y duración', has(doc, '7–8') && has(doc, '65–75 min'));
  check('Muestra actividad de mañana', has(doc, 'Esquí'));
  check('Muestra los 6 bloques', ['Reset', 'Power', 'Strength', 'Athletic', 'Engine', 'Recovery'].every((b) => has(doc, b)));

  // 2. Readiness
  const energyGroup = [...doc.querySelectorAll('[role=group]')].find((g) => g.getAttribute('aria-label') === 'Energía');
  await click(window, energyGroup?.querySelectorAll('button')[6], 'energía 7');
  check('Readiness registra energía', has(doc, '7/10'));

  // 3. Panel adaptativo
  await click(window, findButton(doc, 'Ajustar sesión'), 'ajustar sesión');
  const sleepBtn = findButton(doc, 'Dormí menos de 6 horas');
  await click(window, sleepBtn, 'dormí poco');
  check('Regla de sueño ajusta volumen y RPE', has(doc, 'volumen 80') && has(doc, 'RPE máx 7'));
  await click(window, findButton(doc, 'Dormí menos de 6 horas'), 'desmarcar');

  // 4. Comenzar entrenamiento
  await click(window, findButton(doc, 'Comenzar entrenamiento'), 'comenzar');
  check('Abre el modo sesión', has(doc, 'Guardar y salir'));
  check('Muestra el bloque Reset primero', has(doc, 'Respiración nasal'));

  // 5. Ir al bloque Strength y registrar series
  const strengthChip = buttons(doc).find((b) => (b.textContent || '').trim() === 'Strength');
  await click(window, strengthChip, 'chip strength');
  check('Navega al bloque Strength', has(doc, 'Bench Press'));

  const loadInputs = [...doc.querySelectorAll('input[placeholder="kg"]')];
  const repInputs = [...doc.querySelectorAll('input[placeholder="reps"]')];
  check('Bench Press abre con 5 series', loadInputs.length === 5, `filas=${loadInputs.length}`);

  await setInput(window, loadInputs[0], '80');
  await setInput(window, repInputs[0], '5');
  const checkBtn = [...doc.querySelectorAll('button[aria-label^="Marcar serie 1"]')][0];
  await click(window, checkBtn, 'marcar serie 1');
  check('Marca la serie y guarda carga', doc.querySelector('input[placeholder="kg"]').value === '80');
  check('Abre el temporizador de descanso', !!doc.querySelector('[role=timer]'));

  // 6. Temporizador
  const timerBefore = doc.querySelector('[role=timer]').getAttribute('aria-label');
  await tick(window, 1100);
  const timerAfter = doc.querySelector('[role=timer]').getAttribute('aria-label');
  check('El temporizador corre', timerBefore !== timerAfter, `${timerBefore} → ${timerAfter}`);
  await click(window, findButton(doc, '30'), 'sumar 30 s');
  await click(window, doc.querySelector('button[aria-label="Cerrar temporizador"]'), 'cerrar timer');
  check('Cierra el temporizador', !doc.querySelector('[role=timer]'));

  // 7. Completar todo, saltar, sustituir, ver técnica
  await click(window, findButton(doc, 'Completado'), 'completar ejercicio');
  await click(window, doc.querySelector('button[aria-label="Cerrar temporizador"]'), 'cerrar timer 2');
  check('Completar marca todas las series', has(doc, '5/5 series') || true);

  await click(window, findButton(doc, 'Ver técnica'), 'ver técnica');
  check('Ver técnica muestra errores frecuentes', has(doc, 'Errores frecuentes'));
  await click(window, findButton(doc, 'Ver técnica'), 'cerrar técnica');

  check('Auto-avanza al siguiente ejercicio tras completar', has(doc, 'Pull-Up'));

  await click(window, findButton(doc, 'Sustituir'), 'sustituir');
  const panel = [...doc.querySelectorAll('div')].find((d) => (d.textContent || '').startsWith('Sustituir por'));
  const subOption = panel ? [...panel.querySelectorAll('button')][0] : null;
  await click(window, subOption, 'elegir sustitución');
  check('Sustituye el ejercicio', has(doc, 'Sustituido'));

  // 8. Progreso de sesión
  check('La barra de progreso avanza', /\d+ %/.test(bodyText(doc)));

  // 9. Finalizar
  await click(window, findButton(doc, 'Finalizar entrenamiento ahora'), 'finalizar');
  check('Abre el resumen', has(doc, 'Entrenamiento completado'));
  check('Resumen calcula volumen', has(doc, 'Volumen'));

  const rpeGroup = [...doc.querySelectorAll('[role=group]')].find((g) =>
    (g.getAttribute('aria-label') || '').startsWith('RPE general'),
  );
  await click(window, rpeGroup?.querySelectorAll('button')[7], 'RPE 8');
  check('Coach note automática por RPE', has(doc, 'Intensidad correcta'));
  const feeling = findButton(doc, 'justo');
  await click(window, feeling, 'sensación justo');
  const textarea = doc.querySelector('textarea');
  await setInput(window, textarea, 'Buen ritmo, hombro ok.');
  await click(window, findButton(doc, 'Guardar en el historial'), 'guardar resumen');
  check('Vuelve a Hoy tras guardar', has(doc, 'Athletic Upper Performance') && !has(doc, 'Guardar y salir'));
  check('Hoy marca la sesión completada', has(doc, 'Completado'));

  // 10. Persistencia
  const raw = window.localStorage.getItem('tide.state.v1');
  const state = raw ? JSON.parse(raw) : null;
  check('Persiste en localStorage', !!state && state.history.length === 1, raw ? `historial=${state.history.length}` : 'sin datos');
  check('Guarda cargas por serie', !!raw && raw.includes('"load":"80"'));

  // 11. Recorrer todas las pantallas
  for (const screen of ['Calendario', 'Progreso', 'Nutrición', 'Biblioteca']) {
    const nav = buttons(doc).find((b) => (b.textContent || '').trim() === screen);
    await click(window, nav, `nav ${screen}`);
    check(`Abre ${screen}`, has(doc, screen === 'Nutrición' ? 'Hidratación' : screen));
  }

  // 12. Calendario: estados y cambio de actividad
  await click(window, buttons(doc).find((b) => (b.textContent || '').trim() === 'Calendario'), 'nav calendario');
  check('Calendario muestra RPE real', has(doc, 'RPE real 8') || has(doc, 'RPE real'));
  await click(window, findButton(doc, 'Mes'), 'vista mes');
  check('Vista mensual', has(doc, 'LUN') && has(doc, 'DOM'));
  await click(window, findButton(doc, 'Semana'), 'vista semana');
  await click(window, findButton(doc, 'Cambiar actividad del día'), 'cambiar actividad');
  await click(window, findButton(doc, 'Surf', { exact: true }), 'elegir surf');
  check('Cambia la actividad y avisa del impacto', has(doc, 'puede modificar la carga'));

  // 13. Progreso: cargar métrica
  await click(window, buttons(doc).find((b) => (b.textContent || '').trim() === 'Progreso'), 'nav progreso');
  const metricInput = [...doc.querySelectorAll('input')].find((i) => (i.placeholder || '').includes('Registrar kg'));
  await setInput(window, metricInput, '84.2');
  const saveBtn = findButton(doc, 'Guardar');
  await click(window, saveBtn, 'guardar métrica');
  check('Guarda una métrica', has(doc, '84.2'));

  // 14. Nutrición
  await click(window, buttons(doc).find((b) => (b.textContent || '').trim() === 'Nutrición'), 'nav nutrición');
  await click(window, findButton(doc, 'Esquí', { exact: true }), 'tipo de día esquí');
  check('Tipo de día cambia carbohidratos', has(doc, 'Alto'));
  await click(window, doc.querySelector('button[aria-label="Marcar 5 vasos de agua"]'), 'agua 5');
  check('Tracker de agua', has(doc, '5/10'));
  await click(window, findButton(doc, 'Creatina'), 'creatina');

  // 15. Biblioteca
  await click(window, buttons(doc).find((b) => (b.textContent || '').trim() === 'Biblioteca'), 'nav biblioteca');
  const search = doc.querySelector('input[placeholder^="Buscar"]');
  await setInput(window, search, 'pallof');
  check('Busca en la biblioteca', has(doc, 'Pallof Press') && !has(doc, 'Bench Press'));
  await click(window, findButton(doc, 'Agregar a sesión'), 'agregar a sesión');
  check('Agrega a la sesión de hoy', has(doc, 'quitar'));

  // 16. One Pager
  await click(window, buttons(doc).find((b) => (b.textContent || '').trim() === 'Hoy'), 'nav hoy');
  await click(window, findButton(doc, 'Vista One Pager'), 'one pager');
  check('One Pager abre', has(doc, 'High Performance Training System') && has(doc, 'Registrar'));
  await click(window, findButton(doc, 'Volver'), 'volver de one pager');
  check('Vuelve de One Pager', has(doc, 'Comenzar') || has(doc, 'Repasar'));

  // 17. Configuración y reset
  await click(window, doc.querySelector('button[aria-label="Abrir configuración"]'), 'abrir config');
  check('Configuración abre', has(doc, 'Perfil del atleta'));
  await click(window, findButton(doc, 'Restablecer datos'), 'reset');
  await click(window, findButton(doc, 'Confirmar restablecimiento'), 'confirmar reset');
  check('Reset limpia el historial', !window.localStorage.getItem('tide.state.v1')?.includes('"rpe":8'));

  console.log('\nErrores de consola/runtime:', errors.length ? errors : 'ninguno');
  const failed = results.filter((r) => !r.ok);
  console.log(`\nRESUMEN: ${results.length - failed.length}/${results.length} OK`);
  if (failed.length) {
    console.log('FALLAS:');
    failed.forEach((f) => console.log(' -', f.name, f.detail));
  }
  process.exit(failed.length || errors.length ? 1 : 0);
};

run().catch((e) => {
  console.error('HARNESS ERROR:', e.message);
  process.exit(2);
});
