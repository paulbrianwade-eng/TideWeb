import type { CoachAdjustment, DailyReadiness, Workout } from '../types';

export const ADJUSTMENTS: CoachAdjustment[] = [
  {
    id: 'sleep-low',
    label: 'Dormí menos de 6 horas',
    group: 'estado',
    recommendation: 'Bajá el volumen un 20 % y limitá el RPE a 7.',
    effect: 'Quitá la última serie de cada ejercicio de fuerza y cortá el Engine a 6 rondas.',
  },
  {
    id: 'low-back',
    label: 'Dolor lumbar',
    group: 'estado',
    recommendation: 'Reemplazá peso muerto y remo inclinado por variantes con apoyo.',
    effect: 'RDL → SL-RDL con apoyo o hip thrust · Remo inclinado → Chest-Supported Row · sin carries pesados.',
  },
  {
    id: 'legs-tired',
    label: 'Piernas cansadas',
    group: 'estado',
    recommendation: 'Sacá los saltos y bajá el volumen unipodal a la mitad.',
    effect: 'Box Jump → lanzamientos rotacionales · Athletic a 2 rondas.',
  },
  {
    id: 'tomorrow-surf',
    label: 'Mañana hago surf',
    group: 'mañana',
    recommendation: 'Reducí volumen de tirón y fatiga de hombros.',
    effect: 'Pull-Up a 3 series · Face Pull solo 2 series · sin waiter carry.',
  },
  {
    id: 'tomorrow-ski',
    label: 'Mañana esquío',
    group: 'mañana',
    recommendation: 'Evitá volumen alto de piernas y excéntricos intensos.',
    effect: 'Sin sentadilla pesada ni nordics · Athletic con carga moderada.',
  },
  {
    id: 'tomorrow-golf',
    label: 'Mañana juego al golf',
    group: 'mañana',
    recommendation: 'Mantené la rotación pero sin fatigar el core.',
    effect: 'Chops y lifts a 2 series técnicas · sin Pallof al fallo.',
  },
  {
    id: 'time-30',
    label: 'Tengo solo 30 minutos',
    group: 'contexto',
    recommendation: 'Versión corta: Reset + Strength principal + Engine reducido.',
    effect: 'Hacé Reset (4 min), los dos primeros ejercicios de Strength y 6 rondas de Engine.',
  },
  {
    id: 'at-home',
    label: 'Entreno en casa',
    group: 'contexto',
    recommendation: 'Sustituí barra y polea por mancuernas y bandas.',
    effect: 'Bench → press con mancuernas · Polea → banda anclada · Assault Bike → burpees o escalera.',
  },
  {
    id: 'at-gym',
    label: 'Entreno en gimnasio',
    group: 'contexto',
    recommendation: 'Sesión completa según lo planificado.',
    effect: 'Sin cambios.',
  },
  {
    id: 'no-bike',
    label: 'No tengo Assault Bike',
    group: 'contexto',
    recommendation: 'Usá remo, bicicleta, SkiErg o cinta inclinada con los mismos intervalos.',
    effect: 'Mantené 20 s fuerte / 40 s suave al 85–90 %.',
  },
  {
    id: 'no-sled',
    label: 'No tengo trineo',
    group: 'contexto',
    recommendation: 'Reemplazá el trineo por carries pesados o cinta en pendiente.',
    effect: 'Farmer Carry 40 m o caminata en pendiente al 12 %.',
  },
];

export const ADJUSTMENT_MAP: Record<string, CoachAdjustment> = Object.fromEntries(
  ADJUSTMENTS.map((a) => [a.id, a]),
);

export interface AdaptationResult {
  volumeFactor: number;
  rpeCap: number | null;
  notes: string[];
  headline: string;
}

export const computeAdaptation = (
  selected: string[],
  readiness: DailyReadiness,
  workout: Workout | null,
): AdaptationResult => {
  const notes: string[] = [];
  let volumeFactor = 1;
  let rpeCap: number | null = null;

  for (const id of selected) {
    const adj = ADJUSTMENT_MAP[id];
    if (!adj) continue;
    notes.push(`${adj.label}: ${adj.recommendation}`);
    if (id === 'sleep-low') {
      volumeFactor = Math.min(volumeFactor, 0.8);
      rpeCap = 7;
    }
    if (id === 'legs-tired') volumeFactor = Math.min(volumeFactor, 0.85);
    if (id === 'time-30') volumeFactor = Math.min(volumeFactor, 0.5);
    if (id === 'tomorrow-ski' || id === 'tomorrow-surf') rpeCap = Math.min(rpeCap ?? 8, 8);
  }

  if (readiness.sleep !== null && readiness.sleep <= 4) {
    notes.push('Sueño bajo declarado: priorizá calidad de movimiento y cortá antes del fallo.');
    volumeFactor = Math.min(volumeFactor, 0.85);
    rpeCap = Math.min(rpeCap ?? 8, 7);
  }
  if (readiness.pain !== null && readiness.pain >= 6) {
    notes.push('Dolor alto declarado: evitá rangos que molesten y sustituí lo que genere síntomas.');
    rpeCap = Math.min(rpeCap ?? 8, 6);
  }
  if (readiness.energy !== null && readiness.energy >= 8 && volumeFactor === 1) {
    notes.push('Energía alta: podés apuntar al extremo superior del rango de RPE.');
  }

  if (workout?.nextDayActivity === 'ski' && !selected.includes('tomorrow-ski')) {
    notes.push('Mañana hay esquí: llegá con las piernas frescas, sin excéntricos intensos.');
  }

  const headline =
    volumeFactor < 1 || rpeCap
      ? `Sesión ajustada · volumen ${Math.round(volumeFactor * 100)} %${rpeCap ? ` · RPE máx ${rpeCap}` : ''}`
      : 'Sesión sin ajustes: entrená como está planificada.';

  return { volumeFactor, rpeCap, notes, headline };
};

export const readinessState = (
  r: DailyReadiness,
): { label: 'Listo' | 'Moderado' | 'Recuperación'; tone: 'success' | 'warn' | 'danger' } => {
  const { energy, sleep, pain } = r;
  if (energy === null && sleep === null && pain === null) return { label: 'Moderado', tone: 'warn' };
  const e = energy ?? 6;
  const s = sleep ?? 6;
  const p = pain ?? 2;
  const score = (e + s) / 2 - p * 0.6;
  if (score >= 6.5) return { label: 'Listo', tone: 'success' };
  if (score >= 4.5) return { label: 'Moderado', tone: 'warn' };
  return { label: 'Recuperación', tone: 'danger' };
};

export const postSessionNote = (rpe: number): string => {
  if (rpe >= 9) return 'La sesión fue más intensa de lo previsto. Mañana conviene priorizar recuperación.';
  if (rpe >= 7) return 'Intensidad correcta. Buen estímulo sin exceder el objetivo.';
  return 'La próxima vez podemos subir ligeramente la carga o el volumen.';
};
