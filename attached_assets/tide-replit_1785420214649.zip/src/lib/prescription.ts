import type { ExercisePrescription, Workout, WorkoutSession } from '../types';

export const prescriptionKey = (blockId: string, index: number): string => `${blockId}:${index}`;

/** Línea corta tipo "4 × 5 por lado · descanso 45 s" */
export const describePrescription = (p: ExercisePrescription): string => {
  const parts: string[] = [];
  const volume: string[] = [];
  if (p.sets) volume.push(`${p.sets} series`);
  if (p.reps) volume.push(`${p.reps} rep${p.unilateral ? ' por lado' : ''}`);
  if (p.duration) volume.push(p.unilateral ? `${p.duration} por lado` : p.duration);
  if (p.distance) volume.push(`${p.distance}${p.unilateral ? ' por lado' : ''}`);
  if (volume.length) parts.push(volume.join(' × '));
  if (p.rpe) parts.push(`RPE ${p.rpe}`);
  if (p.load) parts.push(p.load);
  if (p.rest) parts.push(`descanso ${p.rest}`);
  return parts.join(' · ');
};

export const unitLabel = (p: ExercisePrescription): string => {
  if (p.carry) return 'Metros por lado';
  if (p.isometric) return 'Segundos';
  if (p.unilateral) return 'Por lado';
  return 'Repeticiones';
};

export const targetSets = (p: ExercisePrescription): number => p.sets ?? 1;

export const totalSets = (workout: Workout): number =>
  workout.blocks.reduce(
    (acc, b) => acc + b.items.reduce((a, item) => a + targetSets(item) * (b.rounds ? roundsCount(b.rounds) : 1), 0),
    0,
  );

export const roundsCount = (rounds: string): number => {
  const m = rounds.match(/(\d+)/);
  return m ? Number(m[1]) : 1;
};

export const setsForItem = (blockRounds: string | undefined, p: ExercisePrescription): number =>
  blockRounds ? roundsCount(blockRounds) : targetSets(p);

export const sessionProgress = (workout: Workout, session?: WorkoutSession): number => {
  if (!session) return 0;
  let done = 0;
  let total = 0;
  workout.blocks.forEach((block) => {
    block.items.forEach((item, i) => {
      const key = prescriptionKey(block.id, i);
      const n = setsForItem(block.rounds, item);
      total += n;
      if (session.skipped.includes(key)) {
        done += n;
        return;
      }
      const rows = session.sets[key] ?? [];
      done += rows.filter((r) => r.done).length;
    });
  });
  return total === 0 ? 0 : Math.min(1, done / total);
};

export const sessionVolume = (workout: Workout, session?: WorkoutSession): number => {
  if (!session) return 0;
  let volume = 0;
  workout.blocks.forEach((block) => {
    block.items.forEach((_, i) => {
      const rows = session.sets[prescriptionKey(block.id, i)] ?? [];
      rows.forEach((r) => {
        if (!r.done) return;
        const load = Number(r.load);
        const reps = Number(r.reps);
        if (Number.isFinite(load) && Number.isFinite(reps)) volume += load * reps;
      });
    });
  });
  return Math.round(volume);
};

export const completedSetCount = (workout: Workout, session?: WorkoutSession): number => {
  if (!session) return 0;
  let n = 0;
  workout.blocks.forEach((block) => {
    block.items.forEach((_, i) => {
      const rows = session.sets[prescriptionKey(block.id, i)] ?? [];
      n += rows.filter((r) => r.done).length;
    });
  });
  return n;
};

export const blocksCompleted = (workout: Workout, session?: WorkoutSession): number => {
  if (!session) return 0;
  return workout.blocks.filter((block) =>
    block.items.every((item, i) => {
      const key = prescriptionKey(block.id, i);
      if (session.skipped.includes(key)) return true;
      const rows = session.sets[key] ?? [];
      return rows.filter((r) => r.done).length >= setsForItem(block.rounds, item);
    }),
  ).length;
};

/** Columna derecha, línea 1: volumen compacto (5 × 5, 3 × 25 m, 10 × 20 s…) */
export const volumeText = (p: ExercisePrescription): string => {
  const left = p.sets ? String(p.sets) : '';
  const right = p.reps ?? p.duration ?? p.distance ?? '';
  if (left && right) return `${left} × ${right}`;
  return right || left;
};

/** Columna derecha, línea 2: RPE, carga o descanso, lo que aporte más. */
export const intensityText = (p: ExercisePrescription): string => {
  if (p.rpe) return `RPE ${p.rpe}`;
  if (p.load) return p.load;
  if (p.rest) return `↺ ${p.rest}`;
  return '';
};

/** Etiqueta de lado bajo el nombre, solo cuando cambia cómo se ejecuta. */
export const sideText = (p: ExercisePrescription): string => {
  if (p.carry) return 'por lado';
  if (p.unilateral) return 'por lado';
  if (p.isometric) return 'isométrico';
  return '';
};
