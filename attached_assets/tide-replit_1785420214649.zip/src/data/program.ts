import type { SportActivity, Workout, WorkoutBlock } from '../types';
import { addDays, todayISO } from '../lib/date';

/**
 * El programa se ancla al día actual: DAY 1 es hoy, de modo que la sesión
 * insignia (Athletic Upper Performance) siempre aparece al abrir la app.
 * Para anclar la semana a un lunes fijo, cambiá PROGRAM_START por una fecha
 * 'YYYY-MM-DD' y ordená los templates como quieras.
 */
export const PROGRAM_START = todayISO();

type Template = Omit<Workout, 'date' | 'day' | 'status'>;

const reset = (id: string): WorkoutBlock => ({
  id: `${id}-reset`,
  kind: 'reset',
  title: 'Reset',
  duration: '8 min',
  focus: 'Movilidad y activación',
  items: [
    { exerciseId: 'nasal-breathing', duration: '2 min', instructions: 'Inhalar 4 s · exhalar 6 s.' },
    { exerciseId: 'cat-cow', reps: '10' },
    { exerciseId: 'worlds-greatest-stretch', reps: '5', unilateral: true },
    { exerciseId: 'open-book', reps: '8', unilateral: true },
    { exerciseId: 'deep-squat-hold', duration: '45 s', isometric: true },
    { exerciseId: 'monster-walk', order: 'Circuito ×2', reps: '15 pasos', unilateral: true },
    { exerciseId: 'bird-dog', order: 'Circuito ×2', reps: '8', unilateral: true },
    { exerciseId: 'scapular-push-up', order: 'Circuito ×2', reps: '10' },
    { exerciseId: 'dead-bug', order: 'Circuito ×2', reps: '10', unilateral: true },
  ],
});

const recovery = (id: string): WorkoutBlock => ({
  id: `${id}-recovery`,
  kind: 'recovery',
  title: 'Recovery',
  duration: '5 min',
  focus: 'Bajar revoluciones',
  items: [
    { exerciseId: 'easy-walk', duration: '2 min' },
    { exerciseId: 'hip-flexor-stretch', duration: '40 s', unilateral: true, isometric: true },
    { exerciseId: 'open-book', reps: '6', unilateral: true },
    { exerciseId: 'nasal-breathing', duration: '2 min', instructions: 'Inhalar 4 s · exhalar 6–8 s.' },
  ],
});

const TEMPLATES: Template[] = [
  {
    id: 'w1d1-athletic-upper',
    week: 1,
    name: 'Athletic Upper Performance',
    subtitle: 'Fuerza superior · Potencia · Antirrotación',
    objective:
      'Desarrollar fuerza del tren superior, potencia rotacional, estabilidad del hombro y control del core sin generar fatiga excesiva de piernas antes de una jornada de esquí.',
    duration: '65–75 min',
    plannedRpe: '7–8',
    coachNote:
      'Hoy no buscamos récords ni fatiga muscular extrema. Cada repetición debe ser explosiva o técnicamente sólida. Terminá sintiendo que podrías haber realizado una serie más.',
    nextDayActivity: 'ski',
    adaptations: [],
    blocks: [
      reset('w1d1'),
      {
        id: 'w1d1-power',
        kind: 'power',
        title: 'Power',
        duration: '8 min',
        focus: 'Velocidad e intención',
        items: [
          {
            exerciseId: 'rotational-mb-throw',
            order: 'A1',
            sets: 4,
            reps: '5',
            unilateral: true,
            rest: '45 s',
            instructions: 'Máxima velocidad. Cortá la serie si baja la potencia.',
          },
          {
            exerciseId: 'box-jump',
            order: 'A2',
            sets: 4,
            reps: '3',
            rest: '60 s',
            instructions: 'Intensidad moderada. No busques altura máxima: aterrizaje suave y estable.',
          },
        ],
      },
      {
        id: 'w1d1-strength',
        kind: 'strength',
        title: 'Strength',
        duration: '25–30 min',
        focus: 'Empuje y tracción',
        items: [
          { exerciseId: 'bench-press', order: 'A', sets: 5, reps: '5', rpe: '7–8', rest: '2 min' },
          {
            exerciseId: 'pull-up',
            order: 'B',
            sets: 5,
            reps: '6–8',
            rpe: '8',
            rest: '2 min',
            instructions: 'Agregá carga si podés hacer más de 10 repeticiones cómodas.',
          },
          { exerciseId: 'landmine-press', order: 'C1', sets: 3, reps: '8', unilateral: true, rpe: '7–8' },
          {
            exerciseId: 'chest-supported-row',
            order: 'C2',
            sets: 3,
            reps: '10',
            rpe: '8',
            rest: '75 s después del par',
          },
          {
            exerciseId: 'face-pull',
            order: 'D',
            sets: 3,
            reps: '15',
            instructions: 'Pausa de 1 s en la posición final.',
          },
        ],
      },
      {
        id: 'w1d1-athletic',
        kind: 'athletic',
        title: 'Athletic',
        duration: '12–15 min',
        focus: 'Circuito controlado',
        rounds: '3 rondas',
        rest: '60–75 s entre rondas',
        items: [
          {
            exerciseId: 'single-leg-rdl',
            order: 'E1',
            reps: '8',
            unilateral: true,
            load: 'Peso moderado',
            instructions: 'Control y estabilidad por encima de la carga.',
          },
          {
            exerciseId: 'pallof-press',
            order: 'E2',
            reps: '10',
            unilateral: true,
            instructions: 'Pausa de 2 s en extensión.',
          },
          {
            exerciseId: 'suitcase-carry',
            order: 'E3',
            distance: '25 m',
            unilateral: true,
            carry: true,
            load: 'Peso desafiante',
            instructions: 'Evitá inclinar el tronco.',
          },
          { exerciseId: 'copenhagen-plank', order: 'E4', duration: '20–25 s', unilateral: true, isometric: true },
        ],
      },
      {
        id: 'w1d1-engine',
        kind: 'engine',
        title: 'Engine',
        duration: '10 min',
        focus: 'Assault Bike · 10 rondas',
        items: [
          {
            exerciseId: 'assault-bike-intervals',
            sets: 10,
            duration: '20 s fuerte / 40 s suave',
            rpe: '85–90 %',
            instructions:
              'Sin esfuerzos máximos. Terminá sintiendo que podrías completar una ronda más.',
            alternatives: ['Bicicleta estática', 'Remo', 'Cinta inclinada', 'SkiErg'],
          },
        ],
      },
      recovery('w1d1'),
    ],
  },
  {
    id: 'w1d2-ski',
    week: 1,
    name: 'Esquí',
    subtitle: 'Actividad deportiva · Jornada de montaña',
    objective: 'Rendir en la nieve con buena resistencia y llegar entero al final del día.',
    duration: 'Jornada',
    plannedRpe: '6–8',
    coachNote:
      'Antes de la primera bajada: 5 minutos de movilidad de cadera y tobillo. Hidratá cada hora y comé algo sólido a media mañana.',
    nextDayActivity: 'rest',
    adaptations: [],
    externalActivity: 'ski',
    blocks: [
      {
        id: 'w1d2-reset',
        kind: 'reset',
        title: 'Pre-esquí',
        duration: '6 min',
        focus: 'Preparar cadera, tobillo y torácica',
        items: [
          { exerciseId: 'hip-9090', reps: '8 cambios' },
          { exerciseId: 'lateral-lunge', reps: '8', unilateral: true },
          { exerciseId: 'worlds-greatest-stretch', reps: '5', unilateral: true },
          { exerciseId: 'monster-walk', reps: '15 pasos', unilateral: true },
        ],
      },
      recovery('w1d2'),
    ],
  },
  {
    id: 'w1d3-active-recovery',
    week: 1,
    name: 'Active Recovery',
    subtitle: 'Movilidad · Circulación · Tejido',
    objective: 'Acelerar la recuperación después del esquí sin sumar fatiga.',
    duration: '30–35 min',
    plannedRpe: '3–4',
    coachNote:
      'Todo debería sentirse fácil. Si en algún momento te falta el aire o aparece tensión, bajá el ritmo.',
    nextDayActivity: 'rest',
    adaptations: [],
    blocks: [
      reset('w1d3'),
      {
        id: 'w1d3-engine',
        kind: 'engine',
        title: 'Engine',
        duration: '20 min',
        focus: 'Zona 1–2 muy suave',
        items: [
          {
            exerciseId: 'easy-walk',
            duration: '20 min',
            rpe: '3',
            instructions: 'Respiración nasal todo el tiempo.',
            alternatives: ['Bicicleta suave', 'Natación fácil'],
          },
        ],
      },
      recovery('w1d3'),
    ],
  },
  {
    id: 'w1d4-mobility',
    week: 1,
    name: 'Movilidad & Descanso',
    subtitle: 'Cadera · Tobillos · Torácica',
    objective: 'Recuperar rango de movimiento y descargar la zona lumbar.',
    duration: '25 min',
    plannedRpe: '2–3',
    coachNote:
      'Día de descanso real. Hacé la rutina si te levantás con ganas; si no, caminá 20 minutos y listo.',
    nextDayActivity: 'gym',
    adaptations: [],
    blocks: [
      reset('w1d4'),
      {
        id: 'w1d4-athletic',
        kind: 'athletic',
        title: 'Control',
        duration: '10 min',
        focus: '2 rondas suaves',
        rounds: '2 rondas',
        items: [
          { exerciseId: 'hip-airplane', reps: '6', unilateral: true },
          { exerciseId: 'cossack-squat', reps: '6', unilateral: true },
          { exerciseId: 'thoracic-rotation', reps: '8', unilateral: true },
          { exerciseId: 'dead-bug', reps: '10', unilateral: true },
        ],
      },
      recovery('w1d4'),
    ],
  },
  {
    id: 'w1d5-lower-power',
    week: 1,
    name: 'Lower Strength + Power',
    subtitle: 'Fuerza inferior · Potencia · Unipodal',
    objective:
      'Construir fuerza de piernas y potencia aplicable a esquí y running, con trabajo unipodal y de tendones.',
    duration: '70 min',
    plannedRpe: '8',
    coachNote:
      'Es el día más pesado de la semana. Calentá sin apuro y priorizá técnica en las series pesadas.',
    nextDayActivity: 'gym',
    adaptations: [],
    blocks: [
      reset('w1d5'),
      {
        id: 'w1d5-power',
        kind: 'power',
        title: 'Power',
        duration: '10 min',
        focus: 'Horizontal y lateral',
        items: [
          { exerciseId: 'broad-jump', order: 'A1', sets: 4, reps: '3', rest: '60 s' },
          { exerciseId: 'lateral-bound', order: 'A2', sets: 3, reps: '5', unilateral: true, rest: '60 s' },
        ],
      },
      {
        id: 'w1d5-strength',
        kind: 'strength',
        title: 'Strength',
        duration: '30 min',
        focus: 'Sentadilla y cadena posterior',
        items: [
          { exerciseId: 'back-squat', order: 'A', sets: 4, reps: '5', rpe: '7–8', rest: '2–3 min' },
          { exerciseId: 'romanian-deadlift', order: 'B', sets: 4, reps: '6–8', rpe: '7', rest: '2 min' },
          {
            exerciseId: 'bulgarian-split-squat',
            order: 'C1',
            sets: 3,
            reps: '8–10',
            unilateral: true,
            rpe: '8',
          },
          { exerciseId: 'copenhagen-plank', order: 'C2', sets: 3, duration: '20 s', unilateral: true, isometric: true },
        ],
      },
      {
        id: 'w1d5-athletic',
        kind: 'athletic',
        title: 'Athletic',
        duration: '12 min',
        focus: 'Circuito',
        rounds: '3 rondas',
        rest: '60 s',
        items: [
          { exerciseId: 'step-down', reps: '8', unilateral: true },
          { exerciseId: 'farmer-carry', distance: '30 m', carry: true },
          { exerciseId: 'tibialis-raise', reps: '20' },
          { exerciseId: 'soleus-raise', reps: '20' },
        ],
      },
      recovery('w1d5'),
    ],
  },
  {
    id: 'w1d6-upper-core',
    week: 1,
    name: 'Upper Strength + Core',
    subtitle: 'Empuje · Tracción · Antirrotación',
    objective: 'Sumar volumen de fuerza en tren superior y consolidar el core en todos los planos.',
    duration: '60 min',
    plannedRpe: '7–8',
    coachNote:
      'Buscá calidad de contracción antes que carga. El core del final es tan importante como el press.',
    nextDayActivity: 'running',
    adaptations: [],
    blocks: [
      reset('w1d6'),
      {
        id: 'w1d6-strength',
        kind: 'strength',
        title: 'Strength',
        duration: '30 min',
        focus: 'Vertical y horizontal',
        items: [
          { exerciseId: 'landmine-press', order: 'A1', sets: 4, reps: '8', unilateral: true, rpe: '8' },
          { exerciseId: 'pull-up', order: 'A2', sets: 4, reps: '6–8', rpe: '8', rest: '90 s' },
          { exerciseId: 'bench-press', order: 'B1', sets: 3, reps: '8', rpe: '7' },
          { exerciseId: 'chest-supported-row', order: 'B2', sets: 3, reps: '12', rpe: '8', rest: '75 s' },
          { exerciseId: 'face-pull', order: 'C', sets: 3, reps: '15' },
        ],
      },
      {
        id: 'w1d6-athletic',
        kind: 'athletic',
        title: 'Core & Carries',
        duration: '15 min',
        focus: 'Antirrotación y rotación',
        rounds: '3 rondas',
        rest: '60 s',
        items: [
          { exerciseId: 'cable-chop', reps: '10', unilateral: true },
          { exerciseId: 'cable-lift', reps: '10', unilateral: true },
          { exerciseId: 'waiter-carry', distance: '20 m', unilateral: true, carry: true },
          { exerciseId: 'dead-bug', reps: '10', unilateral: true },
        ],
      },
      recovery('w1d6'),
    ],
  },
  {
    id: 'w1d7-zone2',
    week: 1,
    name: 'Zone 2 + Mobility',
    subtitle: 'Base aeróbica · Movilidad',
    objective: 'Sumar base aeróbica para volver a los 10 km sin cargar las piernas.',
    duration: '50 min',
    plannedRpe: '5',
    coachNote:
      'Ritmo conversacional. Si no podés hablar en frases completas, estás yendo demasiado rápido.',
    nextDayActivity: 'surf',
    adaptations: [],
    blocks: [
      reset('w1d7'),
      {
        id: 'w1d7-engine',
        kind: 'engine',
        title: 'Engine',
        duration: '35–40 min',
        focus: 'Zona 2 continua',
        items: [
          {
            exerciseId: 'zone2-run',
            duration: '35–40 min',
            rpe: '5',
            instructions: 'Cadencia alta, pasos cortos. Caminá 1 min si la respiración se dispara.',
            alternatives: ['Bicicleta', 'Remo', 'Caminata en pendiente'],
          },
        ],
      },
      {
        id: 'w1d7-athletic',
        kind: 'athletic',
        title: 'Tendones',
        duration: '8 min',
        focus: '2 rondas',
        rounds: '2 rondas',
        items: [
          { exerciseId: 'tibialis-raise', reps: '20' },
          { exerciseId: 'soleus-raise', reps: '20' },
          { exerciseId: 'nordic-curl', reps: '5' },
        ],
      },
      recovery('w1d7'),
    ],
  },
];

export const buildProgram = (start: string = PROGRAM_START): Workout[] =>
  TEMPLATES.map((t, i) => ({
    ...t,
    day: i + 1,
    date: addDays(start, i),
    status: t.externalActivity ? 'external' : 'pending',
  }));

export const ACTIVITY_LABEL: Record<SportActivity, string> = {
  surf: 'Surf',
  golf: 'Golf',
  ski: 'Esquí',
  running: 'Running',
  rest: 'Descanso',
  gym: 'Gimnasio',
  home: 'Entrenamiento en casa',
};
