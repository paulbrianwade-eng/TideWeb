import type { ExercisePrescription, WorkoutBlock } from '../types';
import { BLOCK_META } from './blockMeta';
import { getExercise } from '../data/exercises';
import { intensityText, sideText, volumeText } from '../lib/prescription';


/** Fila tabular: tag · ejercicio · volumen / intensidad alineados a la derecha. */
export const ExerciseRow = ({
  p,
  name,
  dense = false,
}: {
  p: ExercisePrescription;
  name?: string;
  dense?: boolean;
}) => {
  const ex = getExercise(p.exerciseId);
  const side = sideText(p);
  const intensity = intensityText(p);
  return (
    <div className="ex-row last:border-b-0">
      <span className="font-mono text-[11px] leading-5 text-accent">{p.order ?? ''}</span>
      <span className="min-w-0">
        <span className="block truncate text-sm font-medium leading-5">{name ?? ex.name}</span>
        {!dense && (p.instructions || side) && (
          <span className="mt-0.5 block text-xs leading-snug text-muted">
            {side && <span className="mr-1.5 font-mono uppercase tracking-[0.12em] text-muted/80">{side}</span>}
            {p.instructions}
          </span>
        )}
      </span>
      <span className="text-right">
        <span className="block font-mono text-sm leading-5 text-ink">{volumeText(p)}</span>
        {intensity && <span className="block font-mono text-[11px] text-muted">{intensity}</span>}
      </span>
    </div>
  );
};

export const BlockHeader = ({ block }: { block: WorkoutBlock }) => {
  const meta = BLOCK_META[block.kind];
  const Icon = meta.icon;
  return (
    <div className="flex items-center gap-2.5">
      <span
        aria-hidden="true"
        className="grid h-7 w-7 shrink-0 place-items-center rounded-lg border"
        style={{ borderColor: `${meta.color}55`, backgroundColor: `${meta.color}14` }}
      >
        <Icon className="h-3.5 w-3.5" style={{ color: meta.color }} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block font-display text-base font-semibold leading-tight">{block.title}</span>
        <span className="block truncate text-xs text-muted">
          {block.rounds ? `${block.rounds} · ` : ''}
          {block.focus}
        </span>
      </span>
      <span className="shrink-0 font-mono text-[11px] text-muted">{block.duration}</span>
    </div>
  );
};

export const WorkoutBlockCard = ({
  block,
  onOpen,
  progress,
  expanded = false,
}: {
  block: WorkoutBlock;
  onOpen?: () => void;
  progress?: number;
  expanded?: boolean;
}) => {
  const meta = BLOCK_META[block.kind];
  const body = (
    <>
      <BlockHeader block={block} />

      {expanded ? (
        <div className="mt-3">
          {block.items.map((item, i) => (
            <ExerciseRow key={`${block.id}-${i}`} p={item} dense />
          ))}
        </div>
      ) : (
        <p className="mt-2 truncate text-xs text-muted/80">
          {block.items.map((i) => getExercise(i.exerciseId).name).join(' · ')}
        </p>
      )}

      {progress !== undefined && (
        <div className="mt-3 h-1 w-full overflow-hidden rounded-full bg-surface2">
          <div
            className="h-full rounded-full transition-all"
            style={{ width: `${Math.round(progress * 100)}%`, backgroundColor: meta.color }}
          />
        </div>
      )}
    </>
  );

  return onOpen ? (
    <button type="button" onClick={onOpen} className="card w-full p-4 text-left transition-colors hover:border-white/20">
      {body}
    </button>
  ) : (
    <div className="card p-4">{body}</div>
  );
};

/** Bloque en formato "hoja de rutina": banda + tabla. Se usa en One Pager y Daily Card. */
export const BlockSheet = ({ block }: { block: WorkoutBlock }) => {
  const meta = BLOCK_META[block.kind];
  return (
    <section>
      <div className="band mb-1">
        <span className="band-label" style={{ color: meta.color }}>
          {block.title}
        </span>
        <span className="band-rule" />
        <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted">
          {block.rounds ? `${block.rounds} · ` : ''}
          {block.duration}
        </span>
      </div>
      {block.rest && <p className="mb-1 font-mono text-[11px] text-muted">Descanso {block.rest}</p>}
      <div>
        {block.items.map((item, i) => (
          <ExerciseRow key={`${block.id}-sheet-${i}`} p={item} />
        ))}
      </div>
    </section>
  );
};
