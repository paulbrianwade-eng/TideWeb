import { useEffect, useState } from 'react';
import { Trophy } from 'lucide-react';
import type { SessionSummary } from '../types';
import { postSessionNote } from '../lib/adaptations';
import { CoachNote } from './workout-parts';
import { ScaleSelector, Stat, StatusBadge } from './ui';

export interface SummaryDraft {
  workoutId: string;
  workoutName: string;
  date: string;
  durationMin: number;
  blocksCompleted: number;
  blocksTotal: number;
  volumeKg: number;
  setsCompleted: number;
  highlight: string | null;
  personalRecord: string | null;
}

export const WorkoutSummaryModal = ({
  draft,
  onSave,
  onClose,
}: {
  draft: SummaryDraft;
  onSave: (s: SessionSummary) => void;
  onClose: () => void;
}) => {
  const [rpe, setRpe] = useState<number | null>(null);
  const [energy, setEnergy] = useState<number | null>(null);
  const [pain, setPain] = useState<number | null>(null);
  const [feeling, setFeeling] = useState<SessionSummary['feeling']>(null);
  const [comment, setComment] = useState('');

  const note = postSessionNote(rpe ?? 7);

  // Bloquea el scroll del fondo mientras el resumen está abierto
  useEffect(() => {
    document.body.classList.add('scroll-lock');
    return () => document.body.classList.remove('scroll-lock');
  }, []);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Resumen del entrenamiento"
      className="fixed inset-0 z-50 overflow-y-auto bg-base/95 backdrop-blur"
    >
      <div className="mx-auto w-full max-w-2xl space-y-4 px-4 py-8">
        <div className="text-center">
          <StatusBadge tone="success">Entrenamiento completado</StatusBadge>
          <h2 className="mt-3 font-display text-3xl leading-none">{draft.workoutName}</h2>
        </div>

        <div className="card grid grid-cols-2 gap-4 p-4 sm:grid-cols-4">
          <Stat label="Duración" value={`${draft.durationMin} min`} />
          <Stat label="Bloques" value={`${draft.blocksCompleted}/${draft.blocksTotal}`} />
          <Stat label="Volumen" value={draft.volumeKg > 0 ? `${draft.volumeKg} kg` : '—'} tone="accent" />
          <Stat label="Series" value={String(draft.setsCompleted)} />
        </div>

        {(draft.highlight || draft.personalRecord) && (
          <div className="card space-y-2 p-4">
            {draft.highlight && (
              <p className="text-sm">
                <span className="eyebrow mr-2">Destacado</span>
                {draft.highlight}
              </p>
            )}
            {draft.personalRecord && (
              <p className="flex items-center gap-2 text-sm text-accent">
                <Trophy className="h-4 w-4" aria-hidden="true" />
                Récord personal: {draft.personalRecord}
              </p>
            )}
          </div>
        )}

        <div className="card space-y-4 p-4">
          <ScaleSelector label="RPE general de la sesión" value={rpe} onChange={setRpe} />
          <ScaleSelector label="Energía al terminar" value={energy} onChange={setEnergy} />
          <ScaleSelector label="Dolor" value={pain} onChange={setPain} min={0} hint="0 = sin molestias" />

          <div>
            <p className="mb-1.5 text-sm font-medium">¿Llegaste fresco, justo o destruido?</p>
            <div className="grid grid-cols-3 gap-2">
              {(['fresco', 'justo', 'destruido'] as const).map((f) => (
                <button
                  key={f}
                  type="button"
                  aria-pressed={feeling === f}
                  onClick={() => setFeeling(f)}
                  className={`rounded-xl border px-3 py-2.5 text-sm capitalize ${
                    feeling === f ? 'border-accent bg-accent/15' : 'border-line bg-surface2 text-muted'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <label className="block">
            <span className="eyebrow">Comentario</span>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
              placeholder="Qué salió bien, qué molestó, qué cambiarías."
              className="field mt-1 resize-none"
            />
          </label>
        </div>

        {rpe !== null && <CoachNote text={note} compact />}

        <div className="space-y-2">
          <button
            type="button"
            className="btn-primary w-full"
            onClick={() =>
              onSave({
                ...draft,
                rpe: rpe ?? 0,
                energy: energy ?? 0,
                pain: pain ?? 0,
                feeling,
                comment,
                coachNote: note,
              })
            }
          >
            Guardar en el historial
          </button>
          <button type="button" onClick={onClose} className="btn-quiet w-full">
            Volver a la sesión
          </button>
        </div>
      </div>
    </div>
  );
};
