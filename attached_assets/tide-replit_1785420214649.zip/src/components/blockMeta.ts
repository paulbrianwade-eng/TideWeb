import {
  Activity,
  Bike,
  Dumbbell,
  Moon,
  Wind,
  Zap,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { BlockKind } from '../types';

export interface BlockMeta {
  label: string;
  icon: LucideIcon;
  color: string;
  ring: string;
  text: string;
}

export const BLOCK_META: Record<BlockKind, BlockMeta> = {
  reset: { label: 'Reset', icon: Wind, color: '#56D68A', ring: 'border-[#56D68A]/40', text: 'text-[#56D68A]' },
  power: { label: 'Power', icon: Zap, color: '#C7F000', ring: 'border-[#C7F000]/40', text: 'text-[#C7F000]' },
  strength: { label: 'Strength', icon: Dumbbell, color: '#F5F7F8', ring: 'border-white/25', text: 'text-ink' },
  athletic: { label: 'Athletic', icon: Activity, color: '#FFB547', ring: 'border-[#FFB547]/40', text: 'text-[#FFB547]' },
  engine: { label: 'Engine', icon: Bike, color: '#FF6464', ring: 'border-[#FF6464]/40', text: 'text-[#FF6464]' },
  recovery: { label: 'Recovery', icon: Moon, color: '#A5ADB4', ring: 'border-white/15', text: 'text-muted' },
};
