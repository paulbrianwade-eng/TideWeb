import type { ReactNode } from 'react';
import { CalendarDays, Dumbbell, Home, Library, Salad, Settings, TrendingUp } from 'lucide-react';
import { Logo } from './ui';

export type Screen = 'today' | 'calendar' | 'progress' | 'nutrition' | 'library' | 'settings';

export const NAV_ITEMS: { id: Screen; label: string; icon: typeof Home }[] = [
  { id: 'today', label: 'Hoy', icon: Home },
  { id: 'calendar', label: 'Calendario', icon: CalendarDays },
  { id: 'progress', label: 'Progreso', icon: TrendingUp },
  { id: 'nutrition', label: 'Nutrición', icon: Salad },
  { id: 'library', label: 'Biblioteca', icon: Library },
];

export const AppShell = ({
  screen,
  onNavigate,
  children,
}: {
  screen: Screen;
  onNavigate: (s: Screen) => void;
  children: ReactNode;
}) => (
  <div className="min-h-screen bg-base lg:flex">
    <header className="sticky top-0 z-30 border-b border-line bg-base/95 backdrop-blur lg:hidden">
      <div className="flex items-center justify-between px-4 py-3">
        <Logo />
        <button
          type="button"
          onClick={() => onNavigate('settings')}
          aria-label="Abrir configuración"
          className="rounded-lg border border-line bg-surface p-2 text-muted hover:text-ink"
        >
          <Settings className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    </header>

    <nav
      aria-label="Navegación principal"
      className="hidden w-60 shrink-0 border-r border-line bg-surface/40 p-4 lg:flex lg:flex-col lg:gap-1"
    >
      <div className="mb-6 px-1">
        <Logo compact />
        <p className="eyebrow mt-2">High Performance Training System</p>
      </div>
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const active = screen === item.id;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onNavigate(item.id)}
            aria-current={active ? 'page' : undefined}
            className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
              active ? 'bg-accent/15 text-accent' : 'text-muted hover:bg-surface2 hover:text-ink'
            }`}
          >
            <Icon className="h-4 w-4" aria-hidden="true" />
            {item.label}
          </button>
        );
      })}
      <div className="mt-auto pt-4">
        <button
          type="button"
          onClick={() => onNavigate('settings')}
          className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
            screen === 'settings' ? 'bg-accent/15 text-accent' : 'text-muted hover:bg-surface2 hover:text-ink'
          }`}
        >
          <Settings className="h-4 w-4" aria-hidden="true" />
          Configuración
        </button>
      </div>
    </nav>

    <main className="mx-auto w-full max-w-3xl flex-1 px-4 pb-28 pt-4 lg:pb-10 lg:pt-8">{children}</main>

    <nav
      aria-label="Navegación principal"
      className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-base/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden"
    >
      <ul className="grid grid-cols-5">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = screen === item.id;
          return (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => onNavigate(item.id)}
                aria-current={active ? 'page' : undefined}
                className={`flex w-full flex-col items-center gap-1 px-1 py-2.5 text-[11px] font-medium ${
                  active ? 'text-accent' : 'text-muted'
                }`}
              >
                <span
                  aria-hidden="true"
                  className={`h-0.5 w-6 rounded-full ${active ? 'bg-accent' : 'bg-transparent'}`}
                />
                <Icon className="h-5 w-5" aria-hidden="true" />
                {item.label}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  </div>
);

export const FullScreen = ({ children }: { children: ReactNode }) => (
  <div className="min-h-screen bg-base">
    <div className="mx-auto w-full max-w-3xl px-4 pb-32 pt-4">{children}</div>
  </div>
);

export const SessionIcon = Dumbbell;
export const LibraryIcon = Library;
