import { useState } from 'react';
import { CalendarDays, FileText, Play } from 'lucide-react';
import { useApp } from '../state/AppContext';
import { ACTIVITY_LABEL } from '../data/program';
import {
  addDays,
  dayNumber,
  isSameMonth,
  longDate,
  monthMatrix,
  monthName,
  parseISO,
  startOfWeek,
  weekdayShort,
} from '../lib/date';
import { Card, EmptyState, SectionTitle, StatusBadge } from '../components/ui';
import { ActivitySelector, BlockSheet, CoachNote } from '../components/workout-parts';
import { TideLevel } from '../components/ui2';
import type { SportActivity, WorkoutStatus } from '../types';

const STATUS_TONE: Record<WorkoutStatus, 'success' | 'accent' | 'warn' | 'muted'> = {
  completed: 'success',
  pending: 'accent',
  modified: 'warn',
  external: 'warn',
  rest: 'muted',
};

const STATUS_LABEL: Record<WorkoutStatus, string> = {
  completed: 'Completado',
  pending: 'Pendiente',
  modified: 'Modificado',
  external: 'Actividad externa',
  rest: 'Descanso',
};

export const CalendarScreen = ({
  onStart,
  onOnePager,
}: {
  onStart: (workoutId: string, blockIndex?: number) => void;
  onOnePager: (workoutId: string) => void;
}) => {
  const app = useApp();
  const [view, setView] = useState<'week' | 'month'>('week');
  const [selected, setSelected] = useState(app.today);
  const [editing, setEditing] = useState(false);

  const dayInfo = (date: string) => {
    const workout = app.workoutFor(date);
    const override = app.state.calendarOverrides[date] ?? null;
    const summary = workout ? app.summaryFor(workout.id) : undefined;
    let status: WorkoutStatus = 'rest';
    if (summary) status = 'completed';
    else if (override) status = 'modified';
    else if (workout?.externalActivity) status = 'external';
    else if (workout) status = 'pending';
    const title = override
      ? ACTIVITY_LABEL[override]
      : workout
        ? workout.name
        : 'Sin programar';
    return { workout, override, summary, status, title };
  };

  const weekStart = startOfWeek(selected);
  const week = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  const month = monthMatrix(selected);
  const info = dayInfo(selected);

  return (
    <div className="space-y-4">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="eyebrow">Programa</p>
          <h1 className="font-display text-3xl capitalize leading-none">
            {monthName(selected)} {parseISO(selected).getFullYear()}
          </h1>
        </div>
        <div className="flex rounded-xl border border-line bg-surface2 p-1">
          {(['week', 'month'] as const).map((v) => (
            <button
              key={v}
              type="button"
              aria-pressed={view === v}
              onClick={() => setView(v)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold ${
                view === v ? 'bg-accent text-night' : 'text-muted'
              }`}
            >
              {v === 'week' ? 'Semana' : 'Mes'}
            </button>
          ))}
        </div>
      </header>

      {view === 'week' ? (
        <ul className="space-y-2">
          {week.map((date) => {
            const d = dayInfo(date);
            const isToday = date === app.today;
            return (
              <li key={date}>
                <button
                  type="button"
                  onClick={() => {
                    setSelected(date);
                    setEditing(false);
                  }}
                  className={`card flex w-full items-center gap-3 p-3 text-left transition-colors ${
                    date === selected ? 'border-accent/50' : ''
                  }`}
                >
                  <span className="w-11 shrink-0 text-center">
                    <span className="eyebrow block">{weekdayShort(date)}</span>
                    <span className={`font-display text-xl ${isToday ? 'text-accent' : ''}`}>{dayNumber(date)}</span>
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium">{d.title}</span>
                    <span className="block font-mono text-[11px] text-muted">
                      {d.workout ? d.workout.duration : '—'}
                      {d.workout ? ` · RPE plan ${d.workout.plannedRpe}` : ''}
                      {d.summary ? ` · RPE real ${d.summary.rpe}` : ''}
                    </span>
                  </span>
                  <StatusBadge tone={STATUS_TONE[d.status]}>{STATUS_LABEL[d.status]}</StatusBadge>
                </button>
              </li>
            );
          })}
        </ul>
      ) : (
        <Card>
          <div className="mb-2 grid grid-cols-7 gap-1 text-center">
            {['LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB', 'DOM'].map((d) => (
              <span key={d} className="eyebrow">
                {d}
              </span>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {month.map((date) => {
              const d = dayInfo(date);
              const dim = !isSameMonth(date, selected);
              return (
                <button
                  key={date}
                  type="button"
                  onClick={() => {
                    setSelected(date);
                    setEditing(false);
                  }}
                  aria-label={`${longDate(date)} · ${d.title}`}
                  className={`min-h-[44px] aspect-square rounded-lg border p-1 text-left ${
                    date === selected ? 'border-accent bg-accent/10' : 'border-line bg-surface2'
                  } ${dim ? 'opacity-35' : ''}`}
                >
                  <span className={`block font-mono text-[11px] ${date === app.today ? 'text-accent' : 'text-muted'}`}>
                    {dayNumber(date)}
                  </span>
                  {d.status !== 'rest' && (
                    <span
                      aria-hidden="true"
                      className={`mt-1 block h-1.5 w-1.5 rounded-full ${
                        d.status === 'completed'
                          ? 'bg-success'
                          : d.status === 'pending'
                            ? 'bg-accent'
                            : 'bg-warn'
                      }`}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </Card>
      )}

      <section>
        <SectionTitle eyebrow="Daily card" title={longDate(selected)} />
        {info.workout ? (
          <Card className="space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="eyebrow">
                  Week {info.workout.week} · Day {info.workout.day}
                </p>
                <h3 className="font-display text-2xl font-bold leading-tight tracking-[-0.03em]">
                  {info.override ? ACTIVITY_LABEL[info.override] : info.workout.name}
                </h3>
                <p className="mt-1.5 inline-block rounded-full border border-line px-2.5 py-0.5 text-xs text-muted">
                  {info.workout.subtitle}
                </p>
              </div>
              <StatusBadge tone={STATUS_TONE[info.status]}>{STATUS_LABEL[info.status]}</StatusBadge>
            </div>

            <div className="grid grid-cols-3 gap-3 border-y border-line py-3">
              <div>
                <p className="eyebrow">Duración</p>
                <p className="font-mono text-sm">{info.workout.duration}</p>
              </div>
              <div>
                <p className="eyebrow">RPE plan</p>
                <p className="font-mono text-sm">{info.workout.plannedRpe}</p>
              </div>
              <div>
                <p className="eyebrow">RPE real</p>
                <p className="font-mono text-sm text-accent">{info.summary ? info.summary.rpe : '—'}</p>
              </div>
            </div>

            <TideLevel plannedRpe={info.workout.plannedRpe} />

            <CoachNote text={info.workout.coachNote} compact />

            <div className="space-y-5">
              {info.workout.blocks.map((b) => (
                <BlockSheet key={b.id} block={b} />
              ))}
            </div>

            {info.summary && (
              <div className="rounded-xl border border-success/30 bg-success/10 p-3 text-sm">
                <p className="eyebrow text-success">Registro</p>
                <p className="mt-1">
                  {info.summary.durationMin} min · {info.summary.setsCompleted} series ·{' '}
                  {info.summary.volumeKg > 0 ? `${info.summary.volumeKg} kg de volumen` : 'sin cargas registradas'}
                </p>
                {info.summary.comment && <p className="mt-1 text-muted">“{info.summary.comment}”</p>}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onStart(info.workout!.id)}
                className="btn-ghost"
              >
                <Play className="h-4 w-4" aria-hidden="true" /> Abrir sesión
              </button>
              <button type="button" onClick={() => onOnePager(info.workout!.id)} className="btn-ghost">
                <FileText className="h-4 w-4" aria-hidden="true" /> One Pager
              </button>
            </div>

            <div className="border-t border-line pt-3">
              <button
                type="button"
                onClick={() => setEditing((e) => !e)}
                aria-expanded={editing}
                className="btn-ghost w-full"
              >
                <CalendarDays className="h-4 w-4" aria-hidden="true" /> Cambiar actividad del día
              </button>
              {editing && (
                <div className="mt-3">
                  <ActivitySelector
                    value={info.override ?? info.workout.externalActivity ?? null}
                    onChange={(a: SportActivity) => app.setOverride(selected, a)}
                    onClear={info.override ? () => app.setOverride(selected, null) : undefined}
                  />
                </div>
              )}
            </div>
          </Card>
        ) : (
          <EmptyState
            title="Sin sesión programada"
            hint="Elegí una actividad para este día y quedará registrada en el calendario."
            action={
              <div className="mt-2 text-left">
                <ActivitySelector
                  value={info.override}
                  onChange={(a: SportActivity) => app.setOverride(selected, a)}
                  onClear={info.override ? () => app.setOverride(selected, null) : undefined}
                />
              </div>
            }
          />
        )}
      </section>
    </div>
  );
};
