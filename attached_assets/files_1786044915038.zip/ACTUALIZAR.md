# ACTUALIZACIÓN — RUTINA MENSUAL NUEVA

Este ZIP **no es el proyecto completo**: son los archivos de rutina, lógica y pantallas.
`main.tsx`, `vite.config.ts`, `tsconfig.json`, `postcss.config.js`, `package-lock.json` y
`public/` quedan intactos.

**Arrastrá el contenido sobre la raíz del Repl, aceptá sobrescribir, Run.**
No toques "Restablecer datos": tu historial se conserva.

---

## Lo que cambió

### La rutina

| Día | Sesión |
|---|---|
| **Lunes** | Rodilla + Tracción — Core · Fuerza (Sentadilla) · Atleta (Tracción) · Híbrido |
| **Martes** | Spinning 45′ |
| **Miércoles** | Cadera + Empuje — Core · Fuerza (Peso muerto) · Atleta (Banca) · Híbrido |
| **Jueves** | Pasadas — 8×50 · 10×100 · 4×200 · 1×400 |
| **Viernes** | Unipodal + Mixto — Core · Fuerza (Bulgarian) · Atleta (Mixto) · Híbrido |
| **Sábado** | Competencia — Hyrox / WOD largo |
| **Domingo** | Descanso |

Estructura de los días de fuerza: **Core (4 vueltas) → Fuerza (1 principal + 3 complementos) →
Atleta → Híbrido**. 45–50 min.

### El límite de la barra

Con 2×20 + 2×10 + 2×5 las únicas cargas posibles son **20/30/40/50/60/70/80/90 kg**.
Salto mínimo 10 kg, techo 90. Un test verifica que ninguna carga prescrita sea imposible de montar.

Por eso el mes no progresa sumando peso:

| Semana | Esquema | Sentadilla | P. muerto | Banca |
|---|---|---|---|---|
| 1 · Introducción | 3×8,6,6 | 60 | 70 | 50 |
| 2 · Tempo | 3×8,6,6 **tempo 3-1-1** | 60 | 70 | 50 |
| 3 · Carga | 4×6,4,4,4 | **70** | **80** | **60** |
| 4 · Descarga + test | 2×6,6 | 50 | 60 | 40 |

> Comprá un par de discos de 2,5 kg y otro de 1,25 kg. Sin eso, del mes 2 en adelante
> progresás solo con tempo y pausas.

### Híbridos y sábados

Los híbridos rotan formato: 50/10 · AMRAP · For Time · escalera · chipper. **Ninguno usa la
barra cargada** — verificado por test — para no cambiar discos con pulsaciones altas.

Los sábados rotan: chipper largo → 5 rondas → AMRAP 30′ → **Hyrox simulado**.
El de la semana 4 es el test del mes: mismas distancias y cargas siempre, para comparar.

### Calorías y frecuencia cardíaca

Al terminar, además de RPE, energía, dolor y comentario, la app pide:

- **Calorías**
- **FC media**
- **FC máxima**

Son opcionales. El coach feedback los usa: si la FC media quedó baja para el RPE declarado,
te avisa que probablemente los descansos se estiraron; si quedó muy alta, que la sesión se fue
a metabólico cuando buscabas fuerza. Aparecen también en el historial de Progreso.

---

## Lo que se mantiene

Temporizadores (AMRAP, For Time, 50/10, 40/20, descanso a pantalla completa), preguntas
previas con adaptaciones reales, checklist "HOY NECESITÁS", modo coach, biblioteca de
**133 ejercicios** con técnica y video, persistencia, y la continuidad: tu historial no se
borra y el programa no se re-ancla.

## Verificación

```bash
npm run qa
```

**110 verificaciones**, incluida `qa/month.ts` que audita la estructura semanal, las cargas
montables, la progresión de las cuatro semanas y que ningún híbrido use la barra.
