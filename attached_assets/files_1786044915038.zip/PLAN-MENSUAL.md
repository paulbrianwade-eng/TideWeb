# PLAN MENSUAL — 4 SEMANAS

**Paul · 38 años · 1,84 m · 85 kg → 80 kg**
Objetivo: fuerte, potente y flexible. Sin hipertrofia como fin.

---

## LO PRIMERO: EL LÍMITE DE LA BARRA

Tus discos son 2×20, 2×10 y 2×5. Con la barra de 20 kg, las **únicas** cargas posibles son:

`20 · 30 · 40 · 50 · 60 · 70 · 80 · 90 kg`

Dos consecuencias que mandan sobre todo el mes:

**1. El salto mínimo es 10 kg.** En press banca, pasar de 50 a 60 es un salto del 20 %. Ninguna progresión lineal sobrevive eso más de tres semanas.

**2. El techo es 90 kg.** En peso muerto lo vas a tocar en la semana 3 y ahí se te acaba la progresión por carga.

Por eso este mes **no progresa sumando peso**. Progresa cambiando el esquema:

| Semana | Esquema | Cómo se pone más difícil |
|---|---|---|
| 1 | 3×8,6,6 | Carga base, técnica |
| 2 | 3×8,6,6 | Misma carga, **tempo 3-1-1** en la bajada |
| 3 | 4×6,4,4,4 | **+10 kg**, una serie más |
| 4 | 2×6,6 | Descarga: −20 kg, RPE 6 |

> **Recomendación**: comprá un par de discos de 2,5 kg y otro de 1,25 kg. Cuestan poco y te dan saltos de 5 y 2,5 kg. Sin eso, a partir del mes 2 vas a progresar solo con tempo y pausas, que funciona pero se agota.

---

## LA SEMANA

| Día | Sesión | Duración |
|---|---|---|
| **Lunes** | Full Body — Rodilla + Tracción | 49 min |
| **Martes** | Spinning | 45 min |
| **Miércoles** | Full Body — Cadera + Empuje | 49 min |
| **Jueves** | Pasadas | 50 min |
| **Viernes** | Full Body — Unipodal + Mixto | 49 min |
| **Sábado** | Competencia — Hyrox / WOD largo | 55 min |
| **Domingo** | Descanso | — |

Estructura de los días de fuerza: **Core → Fuerza → Atleta → Híbrido**.

---

# SEMANA 1 — INTRODUCCIÓN
*Carga base. Terminá cada serie sintiendo que te quedaban 3 repeticiones.*

## LUNES · Rodilla + Tracción

**Core** — 4 vueltas
- Ab Wheel · 8
- Copenhagen Plank · 20″/lado
- Dead Bug con banda · 8/lado
- Glute Bridge 1P · 10/lado

**Fuerza**
| Ejercicio | Series | Carga |
|---|---|---|
| Box Squat | 3×8,6,6 | **60 kg** |
| Wall Sit | 3×30″ | — |
| Pogos asistidos | 3×10 | banda |
| Psoas dinámico | 3×5/lado | — |

**Atleta**
- Dominadas · 3×8
- Remo TRX · 3×12
- Lanzamiento SC de rodillas · 3×6 · balón 5 kg

**Híbrido 12′** — 50″/10″, 6 estaciones, 2 vueltas
Wall Ball · Box Jump · Goblet Squat KB 20 · Lunges KB 12 · Farmer March KB 20 · Run

---

## MARTES · Spinning — Base 45′
- 10′ progresivo hasta ritmo cómodo
- **5 × (3′ fuerte / 2′ suave)** — fuerte = podés decir frases cortas, no charlar
- 10′ suave

## MIÉRCOLES · Cadera + Empuje

**Core** — 4 vueltas
- TRX Body Saw · 10
- Plancha lateral con rotación · 6/lado
- Bear Plank Tap · 10/lado
- Pallof Press · 8/lado

**Fuerza**
| Ejercicio | Series | Carga |
|---|---|---|
| Peso Muerto | 3×8,6,6 | **70 kg** |
| Puente cadera ISO 1P | 3×5″/lado | — |
| KB Swing | 3×12 | KB 20 |
| 90/90 + Shin Box | 3×6 | — |

**Atleta**
| Ejercicio | Series | Carga |
|---|---|---|
| Press Banca | 3×8,6,6 | **50 kg** |
| Press ISO Push (pines) | 3×5″ | máxima intención |
| Lanzamiento acostado | 3×6 | balón 5 kg |

**Híbrido 12′** — AMRAP
10 KB Swing 20 · 8 Burpees · 12 MB Slam 10 · 40 saltos de soga
*Score: rondas + repeticiones*

---

## JUEVES · Pasadas — 50′
Entrada en calor 10′: trote suave + A-Skip + 3 progresivas de 40 m

| Bloque | Volumen | Descanso |
|---|---|---|
| 8 × 50 m | al 90 % | vuelta caminando |
| 10 × 100 m | al 85 % | 60″ |
| 4 × 200 m | al 80 % | 90″ |
| 1 × 400 m | fuerte, controlado | — |

**2.600 m de trabajo rápido.** Es mucho: si en las 100 empezás a perder velocidad, cortá en 8 y guardá para las 200.

## VIERNES · Unipodal + Mixto

**Core** — 4 vueltas
- Roll Out · 10
- Plancha lateral carrera · 10″/lado
- Bird Dog · 8/lado
- Hollow Hold · 25″

**Fuerza**
| Ejercicio | Series | Carga |
|---|---|---|
| Bulgarian Split Squat | 3×8,6,6/lado | KB 20 goblet |
| Split Squat ISO | 3×20″/lado | — |
| Skater Jump | 3×20″ | — |
| Cossack Squat | 3×6/lado | — |

**Atleta**
- Press Militar KB · 3×8/lado · KB 20
- Remo 1m/1m · 3×8/lado · KB 20
- TRX Power Pull · 3×6/lado

**Híbrido 14′** — Escalera 10-8-6-4-2, con **200 m run** entre escalones
Goblet Squat · Push-Up · KB Clean · Box Step-Up
*Score: tiempo total*

---

## SÁBADO · Competencia — Chipper largo

**Entrada en calor 10′** — 2 vueltas: 200 m trote · 90/90 8 cambios · Monster Walk 15/lado · Pogos 15 · World's Greatest Stretch 5/lado. Después 3 aceleraciones de 40 m.

**WOD — For Time**
1. 800 m run
2. 20 KB Swing · 20 Box Step-Up/lado
3. 600 m run
4. 30 Wall Ball · 30 Farmer March/lado
5. 400 m run
6. 40 Lunges con balón · 20 Burpees
7. 400 m run
8. 50 saltos de soga · 15 MB Slam
9. 800 m run

**Anotá el tiempo.** Es tu marca del mes.

**Bajada 5′** — caminata + respiración nasal 4″/8″

---

# SEMANA 2 — TEMPO
*Misma carga que la semana 1. Lo que cambia es la velocidad de bajada: **3 segundos**, 1 de pausa, subida normal. Va a costar bastante más con el mismo peso.*

**Cargas idénticas a la semana 1**: Box Squat 60 · Peso Muerto 70 · Press Banca 50.

Cambios respecto de la semana 1:

| Día | Qué cambia |
|---|---|
| **Lunes** | Box Squat con tempo 3-1-1 · Core: Hollow Hold, Plancha lateral rotación, Ab Wheel 10, Copenhagen 25″ |
| **Martes** | Spinning: **8 × (2′ fuerte / 1′ suave)** — intervalos más cortos y duros |
| **Miércoles** | Peso Muerto y Banca con tempo 3-1-1 · Híbrido: **For Time 4 vueltas** — 10 TRX Row, 10 Push-Up, 12 KB Swing, 50 soga |
| **Jueves** | Mismo volumen, ritmo objetivo **1 s más rápido** en las 100 m |
| **Viernes** | Bulgarian con tempo 3-1-1 · Híbrido: **Chipper** — 100 soga, 40 KB Swing, 30 Lunges, 20 Burpees, 10 MB Slam, 200 m |
| **Sábado** | **5 rondas For Time**: 400 m run + 15 Wall Ball + 15 KB Swing + 10 Box Step-Up/lado |

---

# SEMANA 3 — CARGA
*La semana pesada del mes. +10 kg en todo y una serie más. Esquema 4×6,4,4,4.*

| Ejercicio | Semana 1-2 | **Semana 3** |
|---|---|---|
| Box Squat | 60 kg | **70 kg** |
| Peso Muerto | 70 kg | **80 kg** |
| Press Banca | 50 kg | **60 kg** |

Sin tempo esta semana: bajada normal, foco en mover la carga.

| Día | Qué cambia |
|---|---|
| **Lunes** | Box Squat 4×6,4,4,4 @ 70 kg · Wall Sit 4×40″ |
| **Martes** | Spinning: **4 × 5′ a umbral / 3′ suave** |
| **Miércoles** | Peso Muerto 4×6,4,4,4 @ 80 kg · Banca 4×6,4,4,4 @ 60 kg |
| **Jueves** | Volumen reducido: 6×50 m · 8×100 m · 3×200 m. Las piernas están cargadas del lunes |
| **Viernes** | Bulgarian 4×6/lado con KB 20 + chaleco o mochila si tenés |
| **Sábado** | **AMRAP 30′** — 200 m run + 10 Wall Ball + 10 KB Swing + 10 Box Step-Up/lado + 15 soga |

**Si el peso muerto a 80 kg se siente liviano**, subí a 90 — pero ahí tocaste el techo y no hay más. A partir de ese punto la progresión es déficit (parado sobre un disco) o tempo.

---

# SEMANA 4 — DESCARGA Y TEST
*Bajás la carga para que el cuerpo consolide. El sábado es el test del mes.*

| Ejercicio | Semana 3 | **Semana 4** |
|---|---|---|
| Box Squat | 70 kg | **50 kg** |
| Peso Muerto | 80 kg | **60 kg** |
| Press Banca | 60 kg | **40 kg** |

Esquema **2×6,6**. RPE 6: tiene que sentirse fácil. Es intencional.

| Día | Qué cambia |
|---|---|
| **Lunes** | Fuerza a 2 series · Core a 3 vueltas · Híbrido: 1 vuelta sola |
| **Martes** | Spinning suave 35′ continuo, zona 2 |
| **Miércoles** | Igual, 2 series · sin lanzamientos |
| **Jueves** | Solo 8×100 m + 2×200 m. Sin 400 |
| **Viernes** | Fuerza a 2 series · sin híbrido, cerrás con movilidad 10′ |
| **Sábado** | **HYROX SIMULADO — el test del mes** |

## El test del sábado (semana 4)

8 rondas de **400 m run + 1 estación**:

| # | Estación |
|---|---|
| 1 | 50 m Farmer Carry KB 20 (ida y vuelta) |
| 2 | 40 Wall Ball |
| 3 | 30 Box Step-Up/lado |
| 4 | 40 KB Swing |
| 5 | 50 m Lunges con balón |
| 6 | 30 Burpees |
| 7 | 100 saltos de soga |
| 8 | 30 MB Slam |

**Anotá el tiempo total.** Este formato se repite **igual** todos los meses: mismas distancias, mismas estaciones, mismas cargas. Es lo único que te dice de verdad si mejoraste.

---

## CÓMO SÉ SI FUNCIONÓ

Al terminar el mes deberías tener:

- **Tiempo del chipper** (sábado semana 1) y **tiempo del Hyrox** (sábado semana 4)
- Peso corporal semanal, siempre a la misma hora
- Cargas reales de cada semana

Y la pregunta que importa: **¿el peso muerto a 80 kg de la semana 3 se sintió más fácil que 70 kg en la semana 1?** Si sí, el mes funcionó. Si no, el problema no fue el plan: fue el sueño, la comida o el estrés.

---

## AJUSTES SOBRE LA MARCHA

| Si pasa esto | Hacé esto |
|---|---|
| Dormiste menos de 6 h | Una vuelta menos en Core, fuerza a RPE 7, híbrido igual |
| Molestia lumbar | Peso muerto → Hip Thrust · sacá el Ab Wheel |
| Molestia de rodilla | Box Squat → Hip Thrust · sacá Box Jump y Pogos |
| Solo 30 minutos | Core 5′ + Fuerza 15′ + Híbrido 10′. Sacá el bloque Atleta |
| Las 100 m se ponen lentas | Cortá la serie. El jueves es calidad, no volumen |
