import type { ExercisePrescription, SportActivity, SportModule, Workout, WorkoutBlock } from '../types';
import { addDays } from '../lib/date';
import { isDeload, phaseFor } from './phases';
import { block } from './blocks';

export const TOTAL_WEEKS = 16;
/** Ciclo V4 anclado: no se recalcula con "hoy" en cada carga. */
export const PROGRAM_START = '2026-08-31';

export const ACTIVITY_LABEL: Record<SportActivity, string> = {
  surf: 'Surf', golf: 'Golf', ski: 'Esquí', running: 'Running', rest: 'Descanso', gym: 'Gimnasio', home: 'Entrenamiento en casa',
};

const p = (exerciseId: string, extra: Partial<ExercisePrescription> = {}): ExercisePrescription => ({ exerciseId, ...extra });
const B = (id:string, kind:WorkoutBlock['kind'], title:string, duration:string, items:ExercisePrescription[], focus:string, extra:Partial<WorkoutBlock>={}) =>
  block(id, kind, title, duration, items, { focus, ...extra });
const vol = (week:number, normal:number, deload:number) => isDeload(week) ? deload : normal;
const rounds = (week:number, normal=3) => `${vol(week,normal,2)} vueltas`;
const pick = <T,>(items:T[], week:number, offset=0):T => items[(week - 1 + offset) % items.length];

const transition = (id:string, n:number, intensity='Sostenido · RPE 6–7') => B(
  `${id}-run-${n}`,'transition','VUELTA A LA MANZANA','2–4 min',
  [p('block-run',{sets:1,reps:'1 vuelta',rpe:intensity,instructions:'Transición cardiovascular. No es sprint; volvé con control para el bloque siguiente.'})],
  'Cardio transition · mantener pulsaciones y fluidez'
);

// ---------------- ZONA MEDIA: rota sin perder patrones ----------------
const CORE_MENUS: ExercisePrescription[][] = [
  [p('ab-wheel',{reps:'8'}),p('copenhagen-plank',{duration:'20 s/lado',unilateral:true}),p('dead-bug',{reps:'8/lado',unilateral:true}),p('pallof-press',{reps:'10/lado',unilateral:true})],
  [p('trx-body-saw',{reps:'10'}),p('side-plank-rotation',{reps:'6/lado',unilateral:true}),p('bear-crawl',{distance:'10 m'}),p('hip-airplane',{reps:'5/lado',unilateral:true})],
  [p('side-plank',{duration:'25 s/lado',unilateral:true}),p('bird-dog',{reps:'8/lado',unilateral:true}),p('pallof-press',{reps:'8/lado',unilateral:true}),p('ab-wheel',{reps:'6–8'})],
  [p('dead-bug',{reps:'10/lado',unilateral:true}),p('copenhagen-plank',{duration:'15–20 s/lado',unilateral:true}),p('trx-body-saw',{reps:'8'}),p('bear-crawl',{distance:'12 m'})],
];
const core = (id:string,w:number,offset=0) => B(`${id}-core`,'core','01 · ZONA MEDIA','6–8 min',pick(CORE_MENUS,w,offset),
  'Antiextensión + antirrotación + estabilidad de cadera',{rounds:rounds(w)});

// ---------------- FUERZA: principal progresable + 2 accesorios ----------------
const lowerStrength = (id:string,w:number) => {
  const ph=phaseFor(w); const sets=vol(w, ph.strength.sets, 3);
  const main = ph.id <= 2 ? 'back-squat' : 'front-squat';
  return B(`${id}-strength`,'strength','02 · FUERZA','14–17 min',[
    p(main,{order:'A',sets,reps:ph.id===1?'6–8':ph.id===2?'5–6':'4–5',rpe:isDeload(w)?'6':'7–8',rest:ph.strength.rest,instructions:'Completar todas las series A antes de B.'}),
    p(pick(['single-leg-rdl','bulgarian-split-squat','step-down'],w),{order:'B1',sets:3,reps:'8/lado',unilateral:true,load:'KB 20 kg'}),
    p(pick(['soleus-raise','tibialis-raise','split-squat-hold'],w,1),{order:'B2',sets:3,reps:'12–20',duration:'20–30 s si es isométrico'})
  ],'Fuerza real + accesorio unilateral + durabilidad');
};

const upperStrength = (id:string,w:number) => {
  const accessory = pick([
    ['pull-up','db-lateral-raise'],
    ['trx-row','db-hammer-curl'],
    ['pull-up','db-biceps-curl'],
    ['trx-row','db-lateral-raise'],
  ],w) as string[];
  return B(`${id}-strength`,'strength','02 · FUERZA','14–17 min',[
    p('bench-press',{order:'A',sets:vol(w,4,3),reps:phaseFor(w).id<=2?'6–8':'4–6',rpe:isDeload(w)?'6':'7–8',rest:'90–120 s',instructions:'Completar A antes de los accesorios.'}),
    p(accessory[0],{order:'B1',sets:3,reps:accessory[0]==='pull-up'?'6–8':'10–12'}),
    p(accessory[1],{order:'B2',sets:3,reps:'12–15',load:'DB 5 kg'})
  ],'Mantener músculo: empuje principal + tirón + hombro/bíceps');
};

const fullStrength = (id:string,w:number) => B(`${id}-strength`,'strength','02 · FUERZA','14–17 min',[
  p(pick(['romanian-deadlift','back-squat','front-squat'],w),{order:'A',sets:vol(w,4,3),reps:phaseFor(w).id>=3?'4–6':'6–8',rpe:isDeload(w)?'6':'7–8',rest:'90–120 s',instructions:'Una sola configuración pesada de barra.'}),
  p(pick(['trx-row','pull-up','single-leg-rdl'],w,1),{order:'B1',sets:3,reps:'8–12'}),
  p(pick(['db-shoulder-press','db-hammer-curl','db-lateral-raise'],w,2),{order:'B2',sets:3,reps:'10–15',load:'DB disponibles'})
],'Fuerza global + músculo accesorio sin convertirlo en bodybuilding');

// ---------------- ATLETA: explosivo, dinámico y MUY variado ----------------
const ATHLETE_MENUS: ExercisePrescription[][] = [
  [p('hang-clean',{order:'A1',reps:'4',rpe:'6–7'}),p('box-jump',{order:'A2',reps:'5'}),p('push-press',{order:'A3',reps:'5',rpe:'6–7'}),p('threshold-run',{order:'A4',distance:'20–30 m rápido'})],
  [p('kb-snatch',{order:'A1',reps:'5/lado',unilateral:true}),p('lateral-bound',{order:'A2',reps:'5/lado',unilateral:true}),p('trx-power-pull',{order:'A3',reps:'6/lado',unilateral:true}),p('shuttle-run',{order:'A4',reps:'10-20-10 m'})],
  [p('clean-high-pull',{order:'A1',reps:'5',rpe:'6–7'}),p('broad-jump',{order:'A2',reps:'4'}),p('front-rack-reverse-lunge',{order:'A3',reps:'6/lado',unilateral:true}),p('threshold-run',{order:'A4',distance:'30 m rápido'})],
  [p('push-jerk',{order:'A1',reps:'4',rpe:'6–7'}),p('rotational-mb-throw',{order:'A2',reps:'6/lado',unilateral:true}),p('split-jump',{order:'A3',reps:'6 total'}),p('farmer-carry',{order:'A4',distance:'30 m',carry:true})],
  [p('clean-pull',{order:'A1',reps:'5',rpe:'6–7'}),p('burpee-broad-jump',{order:'A2',reps:'5'}),p('kb-clean-push-press',{order:'A3',reps:'5/lado',unilateral:true}),p('shuttle-run',{order:'A4',reps:'10-10-10 m'})],
  [p('kb-clean',{order:'A1',reps:'6/lado',unilateral:true}),p('skater-jump',{order:'A2',reps:'6/lado',unilateral:true}),p('med-ball-chest-pass',{order:'A3',reps:'8'}),p('threshold-run',{order:'A4',duration:'20 s rápido'})],
  [p('push-press',{order:'A1',reps:'6',rpe:'6–7'}),p('pogo-jump',{order:'A2',reps:'20'}),p('rotational-mb-throw',{order:'A3',reps:'5/lado',unilateral:true}),p('shuttle-run',{order:'A4',reps:'20-20 m'})],
  [p('hang-clean',{order:'A1',reps:'3',rpe:'6–7'}),p('lateral-bound',{order:'A2',reps:'5/lado',unilateral:true}),p('db-curl-to-press',{order:'A3',reps:'10'}),p('threshold-run',{order:'A4',distance:'30 m rápido'})],
];
const athlete = (id:string,w:number,offset=0) => B(`${id}-athlete`,'athletic','03 · ATLETA','10–12 min',pick(ATHLETE_MENUS,w,offset),
  'Levantamiento dinámico + salto/desplazamiento + potencia',{rounds:rounds(w),rest:'45–60 s entre vueltas · calidad antes que fatiga'});

// ---------------- FINISHERS: mixtos y rotados; swing/slam NO dominan ----------------
const FINISHERS: {mode:string; items:ExercisePrescription[]}[] = [
  {mode:'AMRAP 9 min',items:[p('spinning-bike',{duration:'35 s fuerte'}),p('db-curl-to-press',{reps:'10'}),p('box-step-over',{reps:'10'}),p('trx-row',{reps:'10'}),p('jump-rope',{reps:'40'})]},
  {mode:'FOR TIME · 4 vueltas',items:[p('threshold-run',{distance:'150 m'}),p('goblet-squat',{reps:'12',load:'KB 20 kg'}),p('db-shoulder-press',{reps:'12'}),p('burpee',{reps:'8'})]},
  {mode:'AMRAP 10 min',items:[p('kb-clean',{reps:'6/lado',unilateral:true}),p('reverse-lunge',{reps:'10 total'}),p('pull-up',{reps:'6'}),p('spinning-bike',{duration:'40 s fuerte'}),p('jump-rope',{reps:'30'})]},
  {mode:'CHIPPER',items:[p('jump-rope',{reps:'100'}),p('box-step-over',{reps:'30'}),p('db-hammer-curl',{reps:'20'}),p('burpee',{reps:'15'}),p('threshold-run',{distance:'300 m'})]},
  {mode:'AMRAP 9 min',items:[p('shuttle-run',{reps:'10-20-10 m'}),p('kb-clean-push-press',{reps:'5/lado',unilateral:true}),p('trx-row',{reps:'10'}),p('mountain-climber',{duration:'25 s'})]},
  {mode:'FOR TIME · 4 vueltas',items:[p('spinning-bike',{duration:'30 s fuerte'}),p('goblet-squat',{reps:'10'}),p('db-curl-to-press',{reps:'8'}),p('burpee-broad-jump',{reps:'5'})]},
  {mode:'LADDER 2-4-6-8-10',items:[p('push-press',{reps:'2-4-6-8-10',rpe:'6–7'}),p('pull-up',{reps:'2-4-6-8-10'}),p('threshold-run',{distance:'100 m entre escalones'})]},
  {mode:'AMRAP 10 min',items:[p('farmer-carry',{distance:'30 m',carry:true}),p('box-step-over',{reps:'12'}),p('db-biceps-curl',{reps:'12'}),p('jump-rope',{reps:'50'}),p('burpee',{reps:'6'})]},
  {mode:'FOR TIME · 3 vueltas',items:[p('threshold-run',{distance:'200 m'}),p('kb-swing',{reps:'15'}),p('push-up',{reps:'10'}),p('reverse-lunge',{reps:'12 total'}),p('jump-rope',{reps:'40'})]},
  {mode:'AMRAP 9 min',items:[p('spinning-bike',{duration:'40 s fuerte'}),p('mb-slam',{reps:'10'}),p('trx-row',{reps:'10'}),p('box-step-over',{reps:'10'}),p('mountain-climber',{duration:'20 s'})]},
];
const finisher = (id:string,w:number,offset=0) => {
  const chosen=pick(FINISHERS,w,offset);
  const mode=isDeload(w)?chosen.mode.replace(/10 min|9 min/g,'7 min').replace('4 vueltas','3 vueltas'):chosen.mode;
  return B(`${id}-finisher`,'finisher','04 · FINISHER',isDeload(w)?'7–8 min':'8–11 min',chosen.items,
    'Metabólico mixto · varias estaciones · score registrable',{rounds:mode,rest:'Solo lo necesario · RPE 8–9'});
};

interface DayPlan { name:string; subtitle:string; objective:string; duration:string; rpe:string; next:SportActivity|null; modules:SportModule[]; external?:SportActivity; build:(id:string,week:number)=>WorkoutBlock[]; note:(week:number)=>string; }

const DAYS:DayPlan[]=[
  {name:'LOWER IGNITION',subtitle:'Lower strength · Explosive',objective:'Ganar/preservar músculo y fuerza de piernas mientras desarrollás potencia y gastás energía.',duration:'47–50 min',rpe:'8',next:'gym',modules:[],build:(id,w)=>[
    core(id,w,0),lowerStrength(id,w),transition(id,1),athlete(id,w,0),transition(id,2,'Sostenido/fuerte controlado · RPE 7'),finisher(id,w,0)
  ],note:()=> 'Fuerza progresable; Atleta explosivo; cardio distribuido; finisher mixto sin abusar de swings/slams.'},

  {name:'UPPER ENGINE',subtitle:'Upper muscle · Surf base',objective:'Mantener/subir masa de espalda, pecho, hombros y brazos con potencia útil para surf.',duration:'46–50 min',rpe:'8',next:'running',modules:['surf'],build:(id,w)=>[
    core(id,w,1),upperStrength(id,w),transition(id,1),athlete(id,w,2),finisher(id,w,2)
  ],note:()=> 'Más músculo sin repetir push/pull por toda la sesión. Hombros y bíceps aparecen estratégicamente.'},

  {name:'ENGINE & MOVE',subtitle:'Aerobic base · Mobility · Athletic',objective:'Mejorar motor y movilidad sin sumar otra sesión pesada de barra.',duration:'42–50 min',rpe:'6–7',next:'gym',modules:['running'],build:(id,w)=>[
    core(id,w,2),
    B(`${id}-engine`,'engine','02 · ENGINE','22–30 min',[p(pick(['spinning-bike','zone2-run'],w),{duration:'22–30 min',rpe:'4–6',instructions:'Ritmo conversacional o tempo controlado según fase.'})],'Base aeróbica / tempo sin impacto innecesario'),
    B(`${id}-mobility`,'movement','03 · MOBILITY','10–12 min',[p('hip-9090',{reps:'8 cambios'}),p('open-book',{reps:'8/lado',unilateral:true}),p('hip-flexor-stretch',{duration:'45 s/lado',unilateral:true}),p('shoulder-cars',{reps:'5/lado',unilateral:true})],'Cadera + tórax + hombro')
  ],note:()=> 'Este día baja el estrés neuromuscular: necesitás motor y movilidad para llegar liviano y fresco a la fase específica.'},

  {name:'ROTATE & DRIVE',subtitle:'Full body · Golf power',objective:'Fuerza global, potencia rotacional, frenado y estabilidad para golf.',duration:'47–50 min',rpe:'8',next:'gym',modules:['golf'],build:(id,w)=>[
    core(id,w,3),fullStrength(id,w),transition(id,1),athlete(id,w,4),transition(id,2),finisher(id,w,4)
  ],note:()=> 'Golf: producir fuerza desde el piso, transferirla rápido y poder frenarla.'},

  {name:'FULL SEND',subtitle:'Athletic hybrid · Variety day',objective:'Cerrar la semana con potencia, músculo útil, variedad y capacidad de trabajo.',duration:'47–50 min',rpe:'8–9',next:'rest',modules:['surf','golf'],build:(id,w)=>[
    core(id,w,1),
    B(`${id}-strength`,'strength','02 · FUERZA / POWER','13–15 min',[
      p(pick(['hang-clean','clean-high-pull','push-jerk','clean-pull'],w),{order:'A',sets:vol(w,5,3),reps:'3–5',rpe:'6–7',rest:'75–90 s',instructions:'Velocidad y técnica. No llevar al fallo.'}),
      p(pick(['pull-up','trx-row','db-shoulder-press'],w,1),{order:'B1',sets:3,reps:'8–12'}),
      p(pick(['db-biceps-curl','db-lateral-raise','db-hammer-curl'],w,2),{order:'B2',sets:3,reps:'12–15'})
    ],'Potencia olímpica + accesorio de músculo'),
    transition(id,1),athlete(id,w,6),transition(id,2,'Fuerte controlado · RPE 7–8'),finisher(id,w,6)
  ],note:()=> 'La variedad vive acá, pero no es aleatoria: olímpico + salto/desplazamiento + músculo accesorio + finisher competitivo.'},

  {name:'ZONE 2 / PLAY',subtitle:'Bike · Run · Golf · Outdoor',objective:'Aumentar gasto y base aeróbica con bajo costo de recuperación.',duration:'40–60 min',rpe:'4–5',next:'rest',modules:['running'],external:'running',build:(id,w)=>[
    B(`${id}-z2`,'movement','ZONE 2 / PLAY','35–50 min',[p(pick(['spinning-bike','zone2-run'],w),{duration:'35–50 min',rpe:'4–5',instructions:'Ritmo conversacional. Si jugás golf o hacés otra actividad outdoor, eso reemplaza este bloque.'})],'Base aeróbica y movimiento'),
    B(`${id}-mobility`,'recovery','MOBILITY','8–10 min',[p('hip-9090',{reps:'8'}),p('open-book',{reps:'8/lado',unilateral:true}),p('hip-flexor-stretch',{duration:'45 s/lado',unilateral:true})],'Movilidad mínima efectiva')
  ],note:()=> 'Opcional según recuperación y actividad outdoor.'},

  {name:'REST',subtitle:'Recovery',objective:'Recuperar para mantener rendimiento, músculo y adherencia al déficit.',duration:'Descanso',rpe:'1–2',next:'gym',modules:[],external:'rest',build:(id)=>[
    B(`${id}-restore`,'recovery','RESTORE','10–20 min',[p('nasal-breathing',{duration:'3 min'}),p('hip-flow',{duration:'5 min'}),p('easy-walk',{duration:'10–20 min'})],'Recuperación opcional')
  ],note:()=> 'Descansar forma parte del plan.'}
];

export const WEEK_STRUCTURE=DAYS.map(d=>({name:d.name,subtitle:d.subtitle}));
const buildWorkout=(week:number,dayIndex:number,date:string):Workout=>{const plan=DAYS[dayIndex];const id=`w${week}d${dayIndex+1}`;const blocks=plan.build(id,week);return{id,week,day:dayIndex+1,date,name:plan.name,subtitle:plan.subtitle,objective:plan.objective,duration:plan.duration,plannedRpe:isDeload(week)?'6–7':plan.rpe,coachNote:plan.note(week),nextDayActivity:plan.next,blocks,adaptations:[],status:plan.external?'external':'pending',externalActivity:plan.external,phase:phaseFor(week).id,modules:plan.modules};};
export const buildProgram=(start:string=PROGRAM_START):Workout[]=>{const out:Workout[]=[];for(let w=1;w<=TOTAL_WEEKS;w++)for(let d=0;d<DAYS.length;d++)out.push(buildWorkout(w,d,addDays(start,(w-1)*7+d)));return out;};
export { phaseFor, weekInPhase, isDeload, PHASES } from './phases';
