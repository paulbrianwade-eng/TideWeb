/** Verifica el motor de patrones: no duplicación, balance, límites y coach mode. */
import { buildProgram } from '../src/data/program';
import { analyzeSession, autoFix, explainSession } from '../src/lib/intelligence';
import { HEAVY, untaggedExercises, primaryPattern } from '../src/data/patterns';
import { EXERCISES } from '../src/data/exercises';
import type { Workout } from '../src/types';

let failed = 0;
const check = (name: string, ok: boolean, detail = '') => {
  console.log(`${ok ? 'OK  ' : 'FAIL'} ${name}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failed += 1;
};

const prog = buildProgram('2026-01-05');
const main = prog.filter((w) => !w.externalActivity && w.name !== 'Recovery');

// ── Taxonomía ──
check('Todos los ejercicios tienen patrón asignado', untaggedExercises().length === 0, `${untaggedExercises().length} sin clasificar`);
check('La biblioteca cubre los patrones clave',
  ['upper-push', 'upper-pull', 'squat', 'hinge', 'rotation', 'anti-rotation', 'locomotion', 'plyometrics']
    .every((p) => EXERCISES.some((e) => primaryPattern(e.id) === p)));

// ── Validación de las 20 sesiones principales ──
const invalid = main.filter((w) => !analyzeSession(w).valid);
check('Las 20 sesiones principales pasan la validación', invalid.length === 0,
  invalid.map((w) => `S${w.week} ${w.name}`).join(', '));

const warnings = main.flatMap((w) => analyzeSession(w).issues.filter((i) => i.severity === 'warning'));
check('Sin advertencias de programación', warnings.length === 0, `${warnings.length}`);

// ── Límites de patrones pesados ──
const heavyViolations = main.filter((w) => {
  const counts: Record<string, number> = {};
  w.blocks.forEach((b) => b.items.forEach((i) => {
    const h = HEAVY[i.exerciseId];
    if (h) counts[h] = (counts[h] ?? 0) + 1;
  }));
  return Object.values(counts).some((n) => n > 1);
});
check('Máximo 1 sentadilla / bisagra / press / tracción pesada por sesión', heavyViolations.length === 0);

// ── Balance ──
const noRotation = main.filter((w) => {
  const a = analyzeSession(w);
  return (a.counts.rotation ?? 0) + (a.counts['anti-rotation'] ?? 0) === 0;
});
check('Toda sesión tiene rotación o antirrotación', noRotation.length === 0);

const noUnilateral = main.filter((w) => analyzeSession(w).unilateral === 0);
check('Toda sesión tiene trabajo unilateral', noUnilateral.length === 0);

const noAthletic = main.filter((w) => {
  const a = analyzeSession(w);
  return (a.counts.plyometrics ?? 0) + (a.counts.locomotion ?? 0) === 0;
});
check('Toda sesión tiene un movimiento atlético', noAthletic.length === 0);

const pushHeavy = main.filter((w) => {
  const a = analyzeSession(w);
  return a.push > 0 && a.pull === 0;
});
check('Nunca hay empuje sin tracción', pushHeavy.length === 0);

// ── El validador detecta programación pobre a propósito ──
const badSession: Workout = {
  ...main[0],
  blocks: main[0].blocks.map((b, i) =>
    i === 1
      ? { ...b, items: [
          { exerciseId: 'bench-press', order: 'A', sets: 5, reps: '5' },
          { exerciseId: 'push-up', order: 'B1', sets: 3, reps: '10' },
          { exerciseId: 'trx-push-up', order: 'B2', sets: 3, reps: '10' },
        ] }
      : b,
  ),
};
const badAnalysis = analyzeSession(badSession);
check('Detecta bench → push-up → TRX push-up como programación pobre',
  badAnalysis.issues.some((i) => i.id.includes('dup')),
  badAnalysis.issues.map((i) => i.id).join(', '));
check('Propone una sustitución concreta',
  badAnalysis.issues.some((i) => i.fix?.to),
  badAnalysis.issues.find((i) => i.fix)?.fix?.to ?? 'ninguna');

// ── autoFix resuelve lo que detectó ──
const fixed = autoFix(badSession);
const changed = JSON.stringify(fixed.blocks) !== JSON.stringify(badSession.blocks);
check('autoFix aplica la sustitución', changed);

// ── Detecta dos pesados del mismo tipo ──
const doubleHeavy: Workout = {
  ...main[0],
  blocks: main[0].blocks.map((b, i) =>
    i === 1
      ? { ...b, items: [
          { exerciseId: 'back-squat', order: 'A', sets: 5, reps: '5' },
          { exerciseId: 'front-squat', order: 'B', sets: 3, reps: '5' },
        ] }
      : b,
  ),
};
check('Detecta dos sentadillas pesadas', analyzeSession(doubleHeavy).issues.some((i) => i.id === 'heavy-squat'));

// ── Diversidad: el principal no se repite dos semanas seguidas ──
[1, 2, 4, 5].forEach((day) => {
  const mains = prog.filter((w) => w.day === day).map((w) => w.blocks[1]?.items[0]?.exerciseId);
  const repeatsInARow = mains.some((m, i) => i > 0 && m === mains[i - 1]);
  check(`Día ${day}: el principal cambia cada semana`, !repeatsInARow, mains.join(' → '));
});

const tuesdayPulls = prog.filter((w) => w.day === 2).map((w) => w.blocks[1].items[1].exerciseId);
check('La tracción del martes rota 4 variantes', new Set(tuesdayPulls).size === 4, tuesdayPulls.join(' → '));

// ── Coach mode ──
const explanations = main.map(explainSession);
check('Toda sesión tiene explicación', explanations.every((e) => e.length > 80));
check('Las explicaciones no son todas iguales', new Set(explanations).size >= 5, `${new Set(explanations).size} distintas`);
check('La explicación nombra el deporte', main.filter((w) => w.transfersTo.length).every((w) => {
  const e = explainSession(w).toLowerCase();
  return ['esquí', 'surf', 'golf', 'running', 'atlético'].some((s) => e.includes(s));
}));

console.log(`\nSesiones analizadas: ${main.length} · ejercicios clasificados: ${EXERCISES.length}`);
if (failed) {
  console.error(`\n${failed} verificaciones fallaron`);
  process.exit(1);
}
