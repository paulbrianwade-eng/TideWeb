# ACTUALIZAR SIN PERDER LO QUE YA ENTRENASTE

Este ZIP **no es el proyecto completo**. Son solo los archivos de rutina y lógica que cambiaron.

Todo lo demás de tu Repl queda intacto: `main.tsx`, `vite.config.ts`, `tsconfig.json`,
`postcss.config.js`, `package-lock.json`, `public/`, `src/lib/date.ts`, `src/lib/records.ts`
y `src/data/defaults.ts` **no se tocan**.

---

## Cómo aplicarlo

1. Abrí tu Repl.
2. Arrastrá el contenido de este ZIP sobre la raíz del proyecto, respetando las carpetas.
   Replit va a pedir confirmación para sobrescribir: aceptá.
3. `npm install` (solo si Replit avisa que faltan dependencias).
4. **Run**.

No borres `localStorage`. No uses "Restablecer datos" en Perfil.

---

## Por qué no se pierde nada

Tu entrenamiento del lunes vive en `localStorage`, no en los archivos. Reemplazar código
no lo borra. Pero había **dos bugs reales** que sí te lo hubieran arruinado, y están corregidos:

### 1. El programa se re-anclaba a "hoy" en cada carga

Antes, `PROGRAM_START` se calculaba con la fecha del momento en que abrías la app. Si hacías
Strong Legs el lunes y abrías el miércoles, el miércoles pasaba a ser el Día 1 y te mostraba
Strong Legs otra vez.

Ahora la fecha de arranque se guarda la primera vez y **no se recalcula nunca más**. Si arrancaste
un lunes, el lunes sigue siendo el Día 1.

### 2. Cambiar de versión borraba el estado entero

Antes, si la versión guardada no coincidía con la del código, se devolvía un estado vacío.
Cualquier actualización de lógica te borraba el historial.

Ahora hay una **migración** que conserva historial, sesiones, series registradas, métricas,
readiness y la fecha de arranque. Solo se descarta lo que dejó de existir en el modelo nuevo.

### 3. La app avanza con vos, no con el reloj

La pantalla Hoy detecta que Strong Legs ya está registrado y muestra la **siguiente sesión
pendiente** con un aviso: *"Ya registraste Strong Legs. Seguimos con la próxima sesión del plan."*

Los ids de sesión (`w1d1`, `w1d2`, `w2d1`…) dependen de la posición en el programa, no del
contenido. Por eso podés cambiar los ejercicios del lunes y tu registro del lunes sigue
apuntando al lunes.

---

## Qué cambió en la rutina

Estás en la **semana 1, con el lunes hecho**. Lo próximo que te toca es el martes.

El motor nuevo detectó y corrigió tres errores de programación que tenía la versión anterior:

| Problema | Corrección |
|---|---|
| Lunes: box squat → split squat → step down = tres sentadillas seguidas | El tercero pasó a soleus raise |
| Miércoles: skipping → sprint → lateral shuffle = tres locomociones | El último pasó a single-leg RDL |
| Viernes: empuje sin nada de tracción | TRX push-up pasó a TRX row |
| Circuito Atleta sin ningún salto ni sprint | Push-up explosivo pasó a lateral bound |

> **El lunes que ya hiciste cambió levemente**: donde hacías step-down, ahora va soleus raise.
> Tu registro queda igual — no se toca lo que guardaste. El cambio aplica de la semana que viene
> en adelante, cuando el lunes vuelva a aparecer.

Además, ahora **ningún ejercicio principal se repite dos semanas seguidas**:

| Día | S1 | S2 | S3 | S4 |
|---|---|---|---|---|
| Lunes | Box Squat | Front Squat | Back Squat | Box Squat |
| Martes (empuje) | Bench Press | Incline Bench | Bench Press | TRX Push-Up |
| Martes (tracción) | TRX Row | Inverted Row | Pull-Up | Power Pull |
| Jueves | Push Press | Overhead Press | Push Press | KB Press |
| Viernes | Hang Power Clean | KB Clean | Hang Power Clean | KB Swing |

---

## Verificar que quedó bien

```bash
npm run qa
```

Debería dar: **41/41** en el flujo, y todas las auditorías en verde, incluida
`qa/continuity.ts`, que comprueba exactamente esto:

- Con la misma fecha de inicio el calendario es idéntico
- El Día 1 sigue siendo el día de arranque, no hoy
- La migración conserva historial, series y métricas
- Cambiar los ejercicios no cambia el id de la sesión
- Con el lunes hecho, la próxima pendiente es el martes

Si algo salió mal, en Perfil está "Restablecer datos" — pero eso **sí** borra tu historial,
así que usalo solo como último recurso.
