// Storage de cargas usadas por ejercicio
// Para mostrar "última vez: X kg × Y reps" en la próxima sesión

const KEY = 'bigg_at_home_loads_v1'

export function getAllLoads() {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? JSON.parse(raw) : {}
  } catch (e) {
    return {}
  }
}

export function getLastLoad(exerciseId) {
  const all = getAllLoads()
  const entries = all[exerciseId]
  if (!entries || !entries.length) return null
  // Última entrada (más reciente)
  return entries[entries.length - 1]
}

export function getPR(exerciseId) {
  const all = getAllLoads()
  const entries = all[exerciseId]
  if (!entries || !entries.length) return null
  // Mayor carga histórica
  return entries.reduce((max, e) => {
    if (!e.weight) return max
    if (!max || e.weight > max.weight) return e
    return max
  }, null)
}

export function saveLoad(exerciseId, exerciseName, data) {
  const all = getAllLoads()
  if (!all[exerciseId]) all[exerciseId] = []
  all[exerciseId].push({
    date: new Date().toISOString(),
    name: exerciseName,
    weight: data.weight ? parseFloat(data.weight) : null,
    reps: data.reps ? parseInt(data.reps) : null,
    notes: data.notes || null,
  })
  // Limita historial a 20 entradas por ejercicio
  if (all[exerciseId].length > 20) {
    all[exerciseId] = all[exerciseId].slice(-20)
  }
  try {
    localStorage.setItem(KEY, JSON.stringify(all))
  } catch (e) {}
}

export function deleteLoadHistory(exerciseId) {
  const all = getAllLoads()
  delete all[exerciseId]
  try {
    localStorage.setItem(KEY, JSON.stringify(all))
  } catch (e) {}
}

// Identifica si un ejercicio "trackea peso" (tiene `target` o nombre con barbell/KB/DB)
export function isWeightedExercise(exercise) {
  if (exercise.target) return true
  const name = exercise.name.toLowerCase()
  return /barbell|deadlift|squat|press|row|hip thrust|kb |ddb |db /.test(name)
}
