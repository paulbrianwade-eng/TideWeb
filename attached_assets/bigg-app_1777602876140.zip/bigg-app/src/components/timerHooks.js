import { useEffect, useRef, useState } from 'react'

// Cronómetro ascendente (sesión global)
export function useElapsedTimer(running) {
  const [seconds, setSeconds] = useState(0)
  const startRef = useRef(null)
  const intervalRef = useRef(null)

  useEffect(() => {
    if (running) {
      startRef.current = Date.now() - seconds * 1000
      intervalRef.current = setInterval(() => {
        setSeconds(Math.floor((Date.now() - startRef.current) / 1000))
      }, 250)
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [running])

  function reset() { setSeconds(0); startRef.current = Date.now() }
  return { seconds, reset }
}

// Cronómetro regresivo (timer de bloque o descanso)
export function useCountdown(initialSeconds, onComplete) {
  const [remaining, setRemaining] = useState(initialSeconds)
  const [running, setRunning] = useState(false)
  const intervalRef = useRef(null)
  const onCompleteRef = useRef(onComplete)
  onCompleteRef.current = onComplete

  useEffect(() => {
    if (running && remaining > 0) {
      intervalRef.current = setInterval(() => {
        setRemaining(r => {
          if (r <= 1) {
            clearInterval(intervalRef.current)
            setRunning(false)
            // Beep + vibración
            beep()
            if (navigator.vibrate) navigator.vibrate([200, 100, 200])
            if (onCompleteRef.current) onCompleteRef.current()
            return 0
          }
          return r - 1
        })
      }, 1000)
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [running])

  function start() { setRunning(true) }
  function pause() { setRunning(false) }
  function reset(newSeconds) {
    setRunning(false)
    setRemaining(newSeconds !== undefined ? newSeconds : initialSeconds)
  }
  function skip() {
    setRunning(false)
    setRemaining(0)
    if (onCompleteRef.current) onCompleteRef.current()
  }

  return { remaining, running, start, pause, reset, skip }
}

export function formatTime(seconds) {
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m}:${String(s).padStart(2, '0')}`
}

// Sonido beep simple usando Web Audio API
let audioCtx = null
export function beep() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)()
    const osc = audioCtx.createOscillator()
    const gain = audioCtx.createGain()
    osc.connect(gain)
    gain.connect(audioCtx.destination)
    osc.frequency.value = 880
    osc.type = 'sine'
    gain.gain.setValueAtTime(0.3, audioCtx.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.5)
    osc.start()
    osc.stop(audioCtx.currentTime + 0.5)
  } catch (e) {}
}
