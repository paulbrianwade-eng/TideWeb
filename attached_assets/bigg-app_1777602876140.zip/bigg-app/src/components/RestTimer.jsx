import { useEffect } from 'react'
import { Pause, Play, X, SkipForward, Plus } from 'lucide-react'
import { useCountdown, formatTime } from './timerHooks'

// Convierte "60\"" o "90"" a segundos
export function parseRest(rest) {
  if (!rest) return 0
  const m = rest.match(/(\d+)/)
  return m ? parseInt(m[1]) : 0
}

export default function RestTimer({ seconds, exerciseName, onClose }) {
  const cd = useCountdown(seconds, () => {
    // Cuando termina, cierra automáticamente después de un breve momento
    setTimeout(onClose, 600)
  })

  // Auto-iniciar al abrir
  useEffect(() => {
    cd.start()
  }, [])

  function addTime() {
    cd.reset(cd.remaining + 15)
    cd.start()
  }

  const progress = seconds > 0 ? ((seconds - cd.remaining) / seconds) * 100 : 100

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-md">
      <div className="bg-white w-full max-w-[480px] rounded-t-3xl p-6 animate-slide-in">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Descanso</span>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <p className="text-sm text-gray-500 mb-6 truncate">Próximo: {exerciseName}</p>

        {/* Círculo de progreso */}
        <div className="relative w-56 h-56 mx-auto mb-6">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="45" stroke="#E5E7EB" strokeWidth="6" fill="none" />
            <circle
              cx="50" cy="50" r="45"
              stroke="#C8FF00"
              strokeWidth="6"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 45}`}
              strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
              className="transition-all duration-1000 ease-linear"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="font-display text-5xl">{formatTime(cd.remaining)}</div>
            <div className="text-xs text-gray-500 mt-1">
              {cd.remaining === 0 ? '¡Vamos!' : 'Recuperación'}
            </div>
          </div>
        </div>

        {/* Controles */}
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={addTime}
            className="py-3 bg-gray-100 text-bigg-dark font-bold rounded-xl active:scale-[0.97] flex items-center justify-center gap-1"
          >
            <Plus className="w-4 h-4" /> 15s
          </button>
          <button
            onClick={cd.running ? cd.pause : cd.start}
            className="py-3 bg-bigg-lime text-bigg-dark font-bold rounded-xl active:scale-[0.97] flex items-center justify-center gap-1"
          >
            {cd.running ? <><Pause className="w-4 h-4" /> Pausa</> : <><Play className="w-4 h-4" /> Reanudar</>}
          </button>
          <button
            onClick={cd.skip}
            className="py-3 bg-gray-100 text-bigg-dark font-bold rounded-xl active:scale-[0.97] flex items-center justify-center gap-1"
          >
            <SkipForward className="w-4 h-4" /> Saltar
          </button>
        </div>
      </div>
    </div>
  )
}
