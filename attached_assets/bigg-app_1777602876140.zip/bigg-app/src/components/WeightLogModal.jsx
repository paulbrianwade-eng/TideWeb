import { useState } from 'react'
import { X, TrendingUp, TrendingDown, Minus } from 'lucide-react'
import { saveLoad, getLastLoad } from '../data/loads'

export default function WeightLogModal({ exercise, onClose, onSaved }) {
  const last = getLastLoad(exercise.id)
  const [weight, setWeight] = useState('')
  const [reps, setReps] = useState('')

  function handleSave() {
    saveLoad(exercise.id, exercise.name, { weight, reps })
    onSaved?.()
    onClose()
  }

  function handleSkip() {
    onClose()
  }

  function fillSame() {
    if (last) {
      if (last.weight) setWeight(String(last.weight))
      if (last.reps) setReps(String(last.reps))
    }
  }

  // Comparación con última vez
  const w = parseFloat(weight)
  const diff = last && w && last.weight ? w - last.weight : 0
  const diffPercent = last && w && last.weight ? ((w - last.weight) / last.weight) * 100 : 0

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-[480px] rounded-t-3xl p-6 animate-slide-in">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Registrar carga</span>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <h3 className="font-display text-xl mb-1 leading-tight">{exercise.name}</h3>
        {exercise.target && (
          <p className="text-xs text-gray-500 mb-4">Sugerido: {exercise.target}</p>
        )}

        {/* Última vez */}
        {last && (
          <div className="bg-gray-100 rounded-xl p-3 mb-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center flex-shrink-0">
              <TrendingUp className="w-5 h-5 text-bigg-dark" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-gray-500 mb-0.5">Última vez</p>
              <p className="font-bold text-sm">
                {last.weight ? `${last.weight} kg` : '—'}
                {last.reps && ` × ${last.reps} reps`}
              </p>
            </div>
            <button
              onClick={fillSame}
              className="text-xs font-bold text-bigg-dark bg-bigg-lime px-3 py-1.5 rounded-lg active:scale-95"
            >
              Usar
            </button>
          </div>
        )}

        {/* Inputs */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">Peso</label>
            <div className="relative">
              <input
                type="number"
                inputMode="decimal"
                step="0.5"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder="0"
                className="w-full px-4 py-3 bg-gray-100 rounded-xl text-base font-bold focus:outline-none focus:ring-2 focus:ring-bigg-lime"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400 font-medium">kg</span>
            </div>
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">Reps</label>
            <input
              type="number"
              inputMode="numeric"
              value={reps}
              onChange={(e) => setReps(e.target.value)}
              placeholder="0"
              className="w-full px-4 py-3 bg-gray-100 rounded-xl text-base font-bold focus:outline-none focus:ring-2 focus:ring-bigg-lime"
            />
          </div>
        </div>

        {/* Comparación */}
        {last && last.weight && weight && (
          <div className={`rounded-xl p-3 mb-4 flex items-center gap-2 ${
            diff > 0 ? 'bg-green-50 text-green-700' :
            diff < 0 ? 'bg-orange-50 text-orange-700' :
            'bg-gray-100 text-gray-600'
          }`}>
            {diff > 0 ? <TrendingUp className="w-4 h-4" /> :
             diff < 0 ? <TrendingDown className="w-4 h-4" /> :
             <Minus className="w-4 h-4" />}
            <span className="text-sm font-bold">
              {diff > 0 && `+${diff.toFixed(1)} kg (${diffPercent.toFixed(1)}%)`}
              {diff < 0 && `${diff.toFixed(1)} kg (${diffPercent.toFixed(1)}%)`}
              {diff === 0 && 'Mismo peso'}
            </span>
            <span className="text-xs ml-auto opacity-70">vs última vez</span>
          </div>
        )}

        {/* Acciones */}
        <div className="flex gap-2">
          <button
            onClick={handleSkip}
            className="flex-1 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl active:scale-[0.98]"
          >
            Saltar
          </button>
          <button
            onClick={handleSave}
            disabled={!weight && !reps}
            className="flex-1 py-3 bg-bigg-lime text-bigg-dark font-bold rounded-xl active:scale-[0.98] disabled:opacity-40"
          >
            Guardar
          </button>
        </div>
      </div>
    </div>
  )
}
