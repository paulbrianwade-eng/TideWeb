import { useState } from 'react'
import { X, Heart, Flame, Clock } from 'lucide-react'
import { formatTime } from './timerHooks'

export default function FinishWorkoutModal({ day, elapsedSeconds, onClose, onSave }) {
  const [avgHR, setAvgHR] = useState('')
  const [calories, setCalories] = useState('')
  const [feel, setFeel] = useState(null)
  const [notes, setNotes] = useState('')

  const feelOptions = [
    { value: 'easy',     label: '😎', text: 'Fácil',     color: 'bg-green-100 text-green-700' },
    { value: 'moderate', label: '😅', text: 'Moderado',  color: 'bg-yellow-100 text-yellow-700' },
    { value: 'hard',     label: '🥵', text: 'Duro',      color: 'bg-orange-100 text-orange-700' },
    { value: 'brutal',   label: '💀', text: 'Brutal',    color: 'bg-red-100 text-red-700' },
  ]

  function handleSave() {
    onSave({
      dayId: day.id,
      dayName: day.name,
      dayTitle: day.title,
      duration: elapsedSeconds ? Math.round(elapsedSeconds / 60) : day.duration,
      type: day.type,
      date: new Date().toISOString(),
      avgHR: avgHR ? parseInt(avgHR) : null,
      calories: calories ? parseInt(calories) : null,
      feel,
      notes: notes.trim() || null,
    })
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-[480px] rounded-t-3xl sm:rounded-3xl p-6 max-h-[92vh] overflow-y-auto animate-slide-in">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Resumen del entrenamiento</span>
          <button onClick={onClose} className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center">
            <X className="w-5 h-5" />
          </button>
        </div>
        <h2 className="font-display text-2xl mb-1 leading-tight">{day.title}</h2>
        <p className="text-sm text-gray-500 mb-3">{day.name} · {day.subtitle}</p>

        {/* Tiempo cronometrado */}
        {elapsedSeconds > 0 && (
          <div className="bg-bigg-dark text-white rounded-xl p-3 mb-5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-bigg-lime flex items-center justify-center flex-shrink-0">
              <Clock className="w-5 h-5 text-bigg-dark" strokeWidth={2.5} />
            </div>
            <div>
              <div className="text-[10px] font-bold text-white/60 uppercase tracking-wider">Tiempo entrenado</div>
              <div className="font-display text-2xl leading-none">{formatTime(elapsedSeconds)}</div>
            </div>
          </div>
        )}

        <div className="mb-5">
          <label className="flex items-center gap-2 text-sm font-bold mb-2">
            <Heart className="w-4 h-4 text-red-500 fill-red-500" />
            Frecuencia cardíaca promedio
          </label>
          <div className="relative">
            <input
              type="number"
              inputMode="numeric"
              value={avgHR}
              onChange={(e) => setAvgHR(e.target.value)}
              placeholder="ej: 145"
              className="w-full px-4 py-3 bg-gray-100 rounded-xl text-base font-medium focus:outline-none focus:ring-2 focus:ring-bigg-lime"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-gray-400 font-medium">ppm</span>
          </div>
        </div>

        <div className="mb-5">
          <label className="flex items-center gap-2 text-sm font-bold mb-2">
            <Flame className="w-4 h-4 text-orange-500 fill-orange-500" />
            Calorías quemadas
          </label>
          <div className="relative">
            <input
              type="number"
              inputMode="numeric"
              value={calories}
              onChange={(e) => setCalories(e.target.value)}
              placeholder="ej: 480"
              className="w-full px-4 py-3 bg-gray-100 rounded-xl text-base font-medium focus:outline-none focus:ring-2 focus:ring-bigg-lime"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-gray-400 font-medium">kcal</span>
          </div>
        </div>

        <div className="mb-5">
          <label className="block text-sm font-bold mb-2">¿Cómo lo sentiste?</label>
          <div className="grid grid-cols-4 gap-2">
            {feelOptions.map(opt => (
              <button
                key={opt.value}
                onClick={() => setFeel(opt.value)}
                className={`py-3 rounded-xl text-center transition-all ${
                  feel === opt.value
                    ? `${opt.color} ring-2 ring-bigg-dark`
                    : 'bg-gray-100 hover:bg-gray-200'
                }`}
              >
                <div className="text-2xl mb-0.5">{opt.label}</div>
                <div className="text-[10px] font-bold uppercase tracking-wider">{opt.text}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-bold mb-2">Notas <span className="text-gray-400 font-normal">(opcional)</span></label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="ej: subí 2.5kg en bench, llegué a 4 rondas en el AMRAP..."
            rows={3}
            className="w-full px-4 py-3 bg-gray-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-bigg-lime resize-none"
          />
        </div>

        <div className="flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl active:scale-[0.98] transition-transform"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-3 bg-bigg-lime text-bigg-dark font-bold rounded-xl active:scale-[0.98] transition-transform"
          >
            Guardar
          </button>
        </div>
      </div>
    </div>
  )
}
