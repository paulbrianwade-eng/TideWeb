import { useState } from 'react'
import { Play, Pause, RotateCcw, SkipForward, Clock } from 'lucide-react'
import ExerciseRow from './ExerciseRow'
import { useCountdown, formatTime } from './timerHooks'

const blockColors = {
  warmup:   { bg: 'bg-gray-100',    text: 'text-gray-600',    label: 'CALENTAMIENTO' },
  quality:  { bg: 'bg-blue-100',    text: 'text-blue-700',    label: 'CALIDAD' },
  strength: { bg: 'bg-red-100',     text: 'text-red-700',     label: 'FUERZA' },
  metcon:   { bg: 'bg-orange-100',  text: 'text-orange-700',  label: 'METCON' },
  finisher: { bg: 'bg-purple-100',  text: 'text-purple-700',  label: 'FINISHER' },
  run:      { bg: 'bg-amber-100',   text: 'text-amber-700',   label: 'CARRERA' },
}

export default function BlockCard({ block, checks, onToggle, onLogWeight, onSkipBlock, isSkipped, sessionStarted }) {
  const cfg = blockColors[block.type] || blockColors.warmup
  const cd = useCountdown(block.duration * 60)
  const showTimer = block.duration > 0 && block.type !== 'warmup' && block.type !== 'quality' && sessionStarted

  return (
    <div className={`bg-white rounded-2xl mx-5 mb-4 overflow-hidden shadow-sm transition-opacity ${isSkipped ? 'opacity-40' : ''}`}>
      <div className="px-5 pt-4 pb-3 border-b border-gray-100">
        <div className="flex items-start justify-between gap-3 mb-1.5">
          <div className="flex-1 min-w-0">
            <span className={`inline-block text-[10px] font-bold tracking-wider px-2 py-0.5 rounded ${cfg.bg} ${cfg.text} mb-1.5`}>
              {cfg.label}
              {isSkipped && ' · SALTADO'}
            </span>
            <h3 className="font-display text-lg leading-tight">{block.title}</h3>
          </div>
          {block.duration > 0 && !showTimer && (
            <div className="flex-shrink-0 bg-bigg-bg rounded-lg px-3 py-1.5 text-center">
              <div className="font-display text-base leading-none">{block.duration}'</div>
            </div>
          )}
        </div>
        {block.format && (
          <p className="text-xs text-gray-500 italic mt-1">{block.format}</p>
        )}

        {/* Timer del bloque */}
        {showTimer && (
          <div className="mt-3 bg-bigg-dark text-white rounded-xl p-3 flex items-center gap-3">
            <div className="flex-shrink-0 w-10 h-10 rounded-full bg-bigg-lime flex items-center justify-center">
              <Clock className="w-5 h-5 text-bigg-dark" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[10px] font-bold text-white/60 uppercase tracking-wider">
                {cd.remaining === 0 ? 'Completado' : cd.running ? 'En curso' : 'Listo para empezar'}
              </div>
              <div className="font-display text-2xl leading-none">{formatTime(cd.remaining)}</div>
            </div>
            <div className="flex gap-1">
              {cd.remaining > 0 && (
                <button
                  onClick={cd.running ? cd.pause : cd.start}
                  className="w-9 h-9 rounded-lg bg-bigg-lime flex items-center justify-center active:scale-90"
                >
                  {cd.running ? (
                    <Pause className="w-4 h-4 text-bigg-dark" strokeWidth={2.5} />
                  ) : (
                    <Play className="w-4 h-4 text-bigg-dark" strokeWidth={2.5} />
                  )}
                </button>
              )}
              <button
                onClick={() => cd.reset()}
                className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center active:scale-90"
              >
                <RotateCcw className="w-4 h-4 text-white" strokeWidth={2.5} />
              </button>
            </div>
          </div>
        )}

        {/* Skip block */}
        {sessionStarted && block.type !== 'warmup' && !isSkipped && (
          <button
            onClick={onSkipBlock}
            className="mt-2 text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1"
          >
            <SkipForward className="w-3 h-3" /> Saltar este bloque
          </button>
        )}
      </div>

      {!isSkipped && (
        <div>
          {block.exercises.map(ex => (
            <ExerciseRow
              key={ex.id}
              exercise={ex}
              checked={!!checks[ex.id]}
              onToggle={() => onToggle(ex.id, ex)}
            />
          ))}
        </div>
      )}
    </div>
  )
}
