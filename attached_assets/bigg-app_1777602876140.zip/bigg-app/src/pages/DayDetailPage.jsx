import { useState, useMemo, useRef, useEffect } from 'react'
import { ArrowLeft, Clock, Target, Home, Activity, CheckCircle2, Play, Pause, Zap } from 'lucide-react'
import BlockCard from '../components/BlockCard'
import FinishWorkoutModal from '../components/FinishWorkoutModal'
import RestTimer, { parseRest } from '../components/RestTimer'
import WeightLogModal from '../components/WeightLogModal'
import { useElapsedTimer, formatTime } from '../components/timerHooks'
import { isWeightedExercise } from '../data/loads'

const typeConfig = {
  bigg: { tag: 'BIGG AT HOME', icon: Home, color: 'bg-bigg-lime' },
  run:  { tag: 'BIGG RUN',     icon: Activity, color: 'bg-orange-300' },
  rest: { tag: 'RECOVER',      icon: Home, color: 'bg-blue-200' },
}

// Equipamiento por bloque (se infiere desde detalles)
function getRequiredGear(day) {
  const text = JSON.stringify(day).toLowerCase()
  const gear = []
  if (/barbell|barra|squat|deadlift|bench press|hip thrust/.test(text)) gear.push('Barra olímpica + discos')
  if (/banco|bench/.test(text)) gear.push('Banco reclinable')
  if (/kb 20|kb 12|kb 8/.test(text)) gear.push('KBs (8/12/20)')
  if (/ddb |db /.test(text)) gear.push('Mancuernas')
  if (/box jump|cajón/.test(text)) gear.push('Cajón de salto')
  if (/trx/.test(text)) gear.push('TRX')
  if (/soga|jump rope/.test(text)) gear.push('Soga')
  if (/elást|banded/.test(text)) gear.push('Elásticos')
  if (/rueda abdominal/.test(text)) gear.push('Rueda abdominal')
  return gear
}

export default function DayDetailPage({ day, checks, onToggle, onBack, onFinish }) {
  const [showFinish, setShowFinish] = useState(false)
  const [restTarget, setRestTarget] = useState(null) // { seconds, exerciseName }
  const [weightLogTarget, setWeightLogTarget] = useState(null)
  const [skippedBlocks, setSkippedBlocks] = useState({})
  const [sessionStarted, setSessionStarted] = useState(false)
  const [paused, setPaused] = useState(false)

  const cfg = typeConfig[day.type] || typeConfig.bigg
  const sessionTimer = useElapsedTimer(sessionStarted && !paused)
  const containerRef = useRef(null)

  // Stats progreso (excluye warmup y bloques saltados)
  const realBlocks = day.blocks.filter((b, idx) =>
    b.type !== 'warmup' && !skippedBlocks[idx]
  )
  const totalExercises = realBlocks.reduce((acc, b) => acc + b.exercises.length, 0)
  const checkedCount = realBlocks.reduce(
    (acc, b) => acc + b.exercises.filter(e => checks[e.id]).length,
    0
  )
  const progress = totalExercises > 0 ? (checkedCount / totalExercises) * 100 : 0
  const canFinish = day.type !== 'rest' && checkedCount > 0

  const requiredGear = useMemo(() => getRequiredGear(day), [day])

  function handleToggleExercise(id, exercise) {
    const wasChecked = !!checks[id]
    onToggle(id)

    // Si se está MARCANDO (no desmarcando) durante una sesión activa
    if (!wasChecked && sessionStarted) {
      // 1) Si tiene peso, abrir modal de carga
      if (isWeightedExercise(exercise)) {
        setWeightLogTarget(exercise)
      }
      // 2) Si tiene descanso, abrir timer de descanso (después del weight log)
      else {
        const restSeconds = parseRest(exercise.rest)
        if (restSeconds > 0) {
          setRestTarget({ seconds: restSeconds, exerciseName: 'Próximo ejercicio' })
        }
      }

      // 3) Auto-scroll al siguiente ejercicio sin marcar
      setTimeout(() => {
        const nextEl = document.querySelector('[data-exercise-id]:not([data-checked="true"])')
        if (nextEl) nextEl.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }, 300)
    }
  }

  function handleWeightSaved() {
    // Después del weight log, si el ejercicio tiene rest, abrir el timer
    const ex = weightLogTarget
    setWeightLogTarget(null)
    if (ex) {
      const restSeconds = parseRest(ex.rest)
      if (restSeconds > 0) {
        setRestTarget({ seconds: restSeconds, exerciseName: 'Próximo ejercicio' })
      }
    }
  }

  function handleStartSession() {
    setSessionStarted(true)
    sessionTimer.reset()
  }

  function handleSaveSession(sessionData) {
    onFinish({
      ...sessionData,
      elapsedSeconds: sessionTimer.seconds,
    })
    setShowFinish(false)
    onBack()
  }

  function handleSkipBlock(idx) {
    setSkippedBlocks(prev => ({ ...prev, [idx]: true }))
  }

  return (
    <div ref={containerRef} className="min-h-screen bg-bigg-bg pb-32 max-w-[480px] mx-auto">
      {/* Hero */}
      <div className="relative h-72 overflow-hidden">
        <img src={day.image} alt={day.title} className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-black/85" />

        <div className="relative p-5 pt-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-white/90 backdrop-blur flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-bigg-dark" strokeWidth={2.5} />
          </button>
          <span className={`${cfg.color} text-bigg-dark text-xs font-bold px-3 py-1.5 rounded-full`}>
            {cfg.tag}
          </span>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-5">
          <p className="text-white/80 text-xs font-bold tracking-widest mb-1">{day.name.toUpperCase()}</p>
          <h1 className="font-display text-3xl text-white leading-tight mb-2">{day.title}</h1>
          <div className="flex items-center gap-3 text-white/90 text-sm">
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" /> {day.duration} min
            </span>
            <span className="flex items-center gap-1.5">
              <Target className="w-4 h-4" /> {day.subtitle}
            </span>
          </div>
        </div>
      </div>

      {/* Cronómetro / Iniciador sticky */}
      {day.type !== 'rest' && (
        <div className="bg-white px-5 py-3 sticky top-0 z-20 shadow-sm">
          {!sessionStarted ? (
            <button
              onClick={handleStartSession}
              className="w-full bg-bigg-lime text-bigg-dark font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
            >
              <Zap className="w-5 h-5" strokeWidth={2.5} fill="currentColor" />
              Empezar entrenamiento
            </button>
          ) : (
            <div className="space-y-2">
              {/* Cronómetro */}
              <div className="bg-bigg-dark text-white rounded-xl p-3 flex items-center gap-3">
                <button
                  onClick={() => setPaused(p => !p)}
                  className="w-11 h-11 rounded-full bg-bigg-lime flex items-center justify-center flex-shrink-0 active:scale-90"
                >
                  {paused ? (
                    <Play className="w-5 h-5 text-bigg-dark" strokeWidth={2.5} fill="currentColor" />
                  ) : (
                    <Pause className="w-5 h-5 text-bigg-dark" strokeWidth={2.5} />
                  )}
                </button>
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] font-bold text-white/60 uppercase tracking-wider">
                    {paused ? 'En pausa' : 'En curso'}
                  </div>
                  <div className="font-display text-2xl leading-none">
                    {formatTime(sessionTimer.seconds)}
                  </div>
                </div>
                <div className="text-right text-xs text-white/60">
                  <div>Progreso</div>
                  <div className="font-bold text-white text-base">{checkedCount}/{totalExercises}</div>
                </div>
              </div>

              {/* Barra de progreso */}
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-bigg-lime transition-all duration-300 rounded-full"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Resumen pre-entreno */}
      {!sessionStarted && day.type !== 'rest' && (
        <div className="mx-5 mt-4 bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Antes de empezar</span>
          </div>
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="text-[10px] font-bold text-gray-500 uppercase mb-0.5">Bloques</div>
              <div className="font-display text-xl">{day.blocks.length}</div>
            </div>
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="text-[10px] font-bold text-gray-500 uppercase mb-0.5">Tiempo total</div>
              <div className="font-display text-xl">{day.duration}'</div>
            </div>
          </div>
          {requiredGear.length > 0 && (
            <div>
              <div className="text-[10px] font-bold text-gray-500 uppercase mb-1.5">Necesitás</div>
              <div className="flex flex-wrap gap-1.5">
                {requiredGear.map(g => (
                  <span key={g} className="bg-gray-100 text-gray-700 text-xs px-2.5 py-1 rounded-lg font-medium">
                    {g}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Intro */}
      <div className="px-5 py-4">
        <p className="text-sm text-gray-600 leading-relaxed">{day.intro}</p>
      </div>

      {/* Bloques */}
      <div className="space-y-0 animate-slide-in">
        {day.blocks.map((block, idx) => (
          <BlockCard
            key={idx}
            block={block}
            checks={checks}
            onToggle={(id) => {
              const exercise = block.exercises.find(e => e.id === id)
              handleToggleExercise(id, exercise)
            }}
            onSkipBlock={() => handleSkipBlock(idx)}
            isSkipped={!!skippedBlocks[idx]}
            sessionStarted={sessionStarted}
          />
        ))}
      </div>

      {/* CTA Finalizar */}
      {canFinish && sessionStarted && (
        <div className="px-5 mt-4">
          <button
            onClick={() => setShowFinish(true)}
            className="w-full bg-bigg-dark text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform shadow-sm"
          >
            <CheckCircle2 className="w-5 h-5" strokeWidth={2.5} />
            Finalizar entrenamiento
          </button>
          <p className="text-xs text-gray-500 text-center mt-2">
            Te vamos a pedir tu FC promedio y calorías quemadas
          </p>
        </div>
      )}

      {/* Modales */}
      {showFinish && (
        <FinishWorkoutModal
          day={day}
          elapsedSeconds={sessionTimer.seconds}
          onClose={() => setShowFinish(false)}
          onSave={handleSaveSession}
        />
      )}

      {restTarget && (
        <RestTimer
          seconds={restTarget.seconds}
          exerciseName={restTarget.exerciseName}
          onClose={() => setRestTarget(null)}
        />
      )}

      {weightLogTarget && (
        <WeightLogModal
          exercise={weightLogTarget}
          onClose={() => setWeightLogTarget(null)}
          onSaved={handleWeightSaved}
        />
      )}
    </div>
  )
}
