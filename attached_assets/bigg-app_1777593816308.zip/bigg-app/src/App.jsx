import { useState, useEffect, useMemo } from 'react'
import HomePage from './pages/HomePage'
import DayDetailPage from './pages/DayDetailPage'
import ActivityPage from './pages/ActivityPage'
import BottomNav from './components/BottomNav'
import { week } from './data/routine'

const STORAGE_CHECKS = 'bigg_at_home_checks_v1'
const STORAGE_HISTORY = 'bigg_at_home_history_v1'

function App() {
  const [page, setPage] = useState('home')      // 'home' | 'day' | 'activity'
  const [activeDayId, setActiveDayId] = useState(null)
  const [checks, setChecks] = useState({})
  const [history, setHistory] = useState([])
  const [navTab, setNavTab] = useState('home')

  // Load
  useEffect(() => {
    try {
      const c = localStorage.getItem(STORAGE_CHECKS)
      if (c) setChecks(JSON.parse(c))
      const h = localStorage.getItem(STORAGE_HISTORY)
      if (h) setHistory(JSON.parse(h))
    } catch (e) {}
  }, [])

  // Save checks
  useEffect(() => {
    try { localStorage.setItem(STORAGE_CHECKS, JSON.stringify(checks)) } catch (e) {}
  }, [checks])

  // Save history
  useEffect(() => {
    try { localStorage.setItem(STORAGE_HISTORY, JSON.stringify(history)) } catch (e) {}
  }, [history])

  const today = useMemo(() => {
    const map = ['dom', 'lun', 'mar', 'mie', 'jue', 'vie', 'sab']
    return map[new Date().getDay()]
  }, [])

  // Días completados = aquellos que tienen al menos 1 entrada de historial en últimos 7 días
  const completedDays = useMemo(() => {
    const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000
    const recent = history.filter(h => new Date(h.date).getTime() >= sevenDaysAgo)
    return [...new Set(recent.map(h => h.dayId))]
  }, [history])

  function selectDay(id) {
    setActiveDayId(id)
    setPage('day')
    window.scrollTo(0, 0)
  }

  function toggleExercise(id) {
    setChecks(prev => ({ ...prev, [id]: !prev[id] }))
  }

  function backToHome() {
    setPage(navTab === 'actividad' ? 'activity' : 'home')
    setActiveDayId(null)
    window.scrollTo(0, 0)
  }

  function handleFinishWorkout(sessionData) {
    setHistory(prev => [...prev, sessionData])
    // Limpiar checks del día completado
    const dayBlocks = week.find(d => d.id === sessionData.dayId)?.blocks || []
    const idsToReset = dayBlocks.flatMap(b => b.exercises.map(e => e.id))
    setChecks(prev => {
      const next = { ...prev }
      idsToReset.forEach(id => delete next[id])
      return next
    })
  }

  function handleDeleteHistory(idx) {
    // idx viene del array ordenado por fecha desc, hay que mapearlo al original
    setHistory(prev => {
      const sorted = [...prev].sort((a, b) => new Date(b.date) - new Date(a.date))
      const target = sorted[idx]
      return prev.filter(h => h !== target)
    })
  }

  function handleNavChange(newTab) {
    setNavTab(newTab)
    setActiveDayId(null)
    setPage(newTab === 'actividad' ? 'activity' : 'home')
    window.scrollTo(0, 0)
  }

  const activeDay = week.find(d => d.id === activeDayId)

  return (
    <>
      {page === 'home' && (
        <HomePage
          onSelectDay={selectDay}
          completedDays={completedDays}
          currentDayId={today}
        />
      )}
      {page === 'activity' && (
        <ActivityPage
          history={history}
          onDelete={handleDeleteHistory}
        />
      )}
      {page === 'day' && activeDay && (
        <DayDetailPage
          day={activeDay}
          checks={checks}
          onToggle={toggleExercise}
          onBack={backToHome}
          onFinish={handleFinishWorkout}
        />
      )}
      {page !== 'day' && (
        <BottomNav active={navTab} onChange={handleNavChange} />
      )}
    </>
  )
}

export default App
