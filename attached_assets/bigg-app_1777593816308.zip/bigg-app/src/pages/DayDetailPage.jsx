import { useState } from 'react'
import { ArrowLeft, Clock, Target, Home, Activity, CheckCircle2 } from 'lucide-react'
import BlockCard from '../components/BlockCard'
import FinishWorkoutModal from '../components/FinishWorkoutModal'

const typeConfig = {
  bigg: { tag: 'BIGG AT HOME', icon: Home, color: 'bg-bigg-lime' },
  run:  { tag: 'BIGG RUN',     icon: Activity, color: 'bg-orange-300' },
  rest: { tag: 'RECOVER',      icon: Home, color: 'bg-blue-200' },
}

export default function DayDetailPage({ day, checks, onToggle, onBack, onFinish }) {
  const [showFinish, setShowFinish] = useState(false)
  const cfg = typeConfig[day.type] || typeConfig.bigg

  // Solo bloques principales (excluye warmup) para progreso
  const realBlocks = day.blocks.filter(b => b.type !== 'warmup')
  const totalExercises = realBlocks.reduce((acc, b) => acc + b.exercises.length, 0)
  const checkedCount = realBlocks.reduce(
    (acc, b) => acc + b.exercises.filter(e => checks[e.id]).length,
    0
  )
  const progress = totalExercises > 0 ? (checkedCount / totalExercises) * 100 : 0
  const canFinish = day.type !== 'rest' && checkedCount > 0

  function handleSaveSession(sessionData) {
    onFinish(sessionData)
    setShowFinish(false)
    onBack()
  }

  return (
    <div className="min-h-screen bg-bigg-bg pb-32 max-w-[480px] mx-auto">
      {/* Hero */}
      <div className="relative h-72 overflow-hidden">
        <img src={day.image} alt={day.title} className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-black/85" />

        <div className="relative p-5 pt-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-white/90 backdrop-blur flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-bigg-dark" strokeWidth={2.5} />
          </button>
          <span className={`${cfg.color} text-bigg-dark text-xs font-bold px-3 py-1.5 rounded-full`}>
            {cfg.tag}
          </span>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-5">
          <p className="text-white/80 text-xs font-bold tracking-widest mb-1">{day.name.toUpperCase()}</p>
          <h1 className="font-display text-3xl text-white leading-tight mb-2">{day.title}</h1>
          <div className="flex items-center gap-3 text-white/90 text-sm">
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" /> {day.duration} min
            </span>
            <span className="flex items-center gap-1.5">
              <Target className="w-4 h-4" /> {day.subtitle}
            </span>
          </div>
        </div>
      </div>

      {/* Progress bar */}
      {day.type !== 'rest' && (
        <div className="bg-white px-5 py-3 sticky top-0 z-20 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Progreso</span>
            <span className="text-sm font-bold">{checkedCount}/{totalExercises}</span>
          </div>
          <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-bigg-lime transition-all duration-300 rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}

      {/* Intro */}
      <div className="px-5 py-4">
        <p className="text-sm text-gray-600 leading-relaxed">{day.intro}</p>
      </div>

      {/* Blocks */}
      <div className="space-y-0 animate-slide-in">
        {day.blocks.map((block, idx) => (
          <BlockCard
            key={idx}
            block={block}
            checks={checks}
            onToggle={onToggle}
          />
        ))}
      </div>

      {/* CTA Finalizar */}
      {canFinish && (
        <div className="px-5 mt-4">
          <button
            onClick={() => setShowFinish(true)}
            className="w-full bg-bigg-lime text-bigg-dark font-bold py-4 rounded-2xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform shadow-sm"
          >
            <CheckCircle2 className="w-5 h-5" strokeWidth={2.5} />
            Finalizar entrenamiento
          </button>
          <p className="text-xs text-gray-500 text-center mt-2">
            Te vamos a pedir tu FC promedio y calorías quemadas
          </p>
        </div>
      )}

      {/* Total */}
      <div className="bg-bigg-dark text-white rounded-2xl mx-5 mt-3 p-5 flex items-center justify-between">
        <div>
          <p className="text-xs text-white/60 uppercase tracking-wider mb-1">Tiempo total estimado</p>
          <p className="font-display text-2xl">{day.duration} minutos</p>
        </div>
        <div className="w-12 h-12 rounded-full bg-bigg-lime flex items-center justify-center">
          <Clock className="w-6 h-6 text-bigg-dark" strokeWidth={2.5} />
        </div>
      </div>

      {/* Modal */}
      {showFinish && (
        <FinishWorkoutModal
          day={day}
          onClose={() => setShowFinish(false)}
          onSave={handleSaveSession}
        />
      )}
    </div>
  )
}
