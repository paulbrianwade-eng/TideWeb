import { Heart, Flame, Clock, TrendingUp, Trash2 } from 'lucide-react'
import TopBar from '../components/TopBar'

const feelMap = {
  easy:     { emoji: '😎', text: 'Fácil',    color: 'bg-green-100 text-green-700' },
  moderate: { emoji: '😅', text: 'Moderado', color: 'bg-yellow-100 text-yellow-700' },
  hard:     { emoji: '🥵', text: 'Duro',     color: 'bg-orange-100 text-orange-700' },
  brutal:   { emoji: '💀', text: 'Brutal',   color: 'bg-red-100 text-red-700' },
}

const typeBadge = {
  bigg: { label: 'BIGG', color: 'bg-bigg-dark text-bigg-lime' },
  run:  { label: 'RUN',  color: 'bg-orange-500 text-white' },
  rest: { label: 'REC',  color: 'bg-blue-200 text-blue-800' },
}

function formatDate(iso) {
  const d = new Date(iso)
  const today = new Date()
  const yesterday = new Date(); yesterday.setDate(today.getDate() - 1)
  const isSameDay = (a, b) => a.toDateString() === b.toDateString()

  if (isSameDay(d, today)) return `Hoy · ${d.toLocaleTimeString('es', {hour:'2-digit', minute:'2-digit'})}`
  if (isSameDay(d, yesterday)) return `Ayer · ${d.toLocaleTimeString('es', {hour:'2-digit', minute:'2-digit'})}`
  return d.toLocaleDateString('es', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
}

export default function ActivityPage({ history, onDelete }) {
  // Agrupar por semana (últimos 7 días vs todo)
  const sortedHistory = [...history].sort((a, b) => new Date(b.date) - new Date(a.date))

  const last7Days = sortedHistory.filter(h => {
    const diff = (Date.now() - new Date(h.date)) / (1000 * 60 * 60 * 24)
    return diff <= 7
  })

  const stats = {
    total: history.length,
    week: last7Days.length,
    totalMinutes: history.reduce((acc, h) => acc + (h.duration || 0), 0),
    totalCalories: history.reduce((acc, h) => acc + (h.calories || 0), 0),
    avgHR: (() => {
      const withHR = history.filter(h => h.avgHR)
      if (!withHR.length) return null
      return Math.round(withHR.reduce((acc, h) => acc + h.avgHR, 0) / withHR.length)
    })(),
  }

  return (
    <div className="min-h-screen bg-bigg-bg pb-32 max-w-[480px] mx-auto">
      <TopBar />

      <div className="px-5 pt-2 pb-4">
        <h1 className="font-display text-3xl">Actividad</h1>
        <p className="text-sm text-gray-500 mt-0.5">Tu historial de entrenamientos</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3 px-5 mb-5">
        <StatCard
          icon={<TrendingUp className="w-5 h-5 text-bigg-dark" />}
          label="Esta semana"
          value={stats.week}
          unit="entrenos"
        />
        <StatCard
          icon={<Clock className="w-5 h-5 text-bigg-dark" />}
          label="Tiempo total"
          value={stats.totalMinutes}
          unit="min"
        />
        <StatCard
          icon={<Flame className="w-5 h-5 text-orange-500" />}
          label="Calorías"
          value={stats.totalCalories}
          unit="kcal"
        />
        <StatCard
          icon={<Heart className="w-5 h-5 text-red-500" />}
          label="FC promedio"
          value={stats.avgHR || '—'}
          unit={stats.avgHR ? 'ppm' : ''}
        />
      </div>

      {/* Historial */}
      {sortedHistory.length === 0 ? (
        <div className="mx-5 bg-white rounded-2xl p-8 text-center shadow-sm">
          <div className="text-5xl mb-3">📊</div>
          <h3 className="font-bold text-lg mb-1">Sin entrenamientos aún</h3>
          <p className="text-sm text-gray-500">
            Completá un día de entrenamiento y aparecerá acá tu historial.
          </p>
        </div>
      ) : (
        <div className="px-5">
          <h3 className="font-bold text-sm text-gray-500 uppercase tracking-wider mb-3">Historial</h3>
          <div className="space-y-3">
            {sortedHistory.map((entry, idx) => (
              <ActivityCard
                key={idx}
                entry={entry}
                onDelete={() => onDelete(idx)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function StatCard({ icon, label, value, unit }) {
  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm">
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">{label}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="font-display text-2xl">{value}</span>
        {unit && <span className="text-xs text-gray-500 font-medium">{unit}</span>}
      </div>
    </div>
  )
}

function ActivityCard({ entry, onDelete }) {
  const tBadge = typeBadge[entry.type] || typeBadge.bigg
  const f = entry.feel ? feelMap[entry.feel] : null

  function handleDelete(e) {
    e.stopPropagation()
    if (confirm('¿Eliminar este entrenamiento del historial?')) {
      onDelete()
    }
  }

  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5">
            <span className={`text-[10px] font-bold tracking-wider px-2 py-0.5 rounded ${tBadge.color}`}>
              {tBadge.label}
            </span>
            <span className="text-xs text-gray-500">{formatDate(entry.date)}</span>
          </div>
          <h4 className="font-bold text-base leading-tight">{entry.dayTitle}</h4>
          <p className="text-xs text-gray-500 mt-0.5">{entry.dayName}</p>
        </div>
        <button
          onClick={handleDelete}
          className="text-gray-300 hover:text-red-500 active:scale-90 transition-all p-1"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div className="flex flex-wrap gap-2 text-xs">
        <Metric icon={<Clock className="w-3.5 h-3.5" />} value={`${entry.duration} min`} />
        {entry.avgHR && (
          <Metric icon={<Heart className="w-3.5 h-3.5 text-red-500" />} value={`${entry.avgHR} ppm`} />
        )}
        {entry.calories && (
          <Metric icon={<Flame className="w-3.5 h-3.5 text-orange-500" />} value={`${entry.calories} kcal`} />
        )}
        {f && (
          <span className={`px-2.5 py-1 rounded-lg ${f.color} font-bold flex items-center gap-1`}>
            <span>{f.emoji}</span>
            <span>{f.text}</span>
          </span>
        )}
      </div>

      {entry.notes && (
        <p className="text-xs text-gray-600 mt-3 pt-3 border-t border-gray-100 italic leading-relaxed">
          "{entry.notes}"
        </p>
      )}
    </div>
  )
}

function Metric({ icon, value }) {
  return (
    <span className="bg-gray-100 px-2.5 py-1 rounded-lg flex items-center gap-1 font-medium text-gray-700">
      {icon}
      {value}
    </span>
  )
}
