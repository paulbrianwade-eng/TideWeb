import TopBar from '../components/TopBar'
import SectionTabs from '../components/SectionTabs'
import DayCard from '../components/DayCard'
import StreakCard from '../components/StreakCard'
import { week } from '../data/routine'
import { useMemo } from 'react'

export default function HomePage({ onSelectDay, completedDays, currentDayId }) {
  // Reordena para mostrar el día de hoy primero
  const orderedWeek = useMemo(() => {
    const idx = week.findIndex(d => d.id === currentDayId)
    if (idx <= 0) return week
    return [...week.slice(idx), ...week.slice(0, idx)]
  }, [currentDayId])

  const todayDay = week.find(d => d.id === currentDayId)

  return (
    <div className="min-h-screen bg-bigg-bg pb-32 max-w-[480px] mx-auto">
      <div className="dot-pattern">
        <TopBar />
        <SectionTabs />

        <div className="px-5 pt-5 pb-3">
          <h2 className="font-display text-2xl">Entrenamientos de BIGG</h2>
          <p className="text-sm text-gray-500 mt-0.5">Tu semana adaptada para casa</p>
        </div>

        {/* Slider de días */}
        <div className="snap-cards no-scrollbar overflow-x-auto flex gap-3 px-5 pb-5">
          {orderedWeek.map(day => (
            <div key={day.id} className="flex-shrink-0 w-[78%]">
              <DayCard
                day={day}
                onClick={() => onSelectDay(day.id)}
                isCompleted={completedDays.includes(day.id)}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Strike */}
      <div className="mt-2">
        <StreakCard
          completedDays={completedDays}
          onDayClick={onSelectDay}
        />
      </div>

      {/* Tu día de hoy - acceso rápido */}
      {todayDay && (
        <div className="mx-5 mt-4 bg-white rounded-2xl p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-bigg-lime"></div>
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Hoy</span>
          </div>
          <h3 className="font-display text-xl mb-1">{todayDay.title}</h3>
          <p className="text-sm text-gray-500 mb-3">{todayDay.subtitle} · {todayDay.duration} min</p>
          <button
            onClick={() => onSelectDay(todayDay.id)}
            className="w-full bg-bigg-lime text-bigg-dark font-bold py-3 rounded-xl active:scale-[0.98] transition-transform"
          >
            {completedDays.includes(todayDay.id) ? 'Ver entrenamiento' : 'Empezar'}
          </button>
        </div>
      )}
    </div>
  )
}
