import { Footprints } from 'lucide-react'

export default function SectionTabs() {
  return (
    <div className="flex border-b border-gray-200 bg-bigg-bg">
      <div className="flex-1 flex flex-col items-center py-3 relative tab-active">
        <Footprints className="w-7 h-7 mb-1 text-bigg-dark" strokeWidth={1.5} />
        <span className="text-sm font-medium text-bigg-dark">Train</span>
      </div>
    </div>
  )
}
