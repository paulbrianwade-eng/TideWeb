import BiggLogo from './BiggLogo'

export default function TopBar({ rightContent }) {
  return (
    <div className="px-5 pt-4 pb-3 flex items-center justify-between bg-bigg-bg sticky top-0 z-30">
      <BiggLogo />
      {rightContent}
    </div>
  )
}
