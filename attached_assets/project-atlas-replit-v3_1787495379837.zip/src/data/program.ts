import type { ExercisePrescription, SportActivity, SportModule, Workout, WorkoutBlock } from '../types';
import { addDays, todayISO } from '../lib/date';
import { isDeload, phaseFor } from './phases';
import { block } from './blocks';

export const TOTAL_WEEKS = 16;
export const PROGRAM_START = todayISO();

export const ACTIVITY_LABEL: Record<SportActivity, string> = {
  surf: 'Surf', golf: 'Golf', ski: 'Esquí', running: 'Running', rest: 'Descanso', gym: 'Gimnasio', home: 'Entrenamiento en casa',
};

const p = (exerciseId: string, extra: Partial<ExercisePrescription> = {}): ExercisePrescription => ({ exerciseId, ...extra });
const B = (id:string, kind:WorkoutBlock['kind'], title:string, duration:string, items:ExercisePrescription[], focus:string, extra:Partial<WorkoutBlock>={}) =>
  block(id, kind, title, duration, items, { focus, ...extra });

const vol = (week:number, normal:number, deload:number) => isDeload(week) ? deload : normal;
const rounds = (week:number, normal=3) => `${vol(week,normal,2)} vueltas`;

const transition = (id:string, n:number, intensity='Sostenido · RPE 6–7') => B(
  `${id}-run-${n}`,'transition','VUELTA A LA MANZANA','2–4 min',
  [p('block-run',{sets:1,reps:'1 vuelta',rpe:intensity,instructions:'Usala como transición. No es un sprint; volvé listo para el siguiente bloque.'})],
  'Cardio transition · mantener pulsaciones sin quemar el siguiente bloque'
);

const coreLower = (id:string,w:number) => B(`${id}-core`,'core','01 · ZONA MEDIA','6–7 min',[
  p('ab-wheel',{reps:'8'}), p('copenhagen-plank',{duration:'20 s/lado',unilateral:true}),
  p('dead-bug',{reps:'8/lado',unilateral:true}), p('pallof-press',{reps:'10/lado',unilateral:true})
],'Antiextensión + plano frontal + antirrotación',{rounds:rounds(w)});

const coreUpper = (id:string,w:number) => B(`${id}-core`,'core','01 · ZONA MEDIA','6–7 min',[
  p('trx-body-saw',{reps:'8–10'}), p('side-plank-rotation',{reps:'6/lado',unilateral:true}),
  p('pallof-press',{reps:'8/lado',unilateral:true}), p('bear-crawl',{distance:'10 m'})
],'Core + escápula + rotación controlada',{rounds:rounds(w)});

const coreRotate = (id:string,w:number) => B(`${id}-core`,'core','01 · ZONA MEDIA','6–7 min',[
  p('pallof-press',{reps:'10/lado',unilateral:true}), p('side-plank-rotation',{reps:'6/lado',unilateral:true}),
  p('hip-airplane',{reps:'5/lado',unilateral:true}), p('dead-bug',{reps:'8/lado',unilateral:true})
],'Antirrotación + cadera + control del plano transversal',{rounds:rounds(w)});

const lowerStrength = (id:string,w:number) => {
  const phase=phaseFor(w);
  const sets=vol(w, phase.strength.sets, 3);
  return B(`${id}-strength`,'strength','02 · FUERZA','14–16 min',[
    p('back-squat',{order:'A',sets,reps:phase.id===1?'6–8':phase.id===3?'4–5':'5–6',rpe:isDeload(w)?'6':'7–8',rest:phase.strength.rest,instructions:'Completar todas las series A antes de pasar a B.'}),
    p('single-leg-rdl',{order:'B1',sets:3,reps:'8/lado',unilateral:true,load:'KB 20 kg'}),
    p('soleus-raise',{order:'B2',sets:3,reps:'15–20'})
  ],'1 principal + 2 accesorios · B1/B2 alternados');
};

const upperStrength = (id:string,w:number) => B(`${id}-strength`,'strength','02 · FUERZA','14–16 min',[
  p('bench-press',{order:'A',sets:vol(w,4,3),reps:w<=4?'6–8':'5–6',rpe:isDeload(w)?'6':'7–8',rest:'90–120 s',instructions:'Completar A. No repetir empuje pesado en los bloques siguientes.'}),
  p('pull-up',{order:'B1',sets:3,reps:'6–8',rpe:'7–8'}),
  p('bottom-up-carry',{order:'B2',sets:3,distance:'20 m/lado',unilateral:true,carry:true})
],'Empuje principal + tirón + estabilidad de hombro');

const rotateStrength = (id:string,w:number) => B(`${id}-strength`,'strength','02 · FUERZA','14–16 min',[
  p('romanian-deadlift',{order:'A',sets:vol(w,4,3),reps:w<=4?'8':'6',rpe:isDeload(w)?'6':'7–8',rest:'90–120 s',instructions:'Una sola configuración de barra.'}),
  p('trx-row',{order:'B1',sets:3,reps:'10–12'}),
  p('bulgarian-split-squat',{order:'B2',sets:3,reps:'8/lado',unilateral:true,load:'KB 20 kg'})
],'Bisagra fuerte + tirón + unilateral');

const athleteLower = (id:string,w:number) => B(`${id}-athlete`,'athletic','03 · ATLETA','9–10 min',[
  p('box-jump',{order:'A1',reps:'5'}), p('kb-swing',{order:'A2',reps:'12–15',load:'KB 20 kg'}),
  p('mb-slam',{order:'A3',reps:'8–10',load:'MB 10 kg'}), p('threshold-run',{order:'A4',duration:'20–30 s rápido',instructions:'Aceleración fuerte, no sprint máximo si la técnica cae.'})
],'Explosivo y dinámico: salto + bisagra balística + slam + carrera',{rounds:rounds(w),rest:'45–60 s entre vueltas'});

const athleteSurf = (id:string,w:number) => B(`${id}-athlete`,'athletic','03 · ATLETA','9–10 min',[
  p('rotational-mb-throw',{order:'A1',reps:'5/lado',unilateral:true,load:'MB 5 kg'}),
  p('broad-jump',{order:'A2',reps:'4'}), p('mb-slam',{order:'A3',reps:'8',load:'MB 10 kg'}),
  p('threshold-run',{order:'A4',duration:'20–30 s rápido'})
],'Potencia global sin volver a repetir push-up/bench/remo',{rounds:rounds(w),rest:'45–60 s entre vueltas'});

const athleteRun = (id:string,w:number) => B(`${id}-athlete`,'athletic','03 · ATLETA','9–10 min',[
  p('pogo-jump',{order:'A1',reps:'20 contactos'}), p('shuttle-run',{order:'A2',reps:'10-20-10 m'}),
  p('kb-clean-push-press',{order:'A3',reps:'5/lado',unilateral:true,load:'KB 12–20 kg'}),
  p('jump-rope',{order:'A4',reps:'40–60'})
],'Elasticidad + aceleración/freno + levantamiento dinámico',{rounds:rounds(w),rest:'45 s entre vueltas'});

const athleteGolf = (id:string,w:number) => B(`${id}-athlete`,'athletic','03 · ATLETA','9–10 min',[
  p('kb-clean-push-press',{order:'A1',reps:'5/lado',unilateral:true,load:'KB 12–20 kg'}),
  p('lateral-bound',{order:'A2',reps:'5/lado',unilateral:true}), p('rotational-mb-throw',{order:'A3',reps:'5/lado',unilateral:true}),
  p('shuttle-run',{order:'A4',reps:'10-10-10 m'})
],'Levantamiento dinámico + lateralidad + rotación + aceleración',{rounds:rounds(w),rest:'45–60 s entre vueltas'});

const athleteHybrid = (id:string,w:number) => B(`${id}-athlete`,'athletic','03 · ATLETA','9–10 min',[
  p('broad-jump',{order:'A1',reps:'4'}), p('kb-clean-push-press',{order:'A2',reps:'5/lado',unilateral:true}),
  p('rotational-mb-throw',{order:'A3',reps:'5/lado',unilateral:true}), p('shuttle-run',{order:'A4',reps:'10-20-10 m'})
],'Potencia full-body + rotación + desplazamiento',{rounds:rounds(w),rest:'45–60 s entre vueltas'});

const finisher = (id:string,w:number,variant:number) => {
  const mins=isDeload(w)?'7 min':'8 min';
  const menus: ExercisePrescription[][]=[
    [p('spinning-bike',{duration:'40 s fuerte'}),p('kb-swing',{reps:'12',load:'KB 20 kg'}),p('burpee',{reps:'8'}),p('mb-slam',{reps:'10'}),p('jump-rope',{reps:'40'})],
    [p('threshold-run',{distance:'150–200 m'}),p('reverse-lunge',{reps:'10 total',load:'KB 20 kg'}),p('trx-row',{reps:'10'}),p('mb-slam',{reps:'10'}),p('jump-rope',{reps:'50'})],
    [p('spinning-bike',{duration:'30 s fuerte'}),p('burpee',{reps:'6'}),p('kb-swing',{reps:'12'}),p('mountain-climber',{duration:'30 s'}),p('mb-slam',{reps:'8'})],
    [p('shuttle-run',{reps:'10-20-10 m'}),p('kb-swing',{reps:'15'}),p('reverse-lunge',{reps:'8/lado',unilateral:true}),p('burpee',{reps:'8'}),p('jump-rope',{reps:'50'})],
  ];
  const mode = variant%2===0 ? `AMRAP ${mins}` : `FOR TIME · ${isDeload(w)?'3':'4'} vueltas`;
  return B(`${id}-finisher`,'finisher','04 · FINISHER',mins,menus[variant%menus.length],
    'Cardio mezclado: nunca solo bici, nunca solo correr',{rounds:mode,rest:'Solo lo necesario · RPE 8–9'});
};

interface DayPlan { name:string; subtitle:string; objective:string; duration:string; rpe:string; next:SportActivity|null; modules:SportModule[]; external?:SportActivity; build:(id:string,week:number)=>WorkoutBlock[]; note:(week:number)=>string; }

const DAYS:DayPlan[]=[
  {name:'POWER LEGS',subtitle:'Lower strength · Explosive athlete',objective:'Preservar/ganar fuerza de piernas mientras bajás grasa y mejorás potencia.',duration:'46–50 min',rpe:'8',next:'gym',modules:[],build:(id,w)=>[
    coreLower(id,w),lowerStrength(id,w),transition(id,1),athleteLower(id,w),transition(id,2,'Sostenido/fuerte controlado · RPE 7'),finisher(id,w,0)
  ],note:()=> 'Zona media prepara. Fuerza construye. Las vueltas mantienen el motor arriba. Atleta es rápido y dinámico. Finisher mezcla estaciones y se puntúa.'},

  {name:'PADDLE POWER',subtitle:'Upper strength · Surf preparation',objective:'Mantener músculo y fuerza de tren superior, mejorar hombro/escápula y potencia útil para surf.',duration:'46–50 min',rpe:'8',next:'running',modules:['surf'],build:(id,w)=>[
    coreUpper(id,w),upperStrength(id,w),transition(id,1),athleteSurf(id,w),transition(id,2),finisher(id,w,1)
  ],note:()=> 'No repetir el mismo patrón por toda la sesión: bench es el empuje principal; después buscamos potencia global y motor.'},

  {name:'MOVE FAST',subtitle:'Engine · Mobility · Athletic conditioning',objective:'Mejorar motor, elasticidad y capacidad de trabajo sin otro día pesado de barra.',duration:'44–50 min',rpe:'7–8',next:'gym',modules:['running'],build:(id,w)=>[
    coreLower(id,w),
    B(`${id}-strength`,'strength','02 · FUERZA / DURABILITY','12–14 min',[p('single-leg-rdl',{order:'A',sets:3,reps:'8/lado',unilateral:true,load:'KB 20 kg'}),p('soleus-raise',{order:'B1',sets:3,reps:'15–20'}),p('tibialis-raise',{order:'B2',sets:3,reps:'15–20'})],'Fuerza ligera que suma sin interferir'),
    transition(id,1,'Suave/sostenido · RPE 5–6'),athleteRun(id,w),finisher(id,w,2)
  ],note:()=> 'Día atlético sin carga axial alta. El finisher sigue siendo mixto, pero no necesitás destruirte para bajar grasa.'},

  {name:'ROTATE & DRIVE',subtitle:'Full body · Golf power',objective:'Fuerza global, rotación rápida, estabilidad y frenado para llegar potente y suelto al golf.',duration:'46–50 min',rpe:'8',next:'gym',modules:['golf'],build:(id,w)=>[
    coreRotate(id,w),rotateStrength(id,w),transition(id,1),athleteGolf(id,w),transition(id,2),finisher(id,w,3)
  ],note:()=> 'Golf no es solo rotar: producir fuerza desde el piso y frenarla con control. El circuito Atleta tiene que sentirse vivo.'},

  {name:'FULL SEND',subtitle:'Hybrid · Olympic power · Work capacity',objective:'Cerrar la semana con potencia, levantamientos dinámicos y un bloque metabólico completo.',duration:'47–50 min',rpe:'8–9',next:'rest',modules:['surf','golf'],build:(id,w)=>[
    coreUpper(id,w),
    B(`${id}-strength`,'strength','02 · FUERZA / POWER','14–16 min',[p('hang-clean',{order:'A',sets:vol(w,6,4),reps:'3',rpe:'6–7',rest:'75–90 s',instructions:'Técnica y velocidad antes que carga.'}),p('pull-up',{order:'B1',sets:3,reps:'6–8'}),p('reverse-lunge',{order:'B2',sets:3,reps:'8/lado',unilateral:true,load:'KB 20 kg'})],'Olímpico como principal · accesorios sin tocar la barra'),
    transition(id,1),athleteHybrid(id,w),transition(id,2,'Fuerte controlado · RPE 7–8'),finisher(id,w,(w+1)%4)
  ],note:()=> 'El clean se hace fresco. El bloque Atleta es dinámico. El finisher es el lugar para competir, no para practicar técnica olímpica.'},

  {name:'ZONE 2 + MOBILITY',subtitle:'Spinning / easy run · Recovery',objective:'Aumentar gasto y base aeróbica con poco costo de recuperación.',duration:'40–55 min',rpe:'4–5',next:'rest',modules:['running'],external:'running',build:(id)=>[
    B(`${id}-z2`,'movement','ZONE 2','35–45 min',[p('spinning-bike',{duration:'35–45 min',rpe:'4–5',instructions:'Ritmo conversacional. También puede ser trote suave o caminata rápida.'})],'Base aeróbica y recuperación'),
    B(`${id}-mobility`,'recovery','MOBILITY','8–10 min',[p('hip-9090',{reps:'8 cambios'}),p('open-book',{reps:'8/lado',unilateral:true}),p('hip-flexor-stretch',{duration:'45 s/lado',unilateral:true})],'Cadera + tórax')
  ],note:()=> 'Opcional. Si necesitás recuperar, hacé solo movilidad y caminata.'},

  {name:'REST',subtitle:'Recovery',objective:'Recuperar para volver a entrenar fuerte.',duration:'Descanso',rpe:'1–2',next:'gym',modules:[],external:'rest',build:(id)=>[
    B(`${id}-restore`,'recovery','RESTORE','10–20 min',[p('nasal-breathing',{duration:'3 min'}),p('hip-flow',{duration:'5 min'}),p('easy-walk',{duration:'10–20 min'})],'Recuperación opcional')
  ],note:()=> 'Descansar también protege músculo, rendimiento y adherencia al déficit.'}
];

export const WEEK_STRUCTURE=DAYS.map(d=>({name:d.name,subtitle:d.subtitle}));
const buildWorkout=(week:number,dayIndex:number,date:string):Workout=>{const plan=DAYS[dayIndex];const id=`w${week}d${dayIndex+1}`;const blocks=plan.build(id,week);return{id,week,day:dayIndex+1,date,name:plan.name,subtitle:plan.subtitle,objective:plan.objective,duration:plan.duration,plannedRpe:isDeload(week)?'6–7':plan.rpe,coachNote:plan.note(week),nextDayActivity:plan.next,blocks,adaptations:[],status:plan.external?'external':'pending',externalActivity:plan.external,phase:phaseFor(week).id,modules:plan.modules};};
export const buildProgram=(start:string=PROGRAM_START):Workout[]=>{const out:Workout[]=[];for(let w=1;w<=TOTAL_WEEKS;w++)for(let d=0;d<DAYS.length;d++)out.push(buildWorkout(w,d,addDays(start,(w-1)*7+d)));return out;};
export { phaseFor, weekInPhase, isDeload, PHASES } from './phases';
