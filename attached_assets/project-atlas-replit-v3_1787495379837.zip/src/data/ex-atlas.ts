import type { Exercise } from '../types';
import { x } from './ex-helpers';

export const ATLAS_EXERCISES: Exercise[] = [
  x('ab-wheel', 'Ab Wheel', {
    cat: ['Core'], obj: 'Antiextensión fuerte del tronco para transferir fuerza sin perder la pelvis.',
    cap: ['Antirrotación'], tgt: ['Recto abdominal', 'Oblicuos', 'Dorsal'], typ: '3 × 6–10',
    cues: ['Costillas abajo.', 'Glúteos activos.', 'Volvé antes de perder la pelvis.'],
    err: ['Arquear la lumbar', 'Buscar rango sin control'], reg: 'TRX fallout o dead bug.', pro: 'Más rango o pausa extendida.', eq: ['Ab Wheel']
  }),
  x('trx-body-saw', 'TRX Body Saw', {
    cat: ['Core', 'Surf'], obj: 'Antiextensión dinámica y control escapular.', cap: ['Antirrotación', 'Estabilidad escapular'],
    tgt: ['Core', 'Serrato'], mod: ['surf'], typ: '3 × 8–12', cues: ['Cuerpo en bloque.', 'Movimiento desde hombros.', 'No hundir lumbar.'],
    err: ['Cadera cae', 'Rango excesivo'], reg: 'Plancha.', pro: 'Mayor inclinación.', eq: ['TRX']
  }),
  x('side-plank-rotation', 'Side Plank Rotation', {
    cat: ['Core', 'Rotación', 'Golf', 'Surf'], obj: 'Rotar el tórax manteniendo pelvis estable.', cap: ['Rotación', 'Antirrotación'],
    tgt: ['Oblicuos', 'Tórax'], mod: ['golf','surf'], typ: '3 × 6–8/lado', cues: ['Pelvis alta.', 'Rotá desde tórax.', 'Control en ambos sentidos.'],
    err: ['Caer de cadera', 'Mover solo el brazo'], reg: 'Side plank.', pro: 'Con banda.', eq: ['Peso corporal']
  }),
  x('kb-swing', 'Kettlebell Swing', {
    cat: ['Potencia'], obj: 'Bisagra balística para producir potencia repetida sin una segunda barra.', cap: ['Potencia', 'Resistencia local'],
    tgt: ['Glúteos','Isquiotibiales','Core'], typ: '10–15 reps', cues: ['Bisagra, no sentadilla.', 'Cadera impulsa.', 'Brazos acompañan.'],
    err: ['Levantar con hombros', 'Hiperextender arriba'], reg: 'KB deadlift.', pro: 'Más cadencia con técnica.', eq: ['Kettlebell']
  }),
  x('kb-clean-push-press', 'KB Clean + Push Press', {
    cat: ['Potencia', 'Unilateral'], obj: 'Levantar y transferir fuerza de suelo a mano en un gesto dinámico full-body.', cap: ['Potencia', 'Unilateral'],
    tgt: ['Cadera','Hombro','Core'], typ: '5–6/lado', cues: ['Clean pegado.', 'Dip corto.', 'Bloqueá sin arquear lumbar.'],
    err: ['Golpear el antebrazo', 'Press estricto bajo fatiga'], reg: 'KB clean solo.', pro: 'Complejo continuo.', eq: ['Kettlebell']
  }),
  x('burpee', 'Burpee', {
    cat: ['Cardio'], obj: 'Subir pulsaciones con un patrón global simple.', cap: ['Resistencia local'], tgt: ['Full body'], typ: '6–10 reps',
    cues: ['Ritmo sostenible.', 'Apoyo firme de manos.', 'Respirá cada repetición.'], err: ['Colapsar lumbar', 'Sprintar la primera ronda'],
    reg: 'Step-back burpee.', pro: 'Burpee over line.', eq: ['Peso corporal']
  }),
  x('jump-rope', 'Jump Rope', {
    cat: ['Cardio', 'Running'], obj: 'Cardio elástico con bajo espacio y buena demanda de pie/tobillo.', cap: ['Pie y tobillo', 'Capacidad aeróbica'],
    tgt: ['Pantorrilla','Pie'], mod: ['running'], typ: '40–60 saltos', cues: ['Saltos bajos.', 'Muñecas rápidas.', 'Ritmo parejo.'],
    err: ['Saltar alto', 'Girar con hombros'], reg: 'Saltos sin soga.', pro: 'Double unders.', eq: ['Soga']
  }),
  x('spinning-bike', 'Spinning Bike', {
    cat: ['Cardio'], obj: 'Sumar trabajo cardiovascular sin impacto y funcionar como estación dentro de circuitos.', cap: ['Capacidad aeróbica', 'Umbral'],
    tgt: ['Cuádriceps','Glúteos','Sistema cardiovascular'], typ: '30–60 s fuerte o 30–50 min Zona 2',
    cues: ['Cadencia controlada.', 'Resistencia que permita pedalear fluido.', 'No rebotar en el asiento.'],
    err: ['Resistencia absurda', 'Cadencia caótica'], reg: 'Menos resistencia.', pro: 'Más watts/cadencia a mismo RPE.', eq: ['Bicicleta de spinning']
  }),
  x('block-run', 'Vuelta a la manzana', {
    cat: ['Cardio', 'Running'], obj: 'Transición cardiovascular que mantiene pulsaciones entre bloques sin reemplazar el trabajo atlético.',
    cap: ['Capacidad aeróbica'], tgt: ['Sistema cardiovascular'], mod: ['running'], typ: '1 vuelta · ritmo sostenido',
    cues: ['RPE 6–7.', 'No sprint.', 'Volvé listo para el siguiente bloque.'], err: ['Correr a fondo', 'Convertirla en otra serie de piernas'],
    reg: 'Trote/caminata.', pro: 'Ritmo sostenido más rápido.', eq: ['Espacio exterior']
  }),
  x('shuttle-run', 'Shuttle Run', {
    cat: ['Cardio', 'Running'], obj: 'Acelerar, frenar y volver a acelerar con control.', cap: ['Cambio de dirección','Desaceleración','Velocidad'],
    tgt: ['Piernas','Core'], mod: ['running'], typ: '10-20-10 m', cues: ['Bajá centro de masa antes de frenar.', 'Apoyo debajo del cuerpo.', 'Acelerá progresivo.'],
    err: ['Frenar erguido', 'Girar sobre rodilla bloqueada'], reg: 'Distancias cortas.', pro: 'Más velocidad.', eq: ['Espacio exterior']
  }),
  x('mountain-climber', 'Mountain Climber', {
    cat: ['Cardio','Core'], obj: 'Cardio simple manteniendo tronco estable.', cap: ['Resistencia local'], tgt: ['Core','Flexores de cadera'], typ: '30–40 s',
    cues: ['Hombros sobre manos.', 'Cadera estable.', 'Rodillas rápidas sin rebotar.'], err: ['Cadera muy alta', 'Lumbar colapsada'],
    reg: 'Marcha en plancha.', pro: 'Mayor cadencia.', eq: ['Peso corporal']
  }),
];
