import ExerciseRow from './ExerciseRow'

const blockColors = {
  warmup: { bg: 'bg-gray-100', text: 'text-gray-600', label: 'CALENTAMIENTO' },
  quality: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'CALIDAD' },
  strength: { bg: 'bg-red-100', text: 'text-red-700', label: 'FUERZA' },
  metcon: { bg: 'bg-orange-100', text: 'text-orange-700', label: 'METCON' },
  finisher: { bg: 'bg-purple-100', text: 'text-purple-700', label: 'FINISHER' },
  run: { bg: 'bg-amber-100', text: 'text-amber-700', label: 'CARRERA' },
}

export default function BlockCard({ block, checks, onToggle }) {
  const cfg = blockColors[block.type] || blockColors.warmup

  return (
    <div className="bg-white rounded-2xl mx-5 mb-4 overflow-hidden shadow-sm">
      <div className="px-5 pt-4 pb-3 border-b border-gray-100">
        <div className="flex items-start justify-between gap-3 mb-1.5">
          <div className="flex-1 min-w-0">
            <span className={`inline-block text-[10px] font-bold tracking-wider px-2 py-0.5 rounded ${cfg.bg} ${cfg.text} mb-1.5`}>
              {cfg.label}
            </span>
            <h3 className="font-display text-lg leading-tight">{block.title}</h3>
          </div>
          {block.duration > 0 && (
            <div className="flex-shrink-0 bg-bigg-bg rounded-lg px-3 py-1.5 text-center">
              <div className="font-display text-base leading-none">{block.duration}'</div>
            </div>
          )}
        </div>
        {block.format && (
          <p className="text-xs text-gray-500 italic mt-1">{block.format}</p>
        )}
      </div>

      <div>
        {block.exercises.map(ex => (
          <ExerciseRow
            key={ex.id}
            exercise={ex}
            checked={!!checks[ex.id]}
            onToggle={() => onToggle(ex.id)}
          />
        ))}
      </div>
    </div>
  )
}
