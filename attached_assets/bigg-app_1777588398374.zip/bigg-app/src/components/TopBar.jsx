import { ShoppingBag, Mail, Bell } from 'lucide-react'
import BiggLogo from './BiggLogo'

export default function TopBar() {
  return (
    <div className="px-5 pt-4 pb-3 flex items-center justify-between bg-bigg-bg sticky top-0 z-30">
      <BiggLogo />
      <div className="flex items-center gap-4">
        <button className="p-1"><ShoppingBag className="w-6 h-6" strokeWidth={2} /></button>
        <button className="p-1"><Mail className="w-6 h-6" strokeWidth={2} /></button>
        <button className="p-1"><Bell className="w-6 h-6" strokeWidth={2} /></button>
      </div>
    </div>
  )
}
