import { Home, BarChart3, Globe, Users, User } from 'lucide-react'

export default function BottomNav({ active = 'home', onChange }) {
  const items = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'actividad', label: 'Actividad', icon: BarChart3 },
    { id: 'world', label: 'BIGG WORLD', icon: Globe, primary: true },
    { id: 'comunidad', label: 'Comunidad', icon: Users },
    { id: 'perfil', label: 'Perfil', icon: User },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40 max-w-[480px] mx-auto pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-center justify-around relative px-2 pt-2 pb-2">
        {items.map(item => {
          const Icon = item.icon
          const isActive = active === item.id

          if (item.primary) {
            return (
              <button
                key={item.id}
                onClick={() => onChange?.(item.id)}
                className="flex flex-col items-center -mt-7"
              >
                <div className="w-14 h-14 rounded-full bg-bigg-lime flex items-center justify-center shadow-lg">
                  <Icon className="w-7 h-7 text-bigg-dark" strokeWidth={2} />
                </div>
                <span className={`text-[10px] font-medium mt-1 ${isActive ? 'text-bigg-dark' : 'text-gray-400'}`}>
                  {item.label}
                </span>
              </button>
            )
          }

          return (
            <button
              key={item.id}
              onClick={() => onChange?.(item.id)}
              className="flex flex-col items-center px-3 py-1"
            >
              <Icon className={`w-6 h-6 mb-0.5 ${isActive ? 'text-bigg-dark' : 'text-gray-400'}`} strokeWidth={isActive ? 2.5 : 2} />
              <span className={`text-[11px] font-medium ${isActive ? 'text-bigg-dark' : 'text-gray-400'}`}>
                {item.label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
