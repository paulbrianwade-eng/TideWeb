import { Footprints, Dumbbell, RotateCw } from 'lucide-react'

export default function SectionTabs({ active = 'train', onChange }) {
  const tabs = [
    { id: 'train', label: 'Train', icon: Footprints },
    { id: 'play', label: 'Play', icon: Dumbbell },
    { id: 'recover', label: 'Recover', icon: RotateCw },
  ]
  return (
    <div className="flex border-b border-gray-200 bg-bigg-bg">
      {tabs.map(tab => {
        const Icon = tab.icon
        const isActive = active === tab.id
        return (
          <button
            key={tab.id}
            onClick={() => onChange?.(tab.id)}
            className={`flex-1 flex flex-col items-center py-3 relative ${isActive ? 'tab-active' : ''}`}
          >
            <Icon className={`w-7 h-7 mb-1 ${isActive ? 'text-bigg-dark' : 'text-gray-400'}`} strokeWidth={1.5} />
            <span className={`text-sm font-medium ${isActive ? 'text-bigg-dark' : 'text-gray-400'}`}>
              {tab.label}
            </span>
          </button>
        )
      })}
    </div>
  )
}
