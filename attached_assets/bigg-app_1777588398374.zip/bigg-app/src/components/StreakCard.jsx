import { week } from '../data/routine'
import { Plus } from 'lucide-react'

export default function StreakCard({ completedDays, onDayClick }) {
  return (
    <div className="bg-white rounded-2xl p-4 mx-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-bold text-base">Strike de Actividad</h3>
        <button className="flex items-center gap-1 text-bigg-dark text-sm font-medium">
          <Plus className="w-4 h-4" /> Agregar nueva
        </button>
      </div>
      <div className="grid grid-cols-7 gap-1">
        {week.map(d => {
          const isComplete = completedDays.includes(d.id)
          return (
            <button
              key={d.id}
              onClick={() => onDayClick?.(d.id)}
              className="flex flex-col items-center gap-2"
            >
              <span className={`text-xs font-medium ${isComplete ? 'text-bigg-dark' : 'text-gray-300'}`}>
                {d.day}
              </span>
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs ${
                  isComplete ? 'bg-bigg-lime' : 'bg-gray-100'
                }`}
              >
                {isComplete && (
                  <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4 text-bigg-dark">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
                  </svg>
                )}
              </div>
            </button>
          )
        })}
      </div>
    </div>
  )
}
