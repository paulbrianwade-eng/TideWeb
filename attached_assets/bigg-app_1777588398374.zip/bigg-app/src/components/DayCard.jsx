import { Home, Activity, ChevronRight } from 'lucide-react'

const typeConfig = {
  bigg: { tag: 'BIGG AT HOME', icon: Home, gradient: 'from-black/20 via-black/40 to-black/85' },
  run: { tag: 'BIGG RUN', icon: Activity, gradient: 'from-black/10 via-black/30 to-black/80' },
  rest: { tag: 'RECOVER', icon: Home, gradient: 'from-black/10 via-black/20 to-black/70' },
}

export default function DayCard({ day, onClick, isCompleted }) {
  const cfg = typeConfig[day.type] || typeConfig.bigg
  const Icon = cfg.icon

  return (
    <button
      onClick={onClick}
      className="relative w-full overflow-hidden rounded-3xl bg-gray-900 aspect-[3/4] active:scale-[0.98] transition-transform"
    >
      <img
        src={day.image}
        alt={day.title}
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
      />
      <div className={`absolute inset-0 bg-gradient-to-b ${cfg.gradient}`} />

      {/* Tag superior */}
      <div className="absolute top-4 left-4">
        <span className="bg-white/95 backdrop-blur-sm text-bigg-dark text-xs font-bold px-3 py-1.5 rounded-full">
          {cfg.tag}
        </span>
      </div>

      {/* Badge completado */}
      {isCompleted && (
        <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-bigg-lime flex items-center justify-center shadow-lg">
          <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 text-bigg-dark">
            <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      )}

      {/* Icono inferior izquierdo */}
      <div className="absolute bottom-32 left-4">
        <div className="w-10 h-10 rounded-full bg-bigg-dark/80 backdrop-blur flex items-center justify-center">
          <Icon className="w-5 h-5 text-white" strokeWidth={2} />
        </div>
      </div>

      {/* Título y duración abajo */}
      <div className="absolute bottom-0 left-0 right-0 p-5">
        <div className="flex items-end justify-between gap-3">
          <div className="flex-1 min-w-0 text-left">
            <h3 className="font-display text-3xl text-white leading-tight mb-1">
              {day.name}
            </h3>
            <p className="text-white/80 text-sm font-medium">{day.duration} minutos</p>
          </div>
          <div className="flex-shrink-0 w-10 h-10 rounded-full bg-white/20 backdrop-blur flex items-center justify-center">
            <ChevronRight className="w-5 h-5 text-white" strokeWidth={2.5} />
          </div>
        </div>
      </div>
    </button>
  )
}
