export default function BiggLogo({ className = "" }) {
  return (
    <span className={`font-display text-2xl tracking-tight ${className}`}>
      BIGG
    </span>
  )
}
