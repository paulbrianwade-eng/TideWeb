export default function ExerciseRow({ exercise, checked, onToggle }) {
  const hasWarning = exercise.detail?.includes('⚠️')
  const detail = exercise.detail?.replace('⚠️', '').trim()

  return (
    <button
      onClick={onToggle}
      className="w-full text-left px-5 py-3.5 border-b border-gray-100 active:bg-gray-50 transition-colors flex items-start gap-3 last:border-b-0"
    >
      <div
        className={`flex-shrink-0 w-6 h-6 rounded-md border-2 mt-0.5 flex items-center justify-center transition-all ${
          checked
            ? 'bg-bigg-lime border-bigg-lime'
            : 'bg-white border-gray-300'
        }`}
      >
        {checked && (
          <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4 text-bigg-dark">
            <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round"/>
          </svg>
        )}
      </div>

      <div className="flex-1 min-w-0">
        <p className={`font-semibold text-[15px] leading-tight mb-1 ${checked ? 'line-through text-gray-400' : 'text-bigg-dark'}`}>
          {exercise.name}
        </p>

        <div className="flex flex-wrap items-center gap-2 mb-1.5">
          {exercise.reps && (
            <span className="text-xs font-bold bg-bigg-lime text-bigg-dark px-2 py-0.5 rounded">
              {exercise.reps}
            </span>
          )}
          {exercise.rest && (
            <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded">
              ⏸ {exercise.rest}
            </span>
          )}
          {exercise.target && (
            <span className="text-xs text-gray-600 bg-gray-100 px-2 py-0.5 rounded font-medium">
              📊 {exercise.target}
            </span>
          )}
        </div>

        {detail && (
          <p className={`text-xs leading-snug ${checked ? 'text-gray-300' : 'text-gray-500'}`}>
            {hasWarning && <span className="text-orange-500 mr-1">⚠️</span>}
            {detail}
          </p>
        )}
      </div>
    </button>
  )
}
