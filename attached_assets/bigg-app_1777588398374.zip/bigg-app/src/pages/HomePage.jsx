import TopBar from '../components/TopBar'
import SectionTabs from '../components/SectionTabs'
import DayCard from '../components/DayCard'
import StreakCard from '../components/StreakCard'
import { week } from '../data/routine'
import { useMemo } from 'react'

export default function HomePage({ onSelectDay, completedDays, currentDayId }) {
  // Reordena para mostrar el día de hoy primero
  const orderedWeek = useMemo(() => {
    const idx = week.findIndex(d => d.id === currentDayId)
    if (idx <= 0) return week
    return [...week.slice(idx), ...week.slice(0, idx)]
  }, [currentDayId])

  return (
    <div className="min-h-screen bg-bigg-bg pb-32 max-w-[480px] mx-auto">
      <div className="dot-pattern">
        <TopBar />
        <SectionTabs active="train" />

        <div className="px-5 pt-5 pb-3">
          <h2 className="font-display text-2xl">Entrenamientos de BIGG</h2>
          <p className="text-sm text-gray-500 mt-0.5">Tu semana adaptada para casa</p>
        </div>

        {/* Slider de días */}
        <div className="snap-cards no-scrollbar overflow-x-auto flex gap-3 px-5 pb-5">
          {orderedWeek.map(day => (
            <div key={day.id} className="flex-shrink-0 w-[78%]">
              <DayCard
                day={day}
                onClick={() => onSelectDay(day.id)}
                isCompleted={completedDays.includes(day.id)}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Strike */}
      <div className="mt-2">
        <StreakCard
          completedDays={completedDays}
          onDayClick={onSelectDay}
        />
      </div>

      {/* Card invitación */}
      <div className="bg-white rounded-2xl p-5 mx-5 mt-4 shadow-sm">
        <div className="flex items-start gap-3 mb-3">
          <div className="w-10 h-10 rounded-full bg-bigg-lime flex items-center justify-center flex-shrink-0">
            <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 text-bigg-dark">
              <path d="M17 20h5v-2a4 4 0 0 0-3-3.87M9 20H4v-2a4 4 0 0 1 3-3.87m6-9a4 4 0 1 1-8 0 4 4 0 0 1 8 0z" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </div>
          <div className="flex-1">
            <h4 className="font-bold text-[15px] mb-0.5">Adaptado a tu equipamiento</h4>
            <p className="text-xs text-gray-500 leading-snug">
              Toda la rutina sustituye Wall Ball, máquinas y DDB pesadas por KBs, soga y barra olímpica.
            </p>
          </div>
        </div>
      </div>

      {/* Section de notas */}
      <div className="px-5 mt-6 mb-3">
        <h2 className="font-display text-2xl">Mejorá tu performance</h2>
      </div>

      <div className="px-5 space-y-3">
        <NoteTile title="Sustituciones" subtitle="Cómo adaptar cada ejercicio a tu casa" />
        <NoteTile title="Cargas en barra" subtitle="Pesos sugeridos por movimiento" />
        <NoteTile title="Banderas rojas" subtitle="Cuándo descansar" />
      </div>
    </div>
  )
}

function NoteTile({ title, subtitle }) {
  return (
    <button className="w-full bg-white rounded-2xl p-4 flex items-center justify-between shadow-sm active:scale-[0.99] transition-transform">
      <div className="text-left">
        <h4 className="font-bold text-base">{title}</h4>
        <p className="text-xs text-gray-500 mt-0.5">{subtitle}</p>
      </div>
      <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 text-gray-400">
        <path d="M9 18l6-6-6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    </button>
  )
}
