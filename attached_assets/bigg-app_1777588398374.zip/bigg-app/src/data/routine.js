// Rutina semanal BIGG at Home adaptada a equipamiento de Patricio
// Equipamiento: Rack + barra olímpica + 60kg discos | Banco reclinable
// KB 8/12/20 | DDB 1/3/5 (ligeras) | Cajón salto | TRX | Soga | Rueda abdominal | Elásticos

export const equipment = [
  { id: 'rack', name: 'Rack', icon: '🏗️' },
  { id: 'barbell', name: 'Barra olímpica + 60kg', icon: '🏋️' },
  { id: 'bench', name: 'Banco reclinable', icon: '🛋️' },
  { id: 'kb', name: 'KB 8/12/20 kg', icon: '⚫' },
  { id: 'db', name: 'DDB 1/3/5 kg', icon: '💪' },
  { id: 'box', name: 'Cajón salto', icon: '📦' },
  { id: 'trx', name: 'TRX', icon: '🔗' },
  { id: 'rope', name: 'Soga', icon: '🪢' },
  { id: 'wheel', name: 'Rueda abdominal', icon: '🎡' },
  { id: 'bands', name: 'Elásticos', icon: '➰' },
]

export const week = [
  // ============ LUNES ============
  {
    id: 'lun',
    day: 'L',
    name: 'Lunes',
    type: 'bigg',
    title: 'BIGG Full Hybrid',
    subtitle: 'Squat + metcon largo',
    duration: 55,
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&q=80',
    intro: 'Sesión completa con squat pesado + metcon medio + finisher. Abres la semana fresco del descanso.',
    blocks: [
      {
        type: 'warmup',
        title: 'Calentamiento',
        duration: 8,
        format: 'Activación general + específica',
        exercises: [
          { id: 'l-w-1', name: 'Movilidad cadera + tobillo', reps: '5 min', detail: "Gato/camello, world's greatest, ankle rocks" },
          { id: 'l-w-2', name: 'Activación general', reps: '2 rondas', detail: '10 air squats + 10 push ups + 10 jumping jacks + 5 inchworm' },
          { id: 'l-w-3', name: 'Específico al squat', reps: '2 sets', rest: '30"', detail: 'Back squat barra vacía 5 reps + 60% 1RM × 5' },
        ]
      },
      {
        type: 'quality',
        title: 'FBA · Calidad',
        format: 'AMRAP for quality',
        duration: 7,
        exercises: [
          { id: 'l-1-1', name: 'Runner Step Ups', reps: '6/6 reps', detail: 'En tu cajón. Sin peso o KB 8 kg en goblet. Movimiento controlado.' },
          { id: 'l-1-2', name: 'Heiden a Single-Leg Box Jump', reps: '2/2 reps', detail: 'Salto lateral, caes a una pierna sobre cajón bajo.' },
          { id: 'l-1-3', name: 'Reverse Lunge', reps: '6/6 reps', detail: 'Tronco vertical, rodilla atrás cae suave.' },
          { id: 'l-1-4', name: 'Asymmetric Halo (KB 8 o 12)', reps: '6/6 reps', detail: 'Círculo lento alrededor de la cabeza, core estable.' },
        ]
      },
      {
        type: 'strength',
        title: 'Hybrid Strength',
        format: 'AMRAP 13\' · Objetivo 3-4 rondas',
        duration: 13,
        exercises: [
          { id: 'l-2-1', name: 'Barbell Back Squat', reps: '6 reps', detail: 'Carga ~72.5% 1RM. RPE 7-8. Foco en profundidad.', target: '~45-50 kg' },
          { id: 'l-2-2', name: 'Box Jumps', reps: '8 reps', detail: 'Tu cajón. Rebote suave o step down si quieres cuidar rodillas.' },
          { id: 'l-2-3', name: 'Soga (jump rope)', reps: '90"', detail: '⚠️ Sustituye al "Machine 40%". Salto continuo a ritmo conversacional.' },
        ]
      },
      {
        type: 'metcon',
        title: 'Every 90"',
        format: '8 rondas · KB Complex',
        duration: 12,
        exercises: [
          { id: 'l-3-1', name: 'KB Front Squat (2× KB 12)', reps: '6 reps', detail: 'Una en cada hombro, codos altos. ⚠️ Reemplaza DDB pesadas.' },
          { id: 'l-3-2', name: 'KB Hang Clean (KB 20)', reps: '4/4 reps', detail: 'Una sola KB, alterna. Controla la trayectoria.' },
          { id: 'l-3-3', name: 'KB Push Press (KB 20)', reps: '4/4 reps', detail: 'Asistencia de piernas, bloqueo arriba.' },
          { id: 'l-3-4', name: 'Burpees', reps: '4 reps', detail: 'Pecho al suelo, salto con palmada arriba.' },
        ]
      },
      {
        type: 'finisher',
        title: 'Finisher',
        format: 'Complete 3 a 10',
        duration: 8,
        exercises: [
          { id: 'l-4-1', name: 'KB Swing (KB 20)', reps: '3-4-5...10', detail: '⚠️ Reemplaza Wall Ball. KB hasta altura ojos. Bisagra de cadera.' },
          { id: 'l-4-2', name: 'Burpees', reps: '3-4-5...10', detail: 'Pecho al suelo, salto con palmada.' },
          { id: 'l-4-3', name: 'Box Jumps', reps: '3-4-5...10', detail: 'Cajón medio.' },
        ]
      },
    ]
  },

  // ============ MARTES ============
  {
    id: 'mar',
    day: 'M',
    name: 'Martes',
    type: 'run',
    title: 'Run Z2 · Base aeróbica',
    subtitle: 'Recuperación + oxidación de grasa',
    duration: 50,
    image: 'https://images.unsplash.com/photo-1486218119243-13883505764c?w=800&q=80',
    intro: 'Carrera continua a ritmo conversacional. NO buscas rendimiento, buscas recuperación entre lunes y miércoles.',
    blocks: [
      {
        type: 'run',
        title: 'Carrera Z2',
        format: 'Pulso 60-70% FCM · Conversacional',
        duration: 50,
        exercises: [
          { id: 'm-1-1', name: 'Calentamiento', reps: '5-8 min', detail: 'Trote muy suave. Movilidad cadera/tobillo antes de empezar.' },
          { id: 'm-1-2', name: 'Bloque principal Z2', reps: '35-45 min', detail: 'Pulso ~130-145 ppm. Para tu nivel: ~30-60s/km más lento que tu pace habitual.' },
          { id: 'm-1-3', name: 'Vuelta a la calma', reps: '5 min', detail: 'Caminata. Bajar pulso bajo 110 ppm antes de parar.' },
        ]
      },
      {
        type: 'quality',
        title: 'Cómo saber si estás en Z2',
        duration: 0,
        exercises: [
          { id: 'm-2-1', name: 'Test conversación', detail: 'Puedes hablar 4-5 frases seguidas sin jadear.' },
          { id: 'm-2-2', name: 'Sensación', detail: 'Sostendrías ese ritmo 2 horas si hiciera falta.' },
          { id: 'm-2-3', name: 'Si necesitas caminar', detail: 'Camina. Es válido. La constancia del pulso bajo es lo que importa.' },
        ]
      },
    ]
  },

  // ============ MIÉRCOLES ============
  {
    id: 'mie',
    day: 'M',
    name: 'Miércoles',
    type: 'bigg',
    title: 'BIGG Metcon',
    subtitle: 'Bench Press + intervalos',
    duration: 50,
    image: 'https://images.unsplash.com/photo-1532029837206-abbe2b7620e3?w=800&q=80',
    intro: 'Sesión más metabólica de la semana. Bench dentro de un AMRAP, luego intervalo intenso 50/10.',
    blocks: [
      {
        type: 'warmup',
        title: 'Calentamiento',
        duration: 8,
        exercises: [
          { id: 'mi-w-1', name: 'Movilidad torácica + hombro', reps: '4 min', detail: 'Cat-cow, thread the needle, banded dislocates con elástico.' },
          { id: 'mi-w-2', name: 'Activación', reps: '2 rondas', detail: '10 push ups + 10 KB swing ligero (KB 8) + 10 air squats.' },
          { id: 'mi-w-3', name: 'Aprox. al bench', reps: '2 sets', rest: '45"', detail: 'Barra vacía × 8 + 60% 1RM × 5.' },
        ]
      },
      {
        type: 'strength',
        title: 'Hybrid Strength',
        format: 'AMRAP 12\' · Objetivo 3-4 rondas',
        duration: 12,
        exercises: [
          { id: 'mi-1-1', name: 'Barbell Bench Press', reps: '5 reps', detail: 'Carga ~75% 1RM. RPE 7-8.', target: '~50-55 kg' },
          { id: 'mi-1-2', name: 'Push Up Hold', reps: '10"', detail: 'Posición media del push up por 10 segundos.' },
          { id: 'mi-1-3', name: 'Soga (jump rope)', reps: '90"', detail: '⚠️ Reemplaza Machine 40%. Salto continuo controlado.' },
        ]
      },
      {
        type: 'metcon',
        title: '50" ON / 10" OFF',
        format: '8 minutos · 2 rondas',
        duration: 8,
        exercises: [
          { id: 'mi-2-1', name: 'KB Floor Press (2× KB 12)', reps: '50"', detail: '⚠️ Reemplaza DDB Chest Press. Acostado en suelo, una KB en cada mano.' },
          { id: 'mi-2-2', name: 'KB Push Press (KB 20)', reps: '50"', detail: 'Una mano. Cambia de mano en la siguiente ronda.' },
          { id: 'mi-2-3', name: 'Soga (alta intensidad)', reps: '50"', detail: '⚠️ Reemplaza Machine. Doble salto si puedes.' },
          { id: 'mi-2-4', name: 'KB Russian Swing (KB 20)', reps: '50"', detail: 'KB hasta altura del pecho, no overhead.' },
        ]
      },
      {
        type: 'finisher',
        title: 'Core finisher',
        duration: 8,
        exercises: [
          { id: 'mi-3-1', name: 'Russian Twist (disco 5-10 kg)', reps: '3 × 20', rest: '30"', detail: 'Disco de la barra o KB 8 kg. Talones arriba si controlas.' },
          { id: 'mi-3-2', name: 'Plank Twist Lateral (DDB 3-5)', reps: '3 × 10/lado', rest: '30"', detail: 'Desde plank alto, gira y toca DDB con mano contraria.' },
          { id: 'mi-3-3', name: 'Palof Press (elástico)', reps: '3 × 12/lado', rest: '30"', detail: '⚠️ Con elástico anclado al rack. Anti-rotación.' },
        ]
      },
    ]
  },

  // ============ JUEVES ============
  {
    id: 'jue',
    day: 'J',
    name: 'Jueves',
    type: 'run',
    title: 'Run Intervalos · VO2max',
    subtitle: 'Cardio intenso · EPOC alto',
    duration: 38,
    image: 'https://images.unsplash.com/photo-1571008887538-b36bb32f4571?w=800&q=80',
    intro: 'Sesión clave para condicionamiento. Intervalos de alta intensidad. Sube tu VO2max y dispara EPOC.',
    blocks: [
      {
        type: 'warmup',
        title: 'Estructura',
        duration: 38,
        exercises: [
          { id: 'j-1-1', name: 'Calentamiento', reps: '10 min', detail: 'Caminata 2\' → trote suave subiendo gradualmente.' },
          { id: 'j-1-2', name: 'Drills (opcional)', reps: '3 min', detail: 'Skipping, talones glúteos, zancadas largas.' },
          { id: 'j-1-3', name: 'Bloque principal', reps: '16 min', detail: 'Elige una de las dos opciones de abajo.' },
          { id: 'j-1-4', name: 'Vuelta a la calma', reps: '8 min', detail: 'Trote suave Z1.' },
        ]
      },
      {
        type: 'metcon',
        title: 'Opción A · 4×4',
        format: 'Clásico VO2max',
        duration: 16,
        exercises: [
          { id: 'j-2-1', name: 'Trabajo: 4 min', reps: '× 4 series', detail: '85-90% FCM. Ritmo exigente sin reventar.' },
          { id: 'j-2-2', name: 'Recuperación: 2 min', reps: '× 4', detail: 'Trote muy suave. Pulso debe bajar a Z2.' },
        ]
      },
      {
        type: 'metcon',
        title: 'Opción B · 30/30',
        format: 'Más explosivo',
        duration: 16,
        exercises: [
          { id: 'j-3-1', name: 'Trabajo: 30"', reps: '× 16 rondas', detail: '~90% FCM. Casi sprint controlado.' },
          { id: 'j-3-2', name: 'Recuperación: 30"', reps: '× 16', detail: 'Trote suave activo, no caminando.' },
        ]
      },
      {
        type: 'quality',
        title: 'Cuándo usar cada opción',
        duration: 0,
        exercises: [
          { id: 'j-4-1', name: 'Si mañana hay deadlift', detail: 'Usa Opción B (30/30). Menos exigente para piernas.' },
          { id: 'j-4-2', name: 'Si te sientes con energía', detail: 'Usa Opción A (4×4).' },
          { id: 'j-4-3', name: 'Si llegas cansado', detail: 'Reduce a 3×4 o 12×30/30.' },
        ]
      },
    ]
  },

  // ============ VIERNES ============
  {
    id: 'vie',
    day: 'V',
    name: 'Viernes',
    type: 'bigg',
    title: 'BIGG Posterior',
    subtitle: 'Deadlift + KB heavy',
    duration: 55,
    image: 'https://images.unsplash.com/photo-1517344884509-a0c97ec11bcc?w=800&q=80',
    intro: 'Cadena posterior (deadlift) y trabajo metabólico con KB pesadas. Vienes con piernas trabajadas del jueves: metcon medio.',
    blocks: [
      {
        type: 'warmup',
        title: 'Calentamiento',
        duration: 8,
        exercises: [
          { id: 'v-w-1', name: 'Movilidad cadera + isquios', reps: '4 min', detail: '90/90, world\'s greatest, jefferson curls suaves.' },
          { id: 'v-w-2', name: 'Activación posterior', reps: '2 sets', rest: '30"', detail: '10 glute bridge + 10 banded good morning + 10 KB swing ligero.' },
          { id: 'v-w-3', name: 'Aprox. al deadlift', reps: '2 sets', rest: '60"', detail: 'Barra vacía × 8 + 50% 1RM × 5.' },
        ]
      },
      {
        type: 'strength',
        title: 'Hybrid Strength · Deadlift',
        format: 'AMRAP 13\' · NO buscar PR',
        duration: 13,
        exercises: [
          { id: 'v-1-1', name: 'Barbell Deadlift', reps: '5 reps', detail: 'Carga ~70% 1RM. RPE 7. Técnica primero.', target: '~50 kg' },
          { id: 'v-1-2', name: 'Push Up Hold', reps: '10"', detail: 'Activación tren superior entre rondas.' },
          { id: 'v-1-3', name: 'Soga', reps: '90"', detail: 'Recuperación activa.' },
        ]
      },
      {
        type: 'metcon',
        title: 'Every 90" · KB heavy',
        format: '8 rondas · Cargas más altas',
        duration: 12,
        exercises: [
          { id: 'v-2-1', name: 'KB Front Squat (2× KB 12)', reps: '6 reps', detail: 'Cuidar técnica con la fatiga del DL.' },
          { id: 'v-2-2', name: 'KB Hang Clean (KB 20)', reps: '4/4', detail: 'Sin soltar entre ejercicios.' },
          { id: 'v-2-3', name: 'KB Push Press (KB 20)', reps: '4/4', detail: 'Empuje con piernas.' },
          { id: 'v-2-4', name: 'Burpees', reps: '4', detail: 'Pecho al suelo + salto.' },
        ]
      },
      {
        type: 'strength',
        title: 'Glúteo / Posterior',
        format: 'Accesorio',
        duration: 12,
        exercises: [
          { id: 'v-3-1', name: 'Hip Thrust (BB en banco)', reps: '4 × 10', rest: '60"', detail: 'Espalda alta en banco, barra acolchada. Pausa 1" arriba.', target: '~40-50 kg' },
          { id: 'v-3-2', name: 'Hamstring Bridge (talones en banco)', reps: '3 × 12', rest: '45"', detail: 'Pies arriba en banco, sube cadera apretando isquios.' },
        ]
      },
      {
        type: 'finisher',
        title: 'Core breve',
        duration: 5,
        exercises: [
          { id: 'v-4-1', name: 'Hollow Hold', reps: '3 × 30"', rest: '30"', detail: 'Lumbar pegada al suelo.' },
          { id: 'v-4-2', name: 'Side Plank', reps: '3 × 30"/lado', rest: '30"', detail: 'Cadera arriba, alineación recta.' },
        ]
      },
    ]
  },

  // ============ SÁBADO ============
  {
    id: 'sab',
    day: 'S',
    name: 'Sábado',
    type: 'bigg',
    title: 'BIGG Hyrox-style',
    subtitle: 'Híbrido completo · Día estrella',
    duration: 55,
    image: 'https://images.unsplash.com/photo-1599058917212-d750089bc07e?w=800&q=80',
    intro: 'La sesión más completa y metabólica de la semana. Aquí cierras los días fuertes. Vienes con descanso del jueves intenso.',
    blocks: [
      {
        type: 'warmup',
        title: 'Calentamiento',
        duration: 8,
        exercises: [
          { id: 's-w-1', name: 'Movilidad general', reps: '4 min', detail: 'Mix completo: cadera, hombro, columna torácica.' },
          { id: 's-w-2', name: 'Activación', reps: '2 rondas', detail: '10 air squats + 10 push ups + 10 KB swing + 5 burpees suaves.' },
          { id: 's-w-3', name: 'Específico', reps: '2 sets', rest: '30"', detail: 'Front squat barra vacía + 5 TRX rows.' },
        ]
      },
      {
        type: 'strength',
        title: 'Hybrid Strength · Front Squat',
        format: 'AMRAP 12\'',
        duration: 12,
        exercises: [
          { id: 's-1-1', name: 'Barbell Front Squat', reps: '6 reps', detail: 'Codos altos, tronco vertical. RPE 7.', target: '~40-45 kg' },
          { id: 's-1-2', name: 'TRX Row (estricto)', reps: '8 reps', detail: '⚠️ Reemplaza Pull Ups. Cuerpo recto, apretar escápulas. Más vertical = más difícil.' },
          { id: 's-1-3', name: 'Soga', reps: '90"', detail: 'Recuperación activa.' },
        ]
      },
      {
        type: 'metcon',
        title: 'Long Metcon · Hyrox',
        format: 'AMRAP 13\' · Objetivo: 1 ronda completa',
        duration: 13,
        exercises: [
          { id: 's-2-1', name: 'KB Swing (KB 20)', reps: '30 reps', detail: '⚠️ Reemplaza Wall/Air Ball. Reps en partidas si necesitas.' },
          { id: 's-2-2', name: 'TRX Row', reps: '5 reps', detail: 'Estricto, ritmo controlado.' },
          { id: 's-2-3', name: 'KB Front Rack Lunges (2× KB 12)', reps: '30 reps', detail: 'KB en posición rack, alterna piernas.' },
          { id: 's-2-4', name: 'Man-Maker (DDB 5 o KB 8)', reps: '5 reps', detail: 'Push up + row D + row I + clean + push press. Usa lo que tengas más liviano para hacerlo bien.' },
          { id: 's-2-5', name: 'KB Floor Press (2× KB 12)', reps: '30 reps', detail: 'En suelo, ritmo constante.' },
          { id: 's-2-6', name: 'KB Thruster (2× KB 12)', reps: '5 reps', detail: 'Squat + push press encadenado.' },
          { id: 's-2-7', name: 'Burpee + KB Clean (KB 20)', reps: '20 reps', detail: '⚠️ Reemplaza Devil Clean. Burpee + clean a hombro alterno.' },
        ]
      },
      {
        type: 'finisher',
        title: 'Core finisher',
        duration: 7,
        exercises: [
          { id: 's-3-1', name: 'KB Halo (KB 12)', reps: '3 × 8/dirección', rest: '30"', detail: 'Lento, controlado, core estable.' },
          { id: 's-3-2', name: 'Hollow Hold (con KB 8 extendida)', reps: '3 × 30"', rest: '30"', detail: 'KB sobre la cabeza para más dificultad.' },
          { id: 's-3-3', name: 'Rueda abdominal', reps: '3 × 8-10', rest: '45"', detail: '⚠️ Reemplaza Sprawls. Desde rodillas. Cierra costillas, no arquees lumbar.' },
        ]
      },
    ]
  },

  // ============ DOMINGO ============
  {
    id: 'dom',
    day: 'D',
    name: 'Domingo',
    type: 'rest',
    title: 'Descanso',
    subtitle: 'Recuperación total',
    duration: 30,
    image: 'https://images.unsplash.com/photo-1545389336-cf090694435e?w=800&q=80',
    intro: 'Sin entrenamiento estructurado. La recuperación ES entrenamiento.',
    blocks: [
      {
        type: 'quality',
        title: 'Recuperación activa (opcional)',
        format: '30-45 min',
        duration: 30,
        exercises: [
          { id: 'd-1-1', name: 'Caminata al aire libre', reps: '30-45 min', detail: 'Ritmo cómodo. Sol si es posible.' },
          { id: 'd-1-2', name: 'Movilidad / yoga suave', reps: '15-20 min', detail: 'Cadera, columna, hombros.' },
          { id: 'd-1-3', name: 'Sauna o baño caliente', detail: 'Si tienes acceso. Acelera recuperación.' },
        ]
      },
      {
        type: 'quality',
        title: 'Importante',
        duration: 0,
        exercises: [
          { id: 'd-2-1', name: 'No metas otra carrera larga', detail: 'Necesitas el reset. La constancia semanal vale más que el día extra.' },
        ]
      },
    ]
  },
]

export const notes = [
  {
    title: 'Por qué esta distribución',
    items: [
      'Lun BIGG fuerte → Mar Z2 recupera → Mié BIGG fuerte → Jue intervalos cortos. Los días duros nunca van pegados.',
      'El Z2 del martes acelera la recuperación del lunes y oxida grasa sin acumular fatiga.',
      'Los intervalos del jueves disparan VO2max sin cansar piernas tanto como un BIGG.',
    ]
  },
  {
    title: 'Sustituciones por equipamiento',
    items: [
      'Wall Ball / Air Ball → KB Swing (KB 20). Mismo patrón explosivo de cadera.',
      'DDB pesadas (front squat, push press, thruster) → 2× KB 12 o KB 20.',
      'Machine 40% → Soga (jump rope). Mismo estímulo aeróbico activo.',
      'Pull Ups estrictos → TRX Row. Más vertical = más difícil.',
      'Devil Clean → Burpee + KB Clean.',
    ]
  },
  {
    title: 'Carga sugerida en barra (1RM aprox.)',
    items: [
      'Si tienes 60 kg de discos + barra (~80 kg total), trabaja al 70-75% para AMRAPs.',
      'Back Squat: ~45-50 kg | Bench: ~50-55 kg | Deadlift: ~50 kg | Front Squat: ~40-45 kg.',
      'Ajusta según tus 1RMs reales. RPE manda más que el porcentaje.',
    ]
  },
  {
    title: 'Banderas rojas — descansa',
    items: [
      'FC en reposo +7 ppm sobre tu basal por 2+ días seguidos.',
      'Dormiste menos de 6h dos noches seguidas.',
      'Dolor articular real (no DOMS), especialmente lumbar, rodillas o tobillo.',
      'Apetito disparado, irritabilidad: déficit muy agresivo, súbele 200 kcal.',
    ]
  },
]
