import { useState, useEffect, useMemo } from 'react'
import HomePage from './pages/HomePage'
import DayDetailPage from './pages/DayDetailPage'
import BottomNav from './components/BottomNav'
import { week } from './data/routine'

const STORAGE_CHECKS = 'bigg_at_home_checks_v1'

function App() {
  const [page, setPage] = useState('home') // 'home' | 'day'
  const [activeDayId, setActiveDayId] = useState(null)
  const [checks, setChecks] = useState({})
  const [navTab, setNavTab] = useState('home')

  // Load progress from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_CHECKS)
      if (saved) setChecks(JSON.parse(saved))
    } catch (e) {}
  }, [])

  // Save progress
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_CHECKS, JSON.stringify(checks))
    } catch (e) {}
  }, [checks])

  const today = useMemo(() => {
    // Mapeo: 0=Dom 1=Lun ... 6=Sab → ids
    const map = ['dom', 'lun', 'mar', 'mie', 'jue', 'vie', 'sab']
    return map[new Date().getDay()]
  }, [])

  const completedDays = useMemo(() => {
    return week
      .filter(d => {
        if (d.type === 'rest') return false
        // Día completado si al menos 50% de ejercicios marcados (excluyendo calentamiento)
        const real = d.blocks.filter(b => b.type !== 'warmup').flatMap(b => b.exercises)
        if (real.length === 0) return false
        const done = real.filter(e => checks[e.id]).length
        return done / real.length >= 0.5
      })
      .map(d => d.id)
  }, [checks])

  function selectDay(id) {
    setActiveDayId(id)
    setPage('day')
    window.scrollTo(0, 0)
  }

  function toggleExercise(id) {
    setChecks(prev => ({ ...prev, [id]: !prev[id] }))
  }

  function backToHome() {
    setPage('home')
    setActiveDayId(null)
    window.scrollTo(0, 0)
  }

  const activeDay = week.find(d => d.id === activeDayId)

  return (
    <>
      {page === 'home' && (
        <HomePage
          onSelectDay={selectDay}
          completedDays={completedDays}
          currentDayId={today}
        />
      )}
      {page === 'day' && activeDay && (
        <DayDetailPage
          day={activeDay}
          checks={checks}
          onToggle={toggleExercise}
          onBack={backToHome}
        />
      )}
      <BottomNav active={navTab} onChange={setNavTab} />
    </>
  )
}

export default App
