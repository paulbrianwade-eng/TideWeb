# BIGG at Home — Rutina Personal

App tipo BIGG con tu rutina semanal adaptada a equipamiento de casa.

## Tu equipamiento

- Rack + barra olímpica + 60 kg en discos
- Banco reclinable
- KB: 8, 12 y 20 kg
- DDB: 1, 3 y 5 kg (ligeras)
- Cajón de salto
- TRX, soga, rueda abdominal, elásticos

## Stack

- React 18 + Vite + Tailwind CSS
- Persistencia en `localStorage`
- Optimizada para móvil (max 480px)

## Cómo correrla en Replit

1. Crea un nuevo Repl tipo **Node.js** o importa este folder
2. Replit detecta `.replit` y corre `npm install && npm run dev` automáticamente
3. La app se abre en el preview en el puerto 3000

## Cómo correrla local

```bash
npm install
npm run dev
```

Abre http://localhost:3000 en el navegador.

## Estructura

```
src/
  App.jsx              # Router simple home <-> day detail
  data/routine.js      # Rutina completa con sustituciones
  components/          # TopBar, BottomNav, DayCard, BlockCard, etc.
  pages/
    HomePage.jsx       # Pantalla principal estilo BIGG
    DayDetailPage.jsx  # Detalle del día con bloques y ejercicios
```

## Sustituciones clave

| Original BIGG | Adaptación casa |
|---|---|
| Wall Ball / Air Ball | KB Swing (KB 20) |
| DDB pesadas (front squat, push press) | 2× KB 12 o KB 20 |
| Machine 40% | Soga (jump rope) |
| Pull Ups estrictos | TRX Row |
| Devil Clean | Burpee + KB Clean |

## Distribución semanal

- **Lun**: BIGG Full Hybrid (squat + metcon)
- **Mar**: Run Z2 (45-55 min)
- **Mié**: BIGG Metcon (bench + intervalos)
- **Jue**: Run Intervalos (4×4 o 30/30)
- **Vie**: BIGG Posterior (deadlift + KB)
- **Sáb**: BIGG Hyrox-style (día estrella)
- **Dom**: Descanso

## Tracking

Marca cada ejercicio al completarlo. Un día se considera "completado" cuando marcas al menos 50% de los ejercicios principales (sin contar calentamiento). El strike semanal se actualiza automáticamente.
