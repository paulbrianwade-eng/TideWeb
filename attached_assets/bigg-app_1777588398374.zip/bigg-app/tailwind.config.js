/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        bigg: {
          lime: '#C8FF00',
          limeDark: '#A8DD00',
          dark: '#0A0A0A',
          gray: '#F5F5F5',
          textDim: '#6B7280',
          border: '#E5E7EB',
          surface: '#FFFFFF',
          bg: '#F2F2F2',
        }
      },
      fontFamily: {
        sans: ['-apple-system', 'BlinkMacSystemFont', 'system-ui', 'sans-serif'],
        display: ['"Archivo Black"', 'Impact', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
